<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('resepsionis');

$conn = connect_db();
$id_pengguna_resepsionis = $_SESSION['id_pengguna'];
$error_message = '';
$success_message = '';

// --- PENANGANAN AKSI (KONFIRMASI / BATALKAN VIA GET) ---
if (isset($_GET['action']) && isset($_GET['id_pendaftaran'])) {
    $action = sanitize_input($_GET['action']);
    $id_pendaftaran_aksi = intval($_GET['id_pendaftaran']);

    if ($action == 'konfirmasi') {
        $stmt_cek = $conn->prepare("SELECT status_pendaftaran FROM pendaftaran_konsultasi WHERE id_pendaftaran = ?");
        if ($stmt_cek) {
            $stmt_cek->bind_param("i", $id_pendaftaran_aksi);
            $stmt_cek->execute();
            $result_cek_status = $stmt_cek->get_result();
            if ($result_cek_status->num_rows > 0) {
                $current_status = $result_cek_status->fetch_assoc()['status_pendaftaran'];
                if ($current_status == 'Menunggu Konfirmasi') {
                    $conn->begin_transaction();
                    try {
                        $stmt_update = $conn->prepare("UPDATE pendaftaran_konsultasi SET status_pendaftaran = 'Dikonfirmasi', dikonfirmasi_oleh = ? WHERE id_pendaftaran = ?");
                        if (!$stmt_update) throw new Exception("Gagal siapkan statement update status: " . $conn->error);
                        $stmt_update->bind_param("ii", $id_pengguna_resepsionis, $id_pendaftaran_aksi);
                        if (!$stmt_update->execute()) throw new Exception("Gagal update status pendaftaran: " . $stmt_update->error);
                        $stmt_update->close();

                        $biaya_konsultasi_set_saat_konfirmasi = 0; // Biaya awal, bisa diupdate nanti

                        $stmt_cek_bayar = $conn->prepare("SELECT id_pembayaran FROM pembayaran WHERE id_pendaftaran = ?");
                        $stmt_cek_bayar->bind_param("i", $id_pendaftaran_aksi);
                        $stmt_cek_bayar->execute();
                        $result_cek_bayar = $stmt_cek_bayar->get_result();
                        $stmt_cek_bayar->close();

                        if ($result_cek_bayar->num_rows == 0) {
                            $stmt_bayar = $conn->prepare("INSERT INTO pembayaran (id_pendaftaran, total_biaya, status_pembayaran, diproses_oleh) VALUES (?, ?, 'Belum Lunas', ?)");
                            if (!$stmt_bayar) throw new Exception("Gagal siapkan statement pembayaran: " . $conn->error);
                            $stmt_bayar->bind_param("idi", $id_pendaftaran_aksi, $biaya_konsultasi_set_saat_konfirmasi, $id_pengguna_resepsionis);
                            if (!$stmt_bayar->execute()) throw new Exception("Gagal buat entri pembayaran: " . $stmt_bayar->error);
                            $stmt_bayar->close();
                        }
                        $conn->commit();
                        $success_message = "Pendaftaran (ID: $id_pendaftaran_aksi) berhasil dikonfirmasi.";
                    } catch (Exception $e) {
                        $conn->rollback();
                        $error_message = "Gagal konfirmasi pendaftaran: " . $e->getMessage();
                    }
                } else {
                    $error_message = "Pendaftaran (ID: $id_pendaftaran_aksi) tidak dalam status 'Menunggu Konfirmasi' atau sudah diproses.";
                }
            } else {
                 $error_message = "Pendaftaran (ID: $id_pendaftaran_aksi) tidak ditemukan.";
            }
             if($stmt_cek) $stmt_cek->close();
        } else {
            $error_message = "Gagal menyiapkan pengecekan status pendaftaran: " . $conn->error;
        }

    } elseif ($action == 'batalkan') {
        $stmt_update = $conn->prepare("UPDATE pendaftaran_konsultasi SET status_pendaftaran = 'Dibatalkan' WHERE id_pendaftaran = ? AND status_pendaftaran IN ('Menunggu Konfirmasi', 'Dikonfirmasi')");
        if ($stmt_update) {
            $stmt_update->bind_param("i", $id_pendaftaran_aksi);
            if ($stmt_update->execute()) {
                if ($stmt_update->affected_rows > 0) {
                    $stmt_update_pembayaran = $conn->prepare("UPDATE pembayaran SET status_pembayaran = 'Dibatalkan' WHERE id_pendaftaran = ? AND status_pembayaran = 'Belum Lunas'");
                    if($stmt_update_pembayaran){
                        $stmt_update_pembayaran->bind_param("i", $id_pendaftaran_aksi);
                        $stmt_update_pembayaran->execute();
                        $stmt_update_pembayaran->close();
                    }
                    $success_message = "Pendaftaran (ID: $id_pendaftaran_aksi) berhasil dibatalkan.";
                } else {
                    $error_message = "Pendaftaran (ID: $id_pendaftaran_aksi) tidak dapat dibatalkan (mungkin sudah selesai atau status tidak valid).";
                }
            } else {
                $error_message = "Gagal membatalkan pendaftaran: " . $stmt_update->error;
            }
            $stmt_update->close();
        } else {
             $error_message = "Gagal menyiapkan statement pembatalan: " . $conn->error;
        }
    }
    $redirect_params = [];
    if ($success_message) $redirect_params['success'] = urlencode($success_message);
    if ($error_message) $redirect_params['error'] = urlencode($error_message);
    header("Location: kelola_pendaftaran.php" . (!empty($redirect_params) ? '?' . http_build_query($redirect_params) : ''));
    exit;
}

if(isset($_GET['success'])) $success_message = urldecode($_GET['success']);
if(isset($_GET['error'])) $error_message = urldecode($_GET['error']);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_pendaftaran_walkin'])) {
    $id_dokter_walkin = sanitize_input($_POST['id_dokter_walkin']);
    $tanggal_konsultasi_walkin = sanitize_input($_POST['tanggal_konsultasi_walkin']);
    $jam_konsultasi_walkin = sanitize_input($_POST['jam_konsultasi_walkin']);
    $keluhan_walkin = sanitize_input($_POST['keluhan_walkin']);
    $biaya_konsultasi_walkin = isset($_POST['biaya_konsultasi_walkin']) ? floatval(sanitize_input($_POST['biaya_konsultasi_walkin'])) : 0;
    $tipe_pasien = sanitize_input($_POST['tipe_pasien']);
    $id_pasien_walkin = null;

    if (empty($id_dokter_walkin) || empty($tanggal_konsultasi_walkin) || empty($jam_konsultasi_walkin) || empty($keluhan_walkin) || $biaya_konsultasi_walkin < 0) {
        $error_message = "Data dokter, tanggal, jam, keluhan, dan biaya (tidak boleh negatif) wajib diisi untuk pendaftaran walk-in.";
    } else {
        if ($tipe_pasien == 'baru') {
            $nama_lengkap_br = sanitize_input($_POST['nama_lengkap_br']);
            $username_br_input = sanitize_input($_POST['username_br']);
            $username_br = empty($username_br_input) ? generate_unique_username($nama_lengkap_br, $conn) : $username_br_input;
            $password_br_raw = $_POST['password_br'] ?: 'pasien123';
            $email_br = filter_var($_POST['email_br'], FILTER_VALIDATE_EMAIL) ? $_POST['email_br'] : null;
            $telepon_br = sanitize_input($_POST['telepon_br']);
            $alamat_br = sanitize_input($_POST['alamat_br']);
            $tgl_lahir_br = sanitize_input($_POST['tgl_lahir_br']);
            $jenis_kelamin_br = sanitize_input($_POST['jenis_kelamin_br']);

            if (empty($nama_lengkap_br) || empty($username_br) || empty($tgl_lahir_br) || empty($jenis_kelamin_br)) {
                $error_message = "Untuk pasien baru: Nama, Username, Tgl Lahir, dan Jenis Kelamin wajib diisi.";
            } else {
                $stmt_cek_user = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE username = ? OR (email IS NOT NULL AND email = ? AND email != '')");
                $stmt_cek_user->bind_param("ss", $username_br, $email_br);
                $stmt_cek_user->execute();
                if ($stmt_cek_user->get_result()->num_rows > 0) {
                    $error_message = "Username atau Email untuk pasien baru sudah digunakan.";
                }
                $stmt_cek_user->close();

                if (empty($error_message)) {
                    $conn->begin_transaction();
                    try {
                        $hashed_password_br = password_hash($password_br_raw, PASSWORD_DEFAULT);
                        $role_pasien = 'pasien';
                        $stmt_pengguna = $conn->prepare("INSERT INTO pengguna (username, password, nama_lengkap, role, email, nomor_telepon, alamat, status_akun) VALUES (?, ?, ?, ?, ?, ?, ?, 1)");
                        if(!$stmt_pengguna) throw new Exception("Gagal siapkan pengguna baru: " . $conn->error);
                        $stmt_pengguna->bind_param("sssssss", $username_br, $hashed_password_br, $nama_lengkap_br, $role_pasien, $email_br, $telepon_br, $alamat_br);
                        if(!$stmt_pengguna->execute()) throw new Exception("Gagal simpan pengguna baru: " . $stmt_pengguna->error);
                        $id_pengguna_baru = $stmt_pengguna->insert_id;
                        $stmt_pengguna->close();

                        $nomor_rm_br = generate_nomor_rekam_medis($id_pengguna_baru);
                        $stmt_pasien = $conn->prepare("INSERT INTO pasien (id_pengguna, nomor_rekam_medis, tanggal_lahir, jenis_kelamin) VALUES (?, ?, ?, ?)");
                         if(!$stmt_pasien) throw new Exception("Gagal siapkan pasien baru: " . $conn->error);
                        $stmt_pasien->bind_param("isss", $id_pengguna_baru, $nomor_rm_br, $tgl_lahir_br, $jenis_kelamin_br);
                        if(!$stmt_pasien->execute()) throw new Exception("Gagal simpan pasien baru: " . $stmt_pasien->error);
                        $id_pasien_walkin = $stmt_pasien->insert_id;
                        $stmt_pasien->close();
                        $conn->commit();
                        $success_message = "Pasien baru '$nama_lengkap_br' (No.RM: $nomor_rm_br) berhasil didaftarkan. ";
                    } catch (Exception $e) {
                        $conn->rollback();
                        $error_message = "Gagal mendaftarkan pasien baru: " . $e->getMessage();
                    }
                }
            }
        } elseif ($tipe_pasien == 'lama') {
            $nomor_rm_lama = sanitize_input($_POST['nomor_rm_lama']);
            if (empty($nomor_rm_lama)) {
                $error_message = "Nomor Rekam Medis pasien lama wajib diisi.";
            } else {
                $stmt_pasien_lama = $conn->prepare("SELECT id_pasien FROM pasien WHERE nomor_rekam_medis = ?");
                $stmt_pasien_lama->bind_param("s", $nomor_rm_lama);
                $stmt_pasien_lama->execute();
                $result_pasien_lama = $stmt_pasien_lama->get_result();
                if ($result_pasien_lama->num_rows > 0) {
                    $id_pasien_walkin = $result_pasien_lama->fetch_assoc()['id_pasien'];
                } else {
                    $error_message = "Pasien dengan No. RM '$nomor_rm_lama' tidak ditemukan.";
                }
                $stmt_pasien_lama->close();
            }
        }

        if ($id_pasien_walkin && empty($error_message)) {
            $conn->begin_transaction();
            try {
                $status_dikonfirmasi = 'Dikonfirmasi';
                $stmt_pendaftaran = $conn->prepare("INSERT INTO pendaftaran_konsultasi (id_pasien, id_dokter, tanggal_konsultasi, jam_konsultasi, keluhan_utama, status_pendaftaran, dikonfirmasi_oleh) VALUES (?, ?, ?, ?, ?, ?, ?)");
                if(!$stmt_pendaftaran) throw new Exception("Gagal siapkan pendaftaran: " . $conn->error);
                $stmt_pendaftaran->bind_param("iissssi", $id_pasien_walkin, $id_dokter_walkin, $tanggal_konsultasi_walkin, $jam_konsultasi_walkin, $keluhan_walkin, $status_dikonfirmasi, $id_pengguna_resepsionis);
                if(!$stmt_pendaftaran->execute()) throw new Exception("Gagal simpan pendaftaran: " . $stmt_pendaftaran->error);
                $id_pendaftaran_baru = $stmt_pendaftaran->insert_id;
                $stmt_pendaftaran->close();

                $stmt_bayar_walkin = $conn->prepare("INSERT INTO pembayaran (id_pendaftaran, total_biaya, status_pembayaran, diproses_oleh) VALUES (?, ?, 'Belum Lunas', ?)");
                if(!$stmt_bayar_walkin) throw new Exception("Gagal siapkan pembayaran: " . $conn->error);
                $stmt_bayar_walkin->bind_param("idi", $id_pendaftaran_baru, $biaya_konsultasi_walkin, $id_pengguna_resepsionis);
                if(!$stmt_bayar_walkin->execute()) throw new Exception("Gagal simpan pembayaran: " . $stmt_bayar_walkin->error);
                $stmt_bayar_walkin->close();
                $conn->commit();
                $success_message .= "Pendaftaran konsultasi walk-in berhasil disimpan (ID: $id_pendaftaran_baru).";
                 $_POST = array();
            } catch (Exception $e) {
                $conn->rollback();
                $error_message = "Gagal menyimpan pendaftaran konsultasi walk-in: " . $e->getMessage();
            }
        }
    }
}

$pendaftaran_list = [];
$filter_status_val = isset($_GET['filter_status']) ? sanitize_input($_GET['filter_status']) : '';
$filter_tanggal_val = isset($_GET['filter_tanggal']) ? sanitize_input($_GET['filter_tanggal']) : '';
$filter_pasien_val = isset($_GET['filter_pasien']) ? sanitize_input($_GET['filter_pasien']) : '';
$filter_dokter_val = isset($_GET['filter_dokter']) ? sanitize_input($_GET['filter_dokter']) : '';

$sql_pendaftaran_base = "FROM pendaftaran_konsultasi pk
                         JOIN pasien pas ON pk.id_pasien = pas.id_pasien
                         JOIN pengguna pas_pengguna ON pas.id_pengguna = pas_pengguna.id_pengguna
                         JOIN dokter dok ON pk.id_dokter = dok.id_dokter
                         JOIN pengguna dok_pengguna ON dok.id_pengguna = dok_pengguna.id_pengguna
                         LEFT JOIN pembayaran pb ON pk.id_pendaftaran = pb.id_pendaftaran
                         WHERE 1=1 ";
$params_filter = [];
$types_filter = "";

if (!empty($filter_status_val)) { $sql_pendaftaran_base .= " AND pk.status_pendaftaran = ? "; $params_filter[] = $filter_status_val; $types_filter .= "s"; }
if (!empty($filter_tanggal_val)) { $sql_pendaftaran_base .= " AND pk.tanggal_konsultasi = ? "; $params_filter[] = $filter_tanggal_val; $types_filter .= "s"; }
if (!empty($filter_pasien_val)) { $sql_pendaftaran_base .= " AND (pas_pengguna.nama_lengkap LIKE ? OR pas.nomor_rekam_medis LIKE ?) "; $search_like_pasien = "%".$filter_pasien_val."%"; array_push($params_filter, $search_like_pasien, $search_like_pasien); $types_filter .= "ss"; }
if (!empty($filter_dokter_val)) { $sql_pendaftaran_base .= " AND dok_pengguna.nama_lengkap LIKE ? "; $params_filter[] = "%".$filter_dokter_val."%"; $types_filter .= "s"; }

$limit = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

$sql_total = "SELECT COUNT(DISTINCT pk.id_pendaftaran) as total " . $sql_pendaftaran_base;
$stmt_total = $conn->prepare($sql_total);
if($stmt_total){
    if(!empty($params_filter) && !empty($types_filter)) $stmt_total->bind_param($types_filter, ...$params_filter);
    $stmt_total->execute();
    $total_results_arr = $stmt_total->get_result()->fetch_assoc();
    $total_results = $total_results_arr ? $total_results_arr['total'] : 0;
    $total_pages = ceil($total_results / $limit);
    $stmt_total->close();
} else { $total_results = 0; $total_pages = 0; $error_message .= " Gagal hitung total pendaftaran: " . $conn->error; }

$sql_pendaftaran_list = "SELECT pk.id_pendaftaran, pk.tanggal_dibuat, pk.status_pendaftaran,
                            pk.tanggal_konsultasi, pk.jam_konsultasi, pk.keluhan_utama,
                            pas_pengguna.nama_lengkap AS nama_pasien, pas.nomor_rekam_medis,
                            dok_pengguna.nama_lengkap AS nama_dokter,
                            pb.total_biaya, pb.status_pembayaran " . $sql_pendaftaran_base .
                         " ORDER BY pk.tanggal_dibuat DESC LIMIT ? OFFSET ?";
$params_filter_paged = $params_filter;
$params_filter_paged[] = $limit;
$params_filter_paged[] = $offset;
$types_filter_paged = $types_filter . "ii";

$stmt_pendaftaran_list = $conn->prepare($sql_pendaftaran_list);
if($stmt_pendaftaran_list) {
    if(!empty($params_filter_paged) && !empty($types_filter_paged)) $stmt_pendaftaran_list->bind_param($types_filter_paged, ...$params_filter_paged);
    elseif (empty($params_filter_paged) && !empty($types_filter_paged) && $types_filter_paged == "ii"){ // Hanya limit dan offset
         $stmt_pendaftaran_list->bind_param($types_filter_paged, $limit, $offset);
    }
    $stmt_pendaftaran_list->execute();
    $result_pendaftaran_list = $stmt_pendaftaran_list->get_result();
    while ($row = $result_pendaftaran_list->fetch_assoc()) $pendaftaran_list[] = $row;
    $stmt_pendaftaran_list->close();
} else { $error_message .= " Gagal ambil daftar pendaftaran: " . $conn->error; }

$dokter_options = [];
$result_dokter_opt = $conn->query("SELECT d.id_dokter, p.nama_lengkap, d.spesialisasi FROM dokter d JOIN pengguna p ON d.id_pengguna = p.id_pengguna WHERE p.role='dokter' AND p.status_akun=1 ORDER BY p.nama_lengkap");
if($result_dokter_opt) { while($row = $result_dokter_opt->fetch_assoc()) $dokter_options[] = $row; }

if($conn) $conn->close();
?>

<?php $page_title = "Kelola Pendaftaran Konsultasi"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Kelola Pendaftaran Konsultasi</h1>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success_message; ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error_message; ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>

<button class="btn btn-lg btn-success mb-3" type="button" data-toggle="collapse" data-target="#formPendaftaranWalkin" aria-expanded="<?php echo (isset($_POST['submit_pendaftaran_walkin']) && !empty($error_message)) ? 'true' : 'false'; ?>" aria-controls="formPendaftaranWalkin">
    <i class="fas fa-plus-circle"></i> Buat Pendaftaran Walk-in / Pasien Baru
</button>

<div class="collapse mb-4 <?php echo (isset($_POST['submit_pendaftaran_walkin']) && !empty($error_message)) ? 'show' : ''; ?>" id="formPendaftaranWalkin">
    <div class="card card-body">
        <h5 class="card-title">Formulir Pendaftaran Pasien Walk-in</h5>
        <form action="kelola_pendaftaran.php" method="POST">
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="tipe_pasien">Tipe Pasien <span class="text-danger">*</span></label>
                    <select id="tipe_pasien" name="tipe_pasien" class="form-control" required onchange="togglePasienFields()">
                        <option value="baru" <?php echo (isset($_POST['tipe_pasien']) && $_POST['tipe_pasien'] == 'baru') ? 'selected' : ((!isset($_POST['tipe_pasien'])) ? 'selected' : ''); ?>>Pasien Baru</option>
                        <option value="lama" <?php echo (isset($_POST['tipe_pasien']) && $_POST['tipe_pasien'] == 'lama') ? 'selected' : ''; ?>>Pasien Lama (via No. RM)</option>
                    </select>
                </div>
            </div>
            <div id="pasienBaruFields">
                <h6>Data Pasien Baru</h6>
                <div class="form-row">
                    <div class="form-group col-md-6"><label for="nama_lengkap_br">Nama Lengkap <span class="text-danger">*</span></label><input type="text" class="form-control" id="nama_lengkap_br" name="nama_lengkap_br" value="<?php echo isset($_POST['nama_lengkap_br']) ? htmlspecialchars($_POST['nama_lengkap_br']) : ''; ?>"></div>
                    <div class="form-group col-md-6"><label for="username_br">Username <span class="text-danger">*</span></label><input type="text" class="form-control" id="username_br" name="username_br" placeholder="Kosongkan untuk auto-generate" value="<?php echo isset($_POST['username_br']) ? htmlspecialchars($_POST['username_br']) : ''; ?>"><small class="form-text text-muted">Kosongkan untuk dibuat otomatis, atau isi manual.</small></div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6"><label for="password_br">Password</label><input type="password" class="form-control" id="password_br" name="password_br" placeholder="Default: pasien123"><small class="form-text text-muted">Min. 6 karakter jika diisi.</small></div>
                    <div class="form-group col-md-6"><label for="email_br">Email</label><input type="email" class="form-control" id="email_br" name="email_br" value="<?php echo isset($_POST['email_br']) ? htmlspecialchars($_POST['email_br']) : ''; ?>"></div>
                </div>
                 <div class="form-row">
                    <div class="form-group col-md-6"><label for="telepon_br">No. Telepon</label><input type="tel" class="form-control" id="telepon_br" name="telepon_br" value="<?php echo isset($_POST['telepon_br']) ? htmlspecialchars($_POST['telepon_br']) : ''; ?>"></div>
                    <div class="form-group col-md-6"><label for="tgl_lahir_br">Tanggal Lahir <span class="text-danger">*</span></label><input type="date" class="form-control" id="tgl_lahir_br" name="tgl_lahir_br" value="<?php echo isset($_POST['tgl_lahir_br']) ? htmlspecialchars($_POST['tgl_lahir_br']) : ''; ?>"></div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6"><label for="jenis_kelamin_br">Jenis Kelamin <span class="text-danger">*</span></label><select id="jenis_kelamin_br" name="jenis_kelamin_br" class="form-control"><option value="">Pilih...</option><option value="Laki-laki" <?php echo (isset($_POST['jenis_kelamin_br']) && $_POST['jenis_kelamin_br'] == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option><option value="Perempuan" <?php echo (isset($_POST['jenis_kelamin_br']) && $_POST['jenis_kelamin_br'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option></select></div>
                    <div class="form-group col-md-6"><label for="alamat_br">Alamat</label><textarea class="form-control" id="alamat_br" name="alamat_br" rows="1"><?php echo isset($_POST['alamat_br']) ? htmlspecialchars($_POST['alamat_br']) : ''; ?></textarea></div>
                </div>
            </div>
            <div id="pasienLamaFields" style="display:none;">
                 <h6>Data Pasien Lama</h6>
                <div class="form-group"><label for="nomor_rm_lama">Nomor Rekam Medis Pasien <span class="text-danger">*</span></label><input type="text" class="form-control" id="nomor_rm_lama" name="nomor_rm_lama" placeholder="Masukkan No. RM" value="<?php echo isset($_POST['nomor_rm_lama']) ? htmlspecialchars($_POST['nomor_rm_lama']) : ''; ?>"></div>
            </div>
            <hr><h6>Detail Konsultasi</h6>
             <div class="form-row">
                <div class="form-group col-md-6"><label for="id_dokter_walkin">Dokter Tujuan <span class="text-danger">*</span></label><select id="id_dokter_walkin" name="id_dokter_walkin" class="form-control" required><option value="">Pilih Dokter...</option><?php foreach ($dokter_options as $dok): ?><option value="<?php echo $dok['id_dokter']; ?>" <?php echo (isset($_POST['id_dokter_walkin']) && $_POST['id_dokter_walkin'] == $dok['id_dokter']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($dok['nama_lengkap']) . " (".htmlspecialchars($dok['spesialisasi']).")"; ?></option><?php endforeach; ?></select></div>
                <div class="form-group col-md-6"><label for="biaya_konsultasi_walkin">Biaya Konsultasi (Rp) <span class="text-danger">*</span></label><input type="number" class="form-control" id="biaya_konsultasi_walkin" name="biaya_konsultasi_walkin" value="<?php echo isset($_POST['biaya_konsultasi_walkin']) ? htmlspecialchars($_POST['biaya_konsultasi_walkin']) : '0'; ?>" min="0" required></div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6"><label for="tanggal_konsultasi_walkin">Tanggal Konsultasi <span class="text-danger">*</span></label><input type="date" class="form-control" id="tanggal_konsultasi_walkin" name="tanggal_konsultasi_walkin" value="<?php echo isset($_POST['tanggal_konsultasi_walkin']) ? htmlspecialchars($_POST['tanggal_konsultasi_walkin']) : date('Y-m-d'); ?>" required></div>
                <div class="form-group col-md-6"><label for="jam_konsultasi_walkin">Jam Konsultasi <span class="text-danger">*</span></label><input type="time" class="form-control" id="jam_konsultasi_walkin" name="jam_konsultasi_walkin" value="<?php echo isset($_POST['jam_konsultasi_walkin']) ? htmlspecialchars($_POST['jam_konsultasi_walkin']) : date('H:i'); ?>" required></div>
            </div>
            <div class="form-group"><label for="keluhan_walkin">Keluhan Utama <span class="text-danger">*</span></label><textarea class="form-control" id="keluhan_walkin" name="keluhan_walkin" rows="3" required><?php echo isset($_POST['keluhan_walkin']) ? htmlspecialchars($_POST['keluhan_walkin']) : ''; ?></textarea></div>
            <button type="submit" name="submit_pendaftaran_walkin" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Pendaftaran Walk-in</button>
        </form>
    </div>
</div>
<script>
function togglePasienFields() {
    var tipe = document.getElementById('tipe_pasien').value;
    var baruFields = document.getElementById('pasienBaruFields');
    var lamaFields = document.getElementById('pasienLamaFields');
    var fieldIdsBaru = ['nama_lengkap_br', 'username_br', 'tgl_lahir_br', 'jenis_kelamin_br'];
    var noRmLama = document.getElementById('nomor_rm_lama');

    if (tipe === 'baru') {
        baruFields.style.display = 'block';
        lamaFields.style.display = 'none';
        fieldIdsBaru.forEach(id => { if(document.getElementById(id)) document.getElementById(id).required = true; });
        if(noRmLama) noRmLama.required = false;
    } else { // lama
        baruFields.style.display = 'none';
        lamaFields.style.display = 'block';
        fieldIdsBaru.forEach(id => { if(document.getElementById(id)) document.getElementById(id).required = false; });
        if(noRmLama) noRmLama.required = true;
    }
}
document.addEventListener('DOMContentLoaded', function() {
    togglePasienFields(); // Panggil saat load untuk set initial state
    // Pastikan alert bisa di-dismiss
    $('.alert .close').on('click', function(){ $(this).parent().alert('close'); });
});
</script>

<div class="card mb-3">
    <div class="card-header"><h6><i class="fas fa-filter"></i> Filter Daftar Pendaftaran</h6></div>
    <div class="card-body">
        <form action="kelola_pendaftaran.php" method="GET" class="form-row align-items-end">
            <div class="form-group col-md-3"><label for="filter_tanggal">Tgl Konsul</label><input type="date" name="filter_tanggal" id="filter_tanggal" class="form-control form-control-sm" value="<?php echo htmlspecialchars($filter_tanggal_val); ?>"></div>
            <div class="form-group col-md-2"><label for="filter_status">Status</label><select name="filter_status" id="filter_status" class="form-control form-control-sm"><option value="">Semua</option><option value="Menunggu Konfirmasi" <?php echo ($filter_status_val == 'Menunggu Konfirmasi') ? 'selected' : ''; ?>>Menunggu Konfirmasi</option><option value="Dikonfirmasi" <?php echo ($filter_status_val == 'Dikonfirmasi') ? 'selected' : ''; ?>>Dikonfirmasi</option><option value="Selesai" <?php echo ($filter_status_val == 'Selesai') ? 'selected' : ''; ?>>Selesai</option><option value="Dibatalkan" <?php echo ($filter_status_val == 'Dibatalkan') ? 'selected' : ''; ?>>Dibatalkan</option></select></div>
            <div class="form-group col-md-3"><label for="filter_pasien">Pasien/No.RM</label><input type="text" name="filter_pasien" id="filter_pasien" class="form-control form-control-sm" value="<?php echo htmlspecialchars($filter_pasien_val); ?>" placeholder="Cari..."></div>
            <div class="form-group col-md-2"><label for="filter_dokter">Dokter</label><input type="text" name="filter_dokter" id="filter_dokter" class="form-control form-control-sm" value="<?php echo htmlspecialchars($filter_dokter_val); ?>" placeholder="Cari..."></div>
            <div class="form-group col-md-2"><button type="submit" class="btn btn-primary btn-sm mr-1"><i class="fas fa-search"></i></button><a href="kelola_pendaftaran.php" class="btn btn-secondary btn-sm"><i class="fas fa-sync-alt"></i></a></div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header"><h6><i class="fas fa-list-alt"></i> Daftar Pendaftaran (Ditemukan: <?php echo $total_results; ?>)</h6></div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-sm">
                <thead class="thead-light"><tr><th>ID</th><th>Tgl Daftar</th><th>Pasien (No.RM)</th><th>Dokter</th><th>Jadwal Konsul</th><th>Keluhan</th><th>Biaya</th><th>Status Daftar</th><th>Status Bayar</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php if (!empty($pendaftaran_list)): ?>
                        <?php foreach ($pendaftaran_list as $p): ?>
                            <tr>
                                <td><?php echo $p['id_pendaftaran']; ?></td>
                                <td><?php echo htmlspecialchars(format_tanggal_indonesia($p['tanggal_dibuat'], true)); ?></td>
                                <td><?php echo htmlspecialchars($p['nama_pasien']); ?> <br><small>(<?php echo htmlspecialchars($p['nomor_rekam_medis']); ?>)</small></td>
                                <td><?php echo htmlspecialchars($p['nama_dokter']); ?></td>
                                <td><?php echo htmlspecialchars(format_tanggal_indonesia($p['tanggal_konsultasi'])); ?> <br><small><?php echo htmlspecialchars(date("H:i", strtotime($p['jam_konsultasi']))); ?></small></td>
                                <td><small><?php echo nl2br(htmlspecialchars(substr($p['keluhan_utama'], 0, 70) . (strlen($p['keluhan_utama']) > 70 ? '...' : ''))); ?></small></td>
                                <td class="text-right"><?php echo htmlspecialchars(number_format($p['total_biaya'] ?: 0, 0, ',', '.')); ?></td>
                                <td>
                                    <?php
                                    $status_class = 'badge-secondary';
                                    if ($p['status_pendaftaran'] == 'Menunggu Konfirmasi') $status_class = 'badge-warning';
                                    elseif ($p['status_pendaftaran'] == 'Dikonfirmasi') $status_class = 'badge-info';
                                    elseif ($p['status_pendaftaran'] == 'Selesai') $status_class = 'badge-success';
                                    elseif ($p['status_pendaftaran'] == 'Dibatalkan') $status_class = 'badge-danger';
                                    ?>
                                    <span class="badge <?php echo $status_class; ?>"><?php echo htmlspecialchars($p['status_pendaftaran']); ?></span>
                                </td>
                                 <td>
                                    <?php
                                    $status_bayar_class = 'badge-secondary';
                                    if ($p['status_pembayaran'] == 'Lunas') $status_bayar_class = 'badge-success';
                                    elseif ($p['status_pembayaran'] == 'Belum Lunas') $status_bayar_class = 'badge-danger';
                                    elseif ($p['status_pembayaran'] == 'Dibatalkan') $status_bayar_class = 'badge-light border text-dark';
                                    ?>
                                    <span class="badge <?php echo $status_bayar_class; ?>"><?php echo htmlspecialchars($p['status_pembayaran'] ?: '-'); ?></span>
                                 </td>
                                <td class="action-buttons text-center">
                                    <?php if ($p['status_pendaftaran'] == 'Menunggu Konfirmasi'): ?>
                                        <a href="kelola_pendaftaran.php?action=konfirmasi&id_pendaftaran=<?php echo $p['id_pendaftaran']; ?>" class="btn btn-success btn-sm my-1 py-0 px-1" title="Konfirmasi" onclick="return confirm('Anda yakin ingin mengkonfirmasi pendaftaran ID <?php echo $p['id_pendaftaran']; ?>?')"><i class="fas fa-check"></i></a>
                                        <a href="kelola_pendaftaran.php?action=batalkan&id_pendaftaran=<?php echo $p['id_pendaftaran']; ?>" class="btn btn-danger btn-sm my-1 py-0 px-1" title="Batalkan" onclick="return confirm('Anda yakin ingin membatalkan pendaftaran ID <?php echo $p['id_pendaftaran']; ?>?')"><i class="fas fa-times"></i></a>
                                    <?php elseif ($p['status_pendaftaran'] == 'Dikonfirmasi'): ?>
                                         <a href="kelola_pendaftaran.php?action=batalkan&id_pendaftaran=<?php echo $p['id_pendaftaran']; ?>" class="btn btn-danger btn-sm my-1 py-0 px-1" title="Batalkan" onclick="return confirm('Anda yakin ingin membatalkan pendaftaran ID <?php echo $p['id_pendaftaran']; ?>?')"><i class="fas fa-times"></i></a>
                                    <?php else: ?>
                                        <small><em>-</em></small> <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="10" class="text-center">Tidak ada data pendaftaran yang ditemukan.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($total_pages > 1): ?>
        <nav><ul class="pagination justify-content-center mt-3">
            <?php if ($page > 1): ?><li class="page-item"><a class="page-link" href="?page=<?php echo $page - 1; ?>&filter_status=<?php echo urlencode($filter_status_val); ?>&filter_tanggal=<?php echo urlencode($filter_tanggal_val); ?>&filter_pasien=<?php echo urlencode($filter_pasien_val); ?>&filter_dokter=<?php echo urlencode($filter_dokter_val); ?>">Prev</a></li><?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?><li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>"><a class="page-link" href="?page=<?php echo $i; ?>&filter_status=<?php echo urlencode($filter_status_val); ?>&filter_tanggal=<?php echo urlencode($filter_tanggal_val); ?>&filter_pasien=<?php echo urlencode($filter_pasien_val); ?>&filter_dokter=<?php echo urlencode($filter_dokter_val); ?>"><?php echo $i; ?></a></li><?php endfor; ?>
            <?php if ($page < $total_pages): ?><li class="page-item"><a class="page-link" href="?page=<?php echo $page + 1; ?>&filter_status=<?php echo urlencode($filter_status_val); ?>&filter_tanggal=<?php echo urlencode($filter_tanggal_val); ?>&filter_pasien=<?php echo urlencode($filter_pasien_val); ?>&filter_dokter=<?php echo urlencode($filter_dokter_val); ?>">Next</a></li><?php endif; ?>
        </ul></nav>
        <?php endif; ?>
    </div>
</div>
<style>
    /* Warna hijau kesehatan */
    :root {
        --hijau-utama: #28a745;
        --hijau-muda: #1cc88a;
        --hijau-teal: #20c997;
        --hijau-lembut: #a8e6cf;
        --abu-tekstil: #5a5c69;
    }

    .card.border-left-primary { border-left: .25rem solid var(--hijau-utama) !important; }
    .card.border-left-success { border-left: .25rem solid var(--hijau-muda) !important; }
    .card.border-left-info   { border-left: .25rem solid var(--hijau-teal) !important; }
    .card.border-left-warning { border-left: .25rem solid #ffc107 !important; }
    .card.border-left-danger  { border-left: .25rem solid #dc3545 !important; }
    .card.border-left-secondary { border-left: .25rem solidrgb(0, 0, 0) !important; }

    .text-primary { color: var(--hijau-utama) !important; }
    .text-success { color: var(--hijau-muda) !important; }
    .text-info    { color: var(--hijau-teal) !important; }
    .text-secondary { color:rgb(0, 1, 2) !important; }

    .btn-primary { background-color: var(--hijau-utama); border-color: var(--hijau-utama); }
    .btn-primary:hover { background-color: #218838; border-color: #1e7e34; }

    .btn-success { background-color: var(--hijau-muda); border-color: var(--hijau-muda); }
    .btn-info { background-color: var(--hijau-teal); border-color: var(--hijau-teal); }

    .text-gray-300 { color: #d4edda !important; }
    .text-gray-800 { color: var(--abu-tekstil) !important; }

    .shadow {
        box-shadow: 0 .15rem 1.75rem 0 rgba(40, 167, 69, 0.15)!important;
    }

    /* Sidebar tetap dengan latar hijau tua */
.sidebar {
    background-color: #14532d !important;  /* Hijau tua solid */
    color: white;
}

/* Untuk item sidebar (jika menggunakan class nav-item dan nav-link) */
.sidebar .nav-item .nav-link {
    color: #ffffff !important;
}

.sidebar .nav-item .nav-link:hover {
    background-color: #1e7e34 !important; /* Hijau hover */
    color: #ffffff !important;
}

/* Aktif link highlight */
.sidebar .nav-item.active .nav-link {
    background-color: #1cc88a !important; /* Hijau muda untuk highlight */
    color: #ffffff !important;
}
/* Navbar atas hijau muda */
.navbar {
    background-color: #1cc88a !important;
    color: white !important;
}

/* Teks di dalam navbar */
.navbar .nav-link,
.navbar .navbar-brand,
.navbar .dropdown-toggle {
    color: #ffffff !important;
}

/* Hover efek navbar */
.navbar .nav-link:hover {
    color: #f8f9fc !important;
}

</style>
<?php include '../includes/footer.php'; ?>