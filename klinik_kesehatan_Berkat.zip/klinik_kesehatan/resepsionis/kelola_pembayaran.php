<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('resepsionis'); // Pastikan hanya resepsionis yang bisa akses

$conn = connect_db();
$id_pengguna_resepsionis = $_SESSION['id_pengguna']; // ID resepsionis yang memproses
$error_message = '';
$success_message = '';

// --- PENANGANAN AKSI: PROSES PEMBAYARAN (TANDAI LUNAS) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['proses_pembayaran'])) {
    $id_pembayaran_update = isset($_POST['id_pembayaran_update']) ? intval($_POST['id_pembayaran_update']) : 0;
    $metode_pembayaran_input = isset($_POST['metode_pembayaran']) ? sanitize_input($_POST['metode_pembayaran']) : '';
    // total_biaya_aktual diambil dari form modal, yang nilainya di-set dari data-totalbiaya
    // Jika Anda ingin resepsionis bisa mengubah jumlah ini saat pembayaran, hapus atribut 'readonly' pada input di modal.
    $total_biaya_aktual = isset($_POST['total_biaya_aktual']) ? floatval($_POST['total_biaya_aktual']) : 0;

    if (empty($metode_pembayaran_input)) {
        $error_message = "Metode pembayaran wajib dipilih.";
    } elseif ($id_pembayaran_update <= 0) {
        $error_message = "ID Pembayaran tidak valid atau tidak terkirim dari form.";
    } elseif ($total_biaya_aktual < 0) { // Biaya tidak boleh negatif
        $error_message = "Total biaya aktual tidak boleh negatif.";
    } else {
        // Cek ulang kondisi pembayaran sebelum update
        $stmt_cek = $conn->prepare("SELECT pb.id_pembayaran
                                   FROM pembayaran pb
                                   JOIN pendaftaran_konsultasi pk ON pb.id_pendaftaran = pk.id_pendaftaran
                                   WHERE pb.id_pembayaran = ? AND pb.status_pembayaran = 'Belum Lunas' AND pk.status_pendaftaran = 'Selesai'");
        if ($stmt_cek) {
            $stmt_cek->bind_param("i", $id_pembayaran_update);
            $stmt_cek->execute();
            $result_cek = $stmt_cek->get_result();

            if ($result_cek->num_rows > 0) {
                $tanggal_pembayaran_sekarang = date("Y-m-d H:i:s");

                $stmt_update = $conn->prepare("UPDATE pembayaran SET
                                                status_pembayaran = 'Lunas',
                                                metode_pembayaran = ?,
                                                tanggal_pembayaran = ?,
                                                diproses_oleh = ?,
                                                total_biaya = ?
                                              WHERE id_pembayaran = ?");
                if ($stmt_update) {
                    $stmt_update->bind_param("ssidi",
                        $metode_pembayaran_input,
                        $tanggal_pembayaran_sekarang,
                        $id_pengguna_resepsionis,
                        $total_biaya_aktual,
                        $id_pembayaran_update
                    );

                    if ($stmt_update->execute()) {
                        $success_message = "Pembayaran (ID: $id_pembayaran_update) berhasil diproses dan ditandai LUNAS.";
                    } else {
                        $error_message = "Gagal memproses pembayaran (execute): " . $stmt_update->error;
                    }
                    $stmt_update->close();
                } else {
                    $error_message = "Gagal menyiapkan statement update pembayaran: " . $conn->error;
                }
            } else {
                $error_message = "Pembayaran (ID: $id_pembayaran_update) tidak ditemukan, statusnya bukan 'Belum Lunas', atau konsultasi terkait belum 'Selesai'.";
            }
            $stmt_cek->close();
        } else {
            $error_message = "Gagal melakukan pengecekan pembayaran: " . $conn->error;
        }
    }
}


// --- FETCHING DATA UNTUK DAFTAR PEMBAYARAN ---
$pembayaran_list = [];
// Default filter menampilkan yang 'Belum Lunas' untuk konsultasi 'Selesai'
$filter_status_bayar_val = isset($_GET['filter_status_bayar']) ? sanitize_input($_GET['filter_status_bayar']) : 'Belum Lunas';
$filter_tanggal_konsul_val = isset($_GET['filter_tanggal_konsul']) ? sanitize_input($_GET['filter_tanggal_konsul']) : '';
$filter_pasien_bayar_val = isset($_GET['filter_pasien_bayar']) ? sanitize_input($_GET['filter_pasien_bayar']) : '';

$sql_pembayaran_list = "SELECT
                            pb.id_pembayaran, pb.total_biaya, pb.status_pembayaran, pb.metode_pembayaran, pb.tanggal_pembayaran,
                            pk.id_pendaftaran, pk.tanggal_konsultasi, pk.jam_konsultasi, pk.status_pendaftaran AS status_konsultasi,
                            pas_pengguna.nama_lengkap AS nama_pasien, pas.nomor_rekam_medis,
                            dok_pengguna.nama_lengkap AS nama_dokter,
                            res_pengguna.nama_lengkap AS nama_resepsionis_bayar
                         FROM pembayaran pb
                         JOIN pendaftaran_konsultasi pk ON pb.id_pendaftaran = pk.id_pendaftaran
                         JOIN pasien pas ON pk.id_pasien = pas.id_pasien
                         JOIN pengguna pas_pengguna ON pas.id_pengguna = pas_pengguna.id_pengguna
                         JOIN dokter dok ON pk.id_dokter = dok.id_dokter
                         JOIN pengguna dok_pengguna ON dok.id_pengguna = dok_pengguna.id_pengguna
                         LEFT JOIN pengguna res_pengguna ON pb.diproses_oleh = res_pengguna.id_pengguna
                         WHERE 1=1 "; // Dimulai dengan kondisi true

$params_filter = [];
$types_filter = "";

// Hanya tampilkan yang status konsultasinya 'Selesai' jika filter status pembayaran bukan 'Dibatalkan'
// Atau jika statusnya 'Dibatalkan', bisa jadi konsultasinya juga batal.
if ($filter_status_bayar_val == 'Belum Lunas' || $filter_status_bayar_val == 'Lunas') {
    $sql_pembayaran_list .= " AND pk.status_pendaftaran = 'Selesai' ";
}


if (!empty($filter_status_bayar_val)) {
    $sql_pembayaran_list .= " AND pb.status_pembayaran = ? ";
    $params_filter[] = $filter_status_bayar_val;
    $types_filter .= "s";
}
if (!empty($filter_tanggal_konsul_val)) {
    $sql_pembayaran_list .= " AND pk.tanggal_konsultasi = ? ";
    $params_filter[] = $filter_tanggal_konsul_val;
    $types_filter .= "s";
}
if (!empty($filter_pasien_bayar_val)) {
    $sql_pembayaran_list .= " AND (pas_pengguna.nama_lengkap LIKE ? OR pas.nomor_rekam_medis LIKE ?) ";
    $search_like_pasien = "%" . $filter_pasien_bayar_val . "%";
    array_push($params_filter, $search_like_pasien, $search_like_pasien);
    $types_filter .= "ss";
}
$sql_pembayaran_list .= " ORDER BY CASE pb.status_pembayaran WHEN 'Belum Lunas' THEN 1 WHEN 'Lunas' THEN 2 ELSE 3 END, pk.tanggal_konsultasi DESC, pk.jam_konsultasi DESC";


// Paginasi
$limit = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

$temp_sql_for_total = preg_replace('/SELECT.*?FROM/s', 'SELECT COUNT(DISTINCT pb.id_pembayaran) as total FROM', $sql_pembayaran_list, 1);
$stmt_total_bayar = $conn->prepare($temp_sql_for_total);
if($stmt_total_bayar){
    if(!empty($params_filter)) {
        $stmt_total_bayar->bind_param($types_filter, ...$params_filter);
    }
    $stmt_total_bayar->execute();
    $total_results_arr = $stmt_total_bayar->get_result()->fetch_assoc();
    $total_results = $total_results_arr ? $total_results_arr['total'] : 0;
    $total_pages = ceil($total_results / $limit);
    $stmt_total_bayar->close();
} else {
    $total_results = 0;
    $total_pages = 0;
    $error_message .= " Gagal menghitung total data pembayaran: " . $conn->error;
}

$sql_pembayaran_list_paged = $sql_pembayaran_list . " LIMIT ? OFFSET ?";
$params_filter_paged = $params_filter;
$params_filter_paged[] = $limit;
$params_filter_paged[] = $offset;
$types_filter_paged = $types_filter . "ii";

$stmt_pembayaran_list = $conn->prepare($sql_pembayaran_list_paged);
if($stmt_pembayaran_list) {
    if(!empty($params_filter_paged) && !empty($types_filter_paged)) { // Pastikan ada parameter untuk di-bind
        $stmt_pembayaran_list->bind_param($types_filter_paged, ...$params_filter_paged);
    } elseif (empty($params_filter_paged) && !empty($types_filter_paged)){
        // Ini seharusnya tidak terjadi, jika types ada, params juga harusnya ada
    }
    $stmt_pembayaran_list->execute();
    $result_pembayaran_list = $stmt_pembayaran_list->get_result();
    while ($row = $result_pembayaran_list->fetch_assoc()) {
        $pembayaran_list[] = $row;
    }
    $stmt_pembayaran_list->close();
} else {
    $error_message .= " Gagal mengambil daftar pembayaran: " . $conn->error;
}

if($conn) $conn->close();
?>

<?php $page_title = "Kelola Pembayaran"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Kelola Pembayaran Konsultasi</h1>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success_message; ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
     <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error_message; ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>


<div class="card mb-3">
    <div class="card-header">
        <h6><i class="fas fa-filter"></i> Filter Pembayaran</h6>
    </div>
    <div class="card-body">
        <form action="kelola_pembayaran.php" method="GET" class="form-row align-items-end">
            <div class="form-group col-md-3">
                <label for="filter_tanggal_konsul">Tanggal Konsultasi</label>
                <input type="date" name="filter_tanggal_konsul" id="filter_tanggal_konsul" class="form-control form-control-sm" value="<?php echo htmlspecialchars($filter_tanggal_konsul_val); ?>">
            </div>
            <div class="form-group col-md-3">
                <label for="filter_status_bayar">Status Pembayaran</label>
                <select name="filter_status_bayar" id="filter_status_bayar" class="form-control form-control-sm">
                    <option value="">Semua Status</option>
                    <option value="Belum Lunas" <?php echo ($filter_status_bayar_val == 'Belum Lunas') ? 'selected' : ''; ?>>Belum Lunas</option>
                    <option value="Lunas" <?php echo ($filter_status_bayar_val == 'Lunas') ? 'selected' : ''; ?>>Lunas</option>
                    <option value="Dibatalkan" <?php echo ($filter_status_bayar_val == 'Dibatalkan') ? 'selected' : ''; ?>>Dibatalkan</option>
                </select>
            </div>
            <div class="form-group col-md-3">
                <label for="filter_pasien_bayar">Nama Pasien / No.RM</label>
                <input type="text" name="filter_pasien_bayar" id="filter_pasien_bayar" class="form-control form-control-sm" value="<?php echo htmlspecialchars($filter_pasien_bayar_val); ?>" placeholder="Cari pasien...">
            </div>
            <div class="form-group col-md-3">
                <button type="submit" class="btn btn-primary btn-sm mr-2"><i class="fas fa-search"></i> Filter</button>
                <a href="kelola_pembayaran.php" class="btn btn-secondary btn-sm"><i class="fas fa-sync-alt"></i> Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h6><i class="fas fa-file-invoice"></i> Daftar Pembayaran (Ditemukan: <?php echo $total_results; ?>)</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-sm">
                <thead class="thead-light">
                    <tr>
                        <th>ID Bayar</th>
                        <th>Tgl Konsul</th>
                        <th>Pasien (No.RM)</th>
                        <th>Dokter</th>
                        <th>Total Biaya (Rp)</th>
                        <th>Status Bayar</th>
                        <th>Metode</th>
                        <th>Tgl Bayar</th>
                        <th>Diproses Oleh</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($pembayaran_list)): ?>
                        <?php foreach ($pembayaran_list as $pb): ?>
                            <tr>
                                <td><?php echo $pb['id_pembayaran']; ?></td>
                                <td><?php echo htmlspecialchars(format_tanggal_indonesia($pb['tanggal_konsultasi'])); ?> <br><small><?php echo htmlspecialchars(date("H:i", strtotime($pb['jam_konsultasi']))); ?></small></td>
                                <td><?php echo htmlspecialchars($pb['nama_pasien']); ?> <br><small>(<?php echo htmlspecialchars($pb['nomor_rekam_medis']); ?>)</small></td>
                                <td><?php echo htmlspecialchars($pb['nama_dokter']); ?></td>
                                <td class="text-right"><?php echo htmlspecialchars(number_format($pb['total_biaya'], 0, ',', '.')); ?></td>
                                <td>
                                    <?php
                                    $status_bayar_class = '';
                                    if ($pb['status_pembayaran'] == 'Lunas') $status_bayar_class = 'badge badge-success';
                                    elseif ($pb['status_pembayaran'] == 'Belum Lunas') $status_bayar_class = 'badge badge-danger';
                                    elseif ($pb['status_pembayaran'] == 'Dibatalkan') $status_bayar_class = 'badge badge-light text-dark border';
                                    else $status_bayar_class = 'badge badge-secondary';
                                    ?>
                                    <span class="<?php echo $status_bayar_class; ?>"><?php echo htmlspecialchars($pb['status_pembayaran']); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($pb['metode_pembayaran'] ?: '-'); ?></td>
                                <td><?php echo $pb['tanggal_pembayaran'] ? htmlspecialchars(format_tanggal_indonesia($pb['tanggal_pembayaran'], true)) : '-'; ?></td>
                                <td><?php echo htmlspecialchars($pb['nama_resepsionis_bayar'] ?: '-'); ?></td>
                                <td class="action-buttons text-center">
                                    <?php if ($pb['status_pembayaran'] == 'Belum Lunas' && $pb['status_konsultasi'] == 'Selesai'): ?>
                                        <button type="button" class="btn btn-success btn-sm my-1" data-toggle="modal" data-target="#modalProsesPembayaran"
                                                data-idpembayaran="<?php echo $pb['id_pembayaran']; ?>"
                                                data-namapasien="<?php echo htmlspecialchars($pb['nama_pasien']); ?>"
                                                data-totalbiaya="<?php echo $pb['total_biaya']; ?>"
                                                title="Proses Pembayaran Pasien">
                                            <i class="fas fa-cash-register"></i> Proses
                                        </button>
                                    <?php elseif($pb['status_pembayaran'] == 'Lunas'): ?>
                                        <i class="fas fa-check-circle text-success" title="Sudah Lunas"></i>
                                    <?php else: ?>
                                        <small><em>-</em></small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center">Tidak ada data pembayaran yang ditemukan sesuai filter.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mt-3">
                <?php if ($page > 1): ?>
                    <li class="page-item"><a class="page-link" href="?page=<?php echo $page - 1; ?>&filter_status_bayar=<?php echo urlencode($filter_status_bayar_val); ?>&filter_tanggal_konsul=<?php echo urlencode($filter_tanggal_konsul_val); ?>&filter_pasien_bayar=<?php echo urlencode($filter_pasien_bayar_val); ?>">Prev</a></li>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&filter_status_bayar=<?php echo urlencode($filter_status_bayar_val); ?>&filter_tanggal_konsul=<?php echo urlencode($filter_tanggal_konsul_val); ?>&filter_pasien_bayar=<?php echo urlencode($filter_pasien_bayar_val); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <?php if ($page < $total_pages): ?>
                    <li class="page-item"><a class="page-link" href="?page=<?php echo $page + 1; ?>&filter_status_bayar=<?php echo urlencode($filter_status_bayar_val); ?>&filter_tanggal_konsul=<?php echo urlencode($filter_tanggal_konsul_val); ?>&filter_pasien_bayar=<?php echo urlencode($filter_pasien_bayar_val); ?>">Next</a></li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>

<div class="modal fade" id="modalProsesPembayaran" tabindex="-1" role="dialog" aria-labelledby="modalProsesPembayaranLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <form action="kelola_pembayaran.php" method="POST" id="formProsesPembayaran">
        <div class="modal-header">
          <h5 class="modal-title" id="modalProsesPembayaranLabel">Proses Pembayaran untuk: <strong id="namaPasienModal"></strong></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id_pembayaran_update" id="idPembayaranUpdateModal">
          <div class="form-group">
            <label for="totalBiayaModal">Total Biaya Tagihan (Rp)</label>
            <input type="number" class="form-control" id="totalBiayaModal" name="total_biaya_aktual" readonly required step="any">
          </div>
          <div class="form-group">
            <label for="metodePembayaranModal">Metode Pembayaran <span class="text-danger">*</span></label>
            <select name="metode_pembayaran" id="metodePembayaranModal" class="form-control" required>
                <option value="">-- Pilih Metode --</option>
                <option value="Tunai">Tunai</option>
                <option value="Debit Card">Debit Card</option>
                <option value="Credit Card">Credit Card</option>
                <option value="QRIS">QRIS</option>
                <option value="Transfer Bank">Transfer Bank</option>
                <option value="Asuransi">Asuransi</option>
                <option value="Lainnya">Lainnya</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          <button type="submit" name="proses_pembayaran" class="btn btn-success"><i class="fas fa-check-circle"></i> Tandai Sudah Lunas</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
// Pastikan jQuery dan Bootstrap JS sudah dimuat sebelum skrip ini.
// Biasanya diletakkan di footer.php atau sebelum tag penutup </body>.
document.addEventListener('DOMContentLoaded', function () {
    // Script untuk mengisi data ke modal saat tombol "Proses" di klik
    var modalProsesPembayaran = document.getElementById('modalProsesPembayaran');
    if (modalProsesPembayaran) { // Cek apakah modal ada di halaman
        $('#modalProsesPembayaran').on('show.bs.modal', function (event) {
          var button = $(event.relatedTarget); // Tombol yang memicu modal
          var idPembayaran = button.data('idpembayaran');
          var namaPasien = button.data('namapasien');
          var totalBiaya = button.data('totalbiaya');

          var modal = $(this);
          modal.find('.modal-title #namaPasienModal').text(namaPasien);
          modal.find('.modal-body #idPembayaranUpdateModal').val(idPembayaran);
          modal.find('.modal-body #totalBiayaModal').val(totalBiaya);
        });
    }
});
</script>
<style>
    /* Warna hijau kesehatan */
    :root {
        --hijau-utama: #28a745;
        --hijau-muda: #1cc88a;
        --hijau-teal: #20c997;
        --hijau-lembut: #a8e6cf;
        --abu-tekstil: #5a5c69;
    }

    .card.border-left-primary { border-left: .25rem solid var(--hijau-utama) !important; }
    .card.border-left-success { border-left: .25rem solid var(--hijau-muda) !important; }
    .card.border-left-info   { border-left: .25rem solid var(--hijau-teal) !important; }
    .card.border-left-warning { border-left: .25rem solid #ffc107 !important; }
    .card.border-left-danger  { border-left: .25rem solid #dc3545 !important; }
    .card.border-left-secondary { border-left: .25rem solidrgb(0, 0, 0) !important; }

    .text-primary { color: var(--hijau-utama) !important; }
    .text-success { color: var(--hijau-muda) !important; }
    .text-info    { color: var(--hijau-teal) !important; }
    .text-secondary { color:rgb(0, 1, 2) !important; }

    .btn-primary { background-color: var(--hijau-utama); border-color: var(--hijau-utama); }
    .btn-primary:hover { background-color: #218838; border-color: #1e7e34; }

    .btn-success { background-color: var(--hijau-muda); border-color: var(--hijau-muda); }
    .btn-info { background-color: var(--hijau-teal); border-color: var(--hijau-teal); }

    .text-gray-300 { color: #d4edda !important; }
    .text-gray-800 { color: var(--abu-tekstil) !important; }

    .shadow {
        box-shadow: 0 .15rem 1.75rem 0 rgba(40, 167, 69, 0.15)!important;
    }

    /* Sidebar tetap dengan latar hijau tua */
.sidebar {
    background-color: #14532d !important;  /* Hijau tua solid */
    color: white;
}

/* Untuk item sidebar (jika menggunakan class nav-item dan nav-link) */
.sidebar .nav-item .nav-link {
    color: #ffffff !important;
}

.sidebar .nav-item .nav-link:hover {
    background-color: #1e7e34 !important; /* Hijau hover */
    color: #ffffff !important;
}

/* Aktif link highlight */
.sidebar .nav-item.active .nav-link {
    background-color: #1cc88a !important; /* Hijau muda untuk highlight */
    color: #ffffff !important;
}
/* Navbar atas hijau muda */
.navbar {
    background-color: #1cc88a !important;
    color: white !important;
}

/* Teks di dalam navbar */
.navbar .nav-link,
.navbar .navbar-brand,
.navbar .dropdown-toggle {
    color: #ffffff !important;
}

/* Hover efek navbar */
.navbar .nav-link:hover {
    color: #f8f9fc !important;
}

</style>
<?php include '../includes/footer.php'; ?>