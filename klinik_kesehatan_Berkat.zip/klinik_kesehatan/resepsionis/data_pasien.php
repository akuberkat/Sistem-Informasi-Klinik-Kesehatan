<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('resepsionis');

$conn = connect_db();
$error_message = '';
$success_message = ''; // Jika ada aksi edit/delete di masa depan

// --- FETCHING DATA UNTUK DAFTAR PASIEN ---
$pasien_list = [];
$search_term = isset($_GET['search_term']) ? sanitize_input($_GET['search_term']) : '';
$filter_jk = isset($_GET['filter_jk']) ? sanitize_input($_GET['filter_jk']) : '';

$sql_pasien_list = "SELECT
                        p.id_pasien, p.nomor_rekam_medis, p.tanggal_lahir, p.jenis_kelamin, p.foto_profil,
                        u.nama_lengkap, u.email, u.nomor_telepon, u.alamat, u.tanggal_registrasi, u.username
                    FROM pasien p
                    JOIN pengguna u ON p.id_pengguna = u.id_pengguna
                    WHERE u.role = 'pasien' "; // Pastikan hanya mengambil role pasien

$params_filter = [];
$types_filter = "";

if (!empty($search_term)) {
    $sql_pasien_list .= " AND (u.nama_lengkap LIKE ? OR p.nomor_rekam_medis LIKE ? OR u.email LIKE ? OR u.nomor_telepon LIKE ?) ";
    $search_like = "%" . $search_term . "%";
    array_push($params_filter, $search_like, $search_like, $search_like, $search_like);
    $types_filter .= "ssss";
}

if (!empty($filter_jk)) {
    $sql_pasien_list .= " AND p.jenis_kelamin = ? ";
    $params_filter[] = $filter_jk;
    $types_filter .= "s";
}

$sql_pasien_list .= " ORDER BY u.nama_lengkap ASC";

// --- PAGINASI (Contoh sederhana) ---
$limit = 10; // Jumlah item per halaman
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// Hitung total data untuk paginasi (tanpa limit)
$stmt_total = $conn->prepare(str_replace("SELECT ... FROM", "SELECT COUNT(*) as total FROM", preg_replace('/SELECT.*?FROM/s', 'SELECT COUNT(p.id_pasien) as total FROM', $sql_pasien_list, 1))); // Ganti select list dengan COUNT(*)
if($stmt_total){
    if(!empty($params_filter)) {
        $stmt_total->bind_param($types_filter, ...$params_filter);
    }
    $stmt_total->execute();
    $total_results = $stmt_total->get_result()->fetch_assoc()['total'];
    $total_pages = ceil($total_results / $limit);
    $stmt_total->close();
} else {
    $total_results = 0;
    $total_pages = 0;
    $error_message .= " Gagal menghitung total data pasien.";
}

$sql_pasien_list_paged = $sql_pasien_list . " LIMIT ? OFFSET ?";
$params_filter_paged = $params_filter;
$params_filter_paged[] = $limit;
$params_filter_paged[] = $offset;
$types_filter_paged = $types_filter . "ii";

$stmt_pasien_list = $conn->prepare($sql_pasien_list_paged);
if($stmt_pasien_list) {
    if(!empty($params_filter_paged)) { // bind_param perlu setidaknya 1 parameter jika types tidak kosong
        $stmt_pasien_list->bind_param($types_filter_paged, ...$params_filter_paged);
    }
    $stmt_pasien_list->execute();
    $result_pasien_list = $stmt_pasien_list->get_result();
    while ($row = $result_pasien_list->fetch_assoc()) {
        $pasien_list[] = $row;
    }
    $stmt_pasien_list->close();
} else {
    $error_message .= " Gagal mengambil daftar pasien: " . $conn->error;
}

$conn->close();
?>

<?php $page_title = "Data Pasien Klinik"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Data Pasien Klinik</h1>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<div class="row mb-3">
    <div class="col-md-12">
        <a href="kelola_pendaftaran.php#formPendaftaranWalkin" class="btn btn-lg btn-success">
            <i class="fas fa-user-plus"></i> Tambah Pasien Baru / Pendaftaran Walk-in
        </a>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header">
        <h6><i class="fas fa-search"></i> Cari & Filter Pasien</h6>
    </div>
    <div class="card-body">
        <form action="data_pasien.php" method="GET" class="form-row align-items-end">
            <div class="form-group col-md-6">
                <label for="search_term">Cari (Nama, No.RM, Email, Telepon)</label>
                <input type="text" name="search_term" id="search_term" class="form-control" value="<?php echo htmlspecialchars($search_term); ?>" placeholder="Masukkan kata kunci...">
            </div>
            <div class="form-group col-md-3">
                <label for="filter_jk">Jenis Kelamin</label>
                <select name="filter_jk" id="filter_jk" class="form-control">
                    <option value="">Semua</option>
                    <option value="Laki-laki" <?php echo ($filter_jk == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
                    <option value="Perempuan" <?php echo ($filter_jk == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
                </select>
            </div>
            <div class="form-group col-md-3">
                <button type="submit" class="btn btn-primary mr-2"><i class="fas fa-filter"></i> Terapkan</button>
                <a href="data_pasien.php" class="btn btn-secondary"><i class="fas fa-sync-alt"></i> Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h6><i class="fas fa-users"></i> Daftar Semua Pasien (Total: <?php echo $total_results; ?>)</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-sm">
                <thead class="thead-light">
                    <tr>
                        <th>No.</th>
                        <th>Foto</th>
                        <th>No. RM</th>
                        <th>Nama Lengkap (Username)</th>
                        <th>Tgl Lahir (Usia)</th>
                        <th>Jenis Kelamin</th>
                        <th>Kontak (Telp/Email)</th>
                        <th>Alamat</th>
                        <th>Tgl Reg.</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($pasien_list)): ?>
                        <?php foreach ($pasien_list as $index => $pasien): ?>
                            <tr>
                                <td><?php echo $offset + $index + 1; ?></td>
                                <td>
                                    <img src="../assets/images/berkat.png/<?php echo !empty($pasien['foto_profil']) ? htmlspecialchars($pasien['foto_profil']) : 'default_pasien.png'; ?>"
                                         alt="Foto <?php echo htmlspecialchars($pasien['nama_lengkap']); ?>"
                                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 50%;">
                                </td>
                                <td><?php echo htmlspecialchars($pasien['nomor_rekam_medis']); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($pasien['nama_lengkap']); ?>
                                    <br><small class="text-muted">(<?php echo htmlspecialchars($pasien['username']); ?>)</small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars(format_tanggal_indonesia($pasien['tanggal_lahir'])); ?>
                                    <?php
                                        if ($pasien['tanggal_lahir']) {
                                            $birthDate = new DateTime($pasien['tanggal_lahir']);
                                            $todayDate = new DateTime();
                                            $age = $todayDate->diff($birthDate)->y;
                                            echo " <small class='text-muted'>(" . $age . " th)</small>";
                                        }
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($pasien['jenis_kelamin']); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($pasien['nomor_telepon'] ?: '-'); ?>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($pasien['email'] ?: '-'); ?></small>
                                </td>
                                <td><?php echo nl2br(htmlspecialchars($pasien['alamat'] ?: '-')); ?></td>
                                <td><?php echo htmlspecialchars(format_tanggal_indonesia($pasien['tanggal_registrasi'], true)); ?></td>
<td class="action-buttons">
    <a href="edit_pasien.php?id_pasien=<?php echo $pasien['id_pasien']; ?>" title="Edit Data Pasien">Edit</a> |
    <a href="hapus_pasien.php?id_pasien=<?php echo $pasien['id_pasien']; ?>" title="Hapus Data Pasien" onclick="return confirm('Yakin ingin menghapus data pasien ini?');">Hapus</a>
</td>

                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center">Tidak ada data pasien yang ditemukan sesuai filter.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mt-3">
                <?php if ($page > 1): ?>
                    <li class="page-item"><a class="page-link" href="?page=<?php echo $page - 1; ?>&search_term=<?php echo urlencode($search_term); ?>&filter_jk=<?php echo urlencode($filter_jk); ?>">Previous</a></li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&search_term=<?php echo urlencode($search_term); ?>&filter_jk=<?php echo urlencode($filter_jk); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item"><a class="page-link" href="?page=<?php echo $page + 1; ?>&search_term=<?php echo urlencode($search_term); ?>&filter_jk=<?php echo urlencode($filter_jk); ?>">Next</a></li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>

    </div>
</div>
<style>
    /* Warna hijau kesehatan */
    :root {
        --hijau-utama: #28a745;
        --hijau-muda: #1cc88a;
        --hijau-teal: #20c997;
        --hijau-lembut: #a8e6cf;
        --abu-tekstil: #5a5c69;
    }

    .card.border-left-primary { border-left: .25rem solid var(--hijau-utama) !important; }
    .card.border-left-success { border-left: .25rem solid var(--hijau-muda) !important; }
    .card.border-left-info   { border-left: .25rem solid var(--hijau-teal) !important; }
    .card.border-left-warning { border-left: .25rem solid #ffc107 !important; }
    .card.border-left-danger  { border-left: .25rem solid #dc3545 !important; }
    .card.border-left-secondary { border-left: .25rem solidrgb(0, 0, 0) !important; }

    .text-primary { color: var(--hijau-utama) !important; }
    .text-success { color: var(--hijau-muda) !important; }
    .text-info    { color: var(--hijau-teal) !important; }
    .text-secondary { color:rgb(0, 1, 2) !important; }

    .btn-primary { background-color: var(--hijau-utama); border-color: var(--hijau-utama); }
    .btn-primary:hover { background-color: #218838; border-color: #1e7e34; }

    .btn-success { background-color: var(--hijau-muda); border-color: var(--hijau-muda); }
    .btn-info { background-color: var(--hijau-teal); border-color: var(--hijau-teal); }

    .text-gray-300 { color: #d4edda !important; }
    .text-gray-800 { color: var(--abu-tekstil) !important; }

    .shadow {
        box-shadow: 0 .15rem 1.75rem 0 rgba(40, 167, 69, 0.15)!important;
    }

    /* Sidebar tetap dengan latar hijau tua */
.sidebar {
    background-color: #14532d !important;  /* Hijau tua solid */
    color: white;
}

/* Untuk item sidebar (jika menggunakan class nav-item dan nav-link) */
.sidebar .nav-item .nav-link {
    color: #ffffff !important;
}

.sidebar .nav-item .nav-link:hover {
    background-color: #1e7e34 !important; /* Hijau hover */
    color: #ffffff !important;
}

/* Aktif link highlight */
.sidebar .nav-item.active .nav-link {
    background-color: #1cc88a !important; /* Hijau muda untuk highlight */
    color: #ffffff !important;
}
/* Navbar atas hijau muda */
.navbar {
    background-color: #1cc88a !important;
    color: white !important;
}

/* Teks di dalam navbar */
.navbar .nav-link,
.navbar .navbar-brand,
.navbar .dropdown-toggle {
    color: #ffffff !important;
}

/* Hover efek navbar */
.navbar .nav-link:hover {
    color: #f8f9fc !important;
}

</style>
<?php include '../includes/footer.php'; ?>
