<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth.php';

check_login('resepsionis');

$conn = connect_db();

if (!isset($_GET['id_pasien'])) {
    echo "ID pasien tidak ditemukan!";
    exit;
}

$id_pasien = intval($_GET['id_pasien']);

// Ambil data pasien untuk ditampilkan di form
$stmt = $conn->prepare("SELECT p.id_pasien, u.nama_lengkap, u.alamat, u.nomor_telepon FROM pasien p JOIN pengguna u ON p.id_pengguna = u.id_pengguna WHERE p.id_pasien = ?");
$stmt->bind_param("i", $id_pasien);
$stmt->execute();
$result = $stmt->get_result();
$pasien = $result->fetch_assoc();
$stmt->close();

if (!$pasien) {
    echo "Data pasien tidak ditemukan!";
    exit;
}

// Proses update data jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_lengkap'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['nomor_telepon'];

    // Update tabel pengguna (sesuai struktur database kamu)
    $stmt = $conn->prepare("UPDATE pengguna u JOIN pasien p ON u.id_pengguna = p.id_pengguna SET u.nama_lengkap = ?, u.alamat = ?, u.nomor_telepon = ? WHERE p.id_pasien = ?");
    $stmt->bind_param("sssi", $nama, $alamat, $no_telepon, $id_pasien);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: data_pasien.php?pesan=edit_sukses");
        exit;
    } else {
        echo "Gagal memperbarui data pasien.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Pasien</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Edit Data Pasien</h2>
    <form method="POST">
        <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" class="form-control" value="<?php echo htmlspecialchars($pasien['nama_lengkap']); ?>" required>
        </div>
        <div class="form-group">
            <label>Alamat</label>
            <input type="text" name="alamat" class="form-control" value="<?php echo htmlspecialchars($pasien['alamat']); ?>">
        </div>
        <div class="form-group">
            <label>No. Telepon</label>
            <input type="text" name="nomor_telepon" class="form-control" value="<?php echo htmlspecialchars($pasien['nomor_telepon']); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="data_pasien.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
