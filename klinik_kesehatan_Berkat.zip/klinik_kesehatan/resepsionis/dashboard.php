<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('resepsionis'); // Memastikan hanya resepsionis yang bisa akses

$conn = connect_db();
$nama_resepsionis = $_SESSION['nama_lengkap'];
$error_message = '';

// Statistik
$jumlah_menunggu_konfirmasi = 0;
$jumlah_pasien_dikonfirmasi_hari_ini = 0;
$jumlah_total_pasien = 0;
$jumlah_belum_lunas = 0;
$pendaftaran_menunggu_konfirmasi_list = [];

// 1. Jumlah pendaftaran menunggu konfirmasi
$stmt_menunggu = $conn->prepare("SELECT COUNT(id_pendaftaran) AS total FROM pendaftaran_konsultasi WHERE status_pendaftaran = 'Menunggu Konfirmasi'");
if ($stmt_menunggu) {
    $stmt_menunggu->execute();
    $result_menunggu = $stmt_menunggu->get_result()->fetch_assoc();
    $jumlah_menunggu_konfirmasi = $result_menunggu['total'];
    $stmt_menunggu->close();
} else {
    $error_message .= " Gagal mengambil jumlah pendaftaran menunggu konfirmasi. ";
}

// 2. Jumlah pasien terdaftar (dikonfirmasi) untuk hari ini
$today = date("Y-m-d");
$stmt_pasien_today = $conn->prepare("SELECT COUNT(id_pendaftaran) AS total FROM pendaftaran_konsultasi WHERE tanggal_konsultasi = ? AND status_pendaftaran = 'Dikonfirmasi'");
if ($stmt_pasien_today) {
    $stmt_pasien_today->bind_param("s", $today);
    $stmt_pasien_today->execute();
    $result_pasien_today = $stmt_pasien_today->get_result()->fetch_assoc();
    $jumlah_pasien_dikonfirmasi_hari_ini = $result_pasien_today['total'];
    $stmt_pasien_today->close();
} else {
    $error_message .= " Gagal mengambil jumlah pasien hari ini. ";
}

// 3. Jumlah total pasien terdaftar di klinik
$stmt_total_pasien = $conn->prepare("SELECT COUNT(id_pasien) AS total FROM pasien");
if ($stmt_total_pasien) {
    $stmt_total_pasien->execute();
    $result_total_pasien = $stmt_total_pasien->get_result()->fetch_assoc();
    $jumlah_total_pasien = $result_total_pasien['total'];
    $stmt_total_pasien->close();
} else {
    $error_message .= " Gagal mengambil jumlah total pasien. ";
}

// 4. Jumlah pembayaran belum lunas untuk konsultasi yang sudah 'Selesai'
$stmt_belum_lunas = $conn->prepare("SELECT COUNT(pb.id_pembayaran) AS total
                                   FROM pembayaran pb
                                   JOIN pendaftaran_konsultasi pk ON pb.id_pendaftaran = pk.id_pendaftaran
                                   WHERE pb.status_pembayaran = 'Belum Lunas' AND pk.status_pendaftaran = 'Selesai'");
if ($stmt_belum_lunas) {
    $stmt_belum_lunas->execute();
    $result_belum_lunas = $stmt_belum_lunas->get_result()->fetch_assoc();
    $jumlah_belum_lunas = $result_belum_lunas['total'];
    $stmt_belum_lunas->close();
} else {
    $error_message .= " Gagal mengambil jumlah pembayaran belum lunas. ";
}


// 5. Daftar singkat pendaftaran menunggu konfirmasi (misal 5 teratas)
$sql_list_menunggu = "SELECT
                        pk.id_pendaftaran,
                        pk.tanggal_dibuat,
                        pas_pengguna.nama_lengkap AS nama_pasien,
                        dok_pengguna.nama_lengkap AS nama_dokter,
                        pk.tanggal_konsultasi,
                        pk.jam_konsultasi
                      FROM pendaftaran_konsultasi pk
                      JOIN pasien pas ON pk.id_pasien = pas.id_pasien
                      JOIN pengguna pas_pengguna ON pas.id_pengguna = pas_pengguna.id_pengguna
                      JOIN dokter dok ON pk.id_dokter = dok.id_dokter
                      JOIN pengguna dok_pengguna ON dok.id_pengguna = dok_pengguna.id_pengguna
                      WHERE pk.status_pendaftaran = 'Menunggu Konfirmasi'
                      ORDER BY pk.tanggal_dibuat ASC
                      LIMIT 5";
$result_list_menunggu = $conn->query($sql_list_menunggu);
if ($result_list_menunggu) {
    while ($row = $result_list_menunggu->fetch_assoc()) {
        $pendaftaran_menunggu_konfirmasi_list[] = $row;
    }
} else {
    $error_message .= " Gagal mengambil daftar pendaftaran menunggu konfirmasi. ";
}


$conn->close();
?>

<?php $page_title = "Dashboard Resepsionis"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Dashboard Resepsionis</h1>
    <p class="lead">Selamat datang, <?php echo htmlspecialchars($nama_resepsionis); ?>!</p>
</div>

<?php if (!empty($error_message)): ?>
    <div class="alert alert-warning"><?php echo "Terjadi beberapa masalah saat mengambil data: " . $error_message; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title mb-0"><i class="fas fa-hourglass-half"></i> Menunggu Konfirmasi</h5>
                    </div>
                    <div class="text-right">
                        <h2 class="mb-0 font-weight-bold"><?php echo $jumlah_menunggu_konfirmasi; ?></h2>
                    </div>
                </div>
                <a href="kelola_pendaftaran.php?status=Menunggu Konfirmasi" class="stretched-link text-white small">Lihat Detail <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                 <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title mb-0"><i class="fas fa-calendar-day"></i> Pasien Hari Ini</h5>
                    </div>
                    <div class="text-right">
                        <h2 class="mb-0 font-weight-bold"><?php echo $jumlah_pasien_dikonfirmasi_hari_ini; ?></h2>
                    </div>
                </div>
                <a href="kelola_pendaftaran.php?tanggal=<?php echo date('Y-m-d'); ?>&status=Dikonfirmasi" class="stretched-link text-white small">Lihat Detail <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title mb-0"><i class="fas fa-users"></i> Total Pasien</h5>
                    </div>
                    <div class="text-right">
                        <h2 class="mb-0 font-weight-bold"><?php echo $jumlah_total_pasien; ?></h2>
                    </div>
                </div>
                <a href="data_pasien.php" class="stretched-link text-white small">Lihat Detail <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="card text-white bg-danger">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title mb-0"><i class="fas fa-file-invoice-dollar"></i> Belum Lunas</h5>
                    </div>
                    <div class="text-right">
                        <h2 class="mb-0 font-weight-bold"><?php echo $jumlah_belum_lunas; ?></h2>
                    </div>
                </div>
                <a href="kelola_pembayaran.php?status_pembayaran=Belum Lunas" class="stretched-link text-white small">Lihat Detail <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
</div>

<div class="row mt-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-bell"></i> Pendaftaran Terbaru Menunggu Konfirmasi (Maks. 5)</h6>
            </div>
            <div class="card-body">
                <?php if (!empty($pendaftaran_menunggu_konfirmasi_list)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>Diajukan</th>
                                    <th>Nama Pasien</th>
                                    <th>Dokter Tujuan</th>
                                    <th>Jadwal Konsul</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pendaftaran_menunggu_konfirmasi_list as $p): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars(format_tanggal_indonesia($p['tanggal_dibuat'])); ?><br><small><?php echo htmlspecialchars(date("H:i", strtotime($p['tanggal_dibuat']))); ?></small></td>
                                        <td><?php echo htmlspecialchars($p['nama_pasien']); ?></td>
                                        <td><?php echo htmlspecialchars($p['nama_dokter']); ?></td>
                                        <td><?php echo htmlspecialchars(format_tanggal_indonesia($p['tanggal_konsultasi'])); ?> <small><?php echo htmlspecialchars(date("H:i", strtotime($p['jam_konsultasi']))); ?></small></td>
                                        <td>
                                            <a href="kelola_pendaftaran.php?action=view&id=<?php echo $p['id_pendaftaran']; ?>" class="btn btn-sm btn-primary">Proses</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                     <a href="kelola_pendaftaran.php?status=Menunggu Konfirmasi" class="btn btn-outline-primary mt-2 btn-sm">Lihat Semua Pendaftaran Menunggu</a>
                <?php else: ?>
                    <p class="text-muted">Tidak ada pendaftaran yang menunggu konfirmasi saat ini.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-tasks"></i> Menu Utama Resepsionis</h6>
            </div>
            <div class="card-body">
                <a href="kelola_pendaftaran.php" class="btn btn-lg btn-primary m-2"><i class="fas fa-calendar-alt"></i> Kelola Pendaftaran</a>
                <a href="data_pasien.php" class="btn btn-lg btn-info m-2"><i class="fas fa-address-book"></i> Data Pasien</a>
                <a href="kelola_pembayaran.php" class="btn btn-lg btn-success m-2"><i class="fas fa-money-check-alt"></i> Kelola Pembayaran</a>
                </div>
        </div>
    </div>
</div>

<style>
    /* Warna hijau kesehatan */
    :root {
        --hijau-utama: #28a745;
        --hijau-muda: #1cc88a;
        --hijau-teal: #20c997;
        --hijau-lembut: #a8e6cf;
        --abu-tekstil: #5a5c69;
    }

    .card.border-left-primary { border-left: .25rem solid var(--hijau-utama) !important; }
    .card.border-left-success { border-left: .25rem solid var(--hijau-muda) !important; }
    .card.border-left-info   { border-left: .25rem solid var(--hijau-teal) !important; }
    .card.border-left-warning { border-left: .25rem solid #ffc107 !important; }
    .card.border-left-danger  { border-left: .25rem solid #dc3545 !important; }
    .card.border-left-secondary { border-left: .25rem solidrgb(0, 0, 0) !important; }

    .text-primary { color: var(--hijau-utama) !important; }
    .text-success { color: var(--hijau-muda) !important; }
    .text-info    { color: var(--hijau-teal) !important; }
    .text-secondary { color:rgb(0, 1, 2) !important; }

    .btn-primary { background-color: var(--hijau-utama); border-color: var(--hijau-utama); }
    .btn-primary:hover { background-color: #218838; border-color: #1e7e34; }

    .btn-success { background-color: var(--hijau-muda); border-color: var(--hijau-muda); }
    .btn-info { background-color: var(--hijau-teal); border-color: var(--hijau-teal); }

    .text-gray-300 { color: #d4edda !important; }
    .text-gray-800 { color: var(--abu-tekstil) !important; }

    .shadow {
        box-shadow: 0 .15rem 1.75rem 0 rgba(40, 167, 69, 0.15)!important;
    }

    /* Sidebar tetap dengan latar hijau tua */
.sidebar {
    background-color: #14532d !important;  /* Hijau tua solid */
    color: white;
}

/* Untuk item sidebar (jika menggunakan class nav-item dan nav-link) */
.sidebar .nav-item .nav-link {
    color: #ffffff !important;
}

.sidebar .nav-item .nav-link:hover {
    background-color: #1e7e34 !important; /* Hijau hover */
    color: #ffffff !important;
}

/* Aktif link highlight */
.sidebar .nav-item.active .nav-link {
    background-color: #1cc88a !important; /* Hijau muda untuk highlight */
    color: #ffffff !important;
}
/* Navbar atas hijau muda */
.navbar {
    background-color: #1cc88a !important;
    color: white !important;
}

/* Teks di dalam navbar */
.navbar .nav-link,
.navbar .navbar-brand,
.navbar .dropdown-toggle {
    color: #ffffff !important;
}

/* Hover efek navbar */
.navbar .nav-link:hover {
    color: #f8f9fc !important;
}

</style>
<?php include '../includes/footer.php'; ?>