<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Klinik Berkat</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />

  <!-- AOS CSS -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />

  <!-- Custom CSS -->
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }

    .navbar {
      background-color: #198754;
    }

    .navbar-brand, .nav-link {
      color: white !important;
      font-weight: 600;
    }

    .hero {
      background-color: #e9f8f1;
      padding: 80px 0;
    }

    .about img {
      border-radius: 30px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    }

    .services .card {
      transition: transform 0.3s;
    }

    .services .card:hover {
      transform: scale(1.03);
    }

    .testimonial {
      background-color: #d1e7dd;
    }

    .footer {
      background-color: #198754;
      color: white;
      padding: 20px 0;
      text-align: center;
    }
  </style>
</head>
<body>

 <!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-success navbar-dark">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="#">
      <img src="assets/images/logoku.png" alt="Logo Klinik" style="height: 60px;" class="me-2">
      Klinik Berkat
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="#beranda">Beranda</a></li>
        <li class="nav-item"><a class="nav-link" href="#tentang">Tentang</a></li>
        <li class="nav-item"><a class="nav-link" href="#layanan">Layanan</a></li>
        <li class="nav-item"><a class="nav-link" href="#testimoni">Testimoni</a></li>
        <li class="nav-item"><a class="nav-link" href="#kontak">Kontak</a></li>
      </ul>
      <a href="login.php" class="btn btn-outline-light ms-3">Login</a>
    </div>
  </div>
</nav>


  <!-- Hero -->
  <section id="beranda" class="hero text-center">
    <div class="container" data-aos="fade-up">
      <h1 class="display-5 fw-bold text-success">Selamat Datang di Klinik Berkat</h1>
      <p>Kami memberikan pelayanan kesehatan terbaik untuk keluarga Anda — cepat, aman, dan terjangkau.</p>
    </div>
  </section>

  <!-- About -->
  <section id="tentang" class="about py-5" style="background-color: #f0fdf4;">
    <div class="container" data-aos="fade-up">
      <div class="row align-items-center">
        <div class="col-md-6 mb-4 mb-md-0">
          <img src="assets/images/pp.jpg" alt="Tentang Klinik" class="img-fluid rounded-4 shadow" />
        </div>
        <div class="col-md-6">
          <h2 class="fw-bold text-success mb-3">Tentang Klinik Berkat</h2>
          <p style="font-size: 1.1rem;">Klinik Berkat didirikan pada tahun 2020 sebagai solusi layanan kesehatan yang modern dan terjangkau. Klinik ini hadir untuk memberikan pelayanan medis yang cepat, aman, dan terpercaya bagi masyarakat.</p>
          <p style="font-size: 1.1rem;">Dengan sistem digital terintegrasi, kami memudahkan pasien dalam melakukan pendaftaran, konsultasi, hingga pembayaran secara online. Fungsi utama klinik ini adalah memberikan layanan kesehatan primer, edukasi kesehatan, serta pemeriksaan rutin bagi seluruh kalangan.</p>
        </div>
      </div>
    </div>
  </section>

<!-- Layanan -->
<section id="layanan" class="services py-5">
  <div class="container" data-aos="fade-up">
    <h2 class="text-center fw-bold mb-5 text-success">Layanan Kami</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card h-100 text-center p-3">
          <img src="assets/images/konsul.jpg" alt="Konsultasi Umum" class="card-img-top mx-auto" style="max-height: 150px; width: auto; object-fit: contain;">
          <div class="card-body">
            <h5 class="card-title text-success">Konsultasi Umum</h5>
            <p class="card-text">Layanan konsultasi dengan dokter umum yang ramah dan profesional.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card h-100 text-center p-3">
          <img src="assets/images/cek.jpg" alt="Pemeriksaan Kesehatan" class="card-img-top mx-auto" style="max-height: 150px; width: auto; object-fit: contain;">
          <div class="card-body">
            <h5 class="card-title text-success">Pemeriksaan Kesehatan</h5>
            <p class="card-text">Cek tekanan darah, gula darah, kolesterol, dan lainnya secara berkala.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card h-100 text-center p-3">
          <img src="assets/images/apotek.jpg" alt="Apotek" class="card-img-top mx-auto" style="max-height: 150px; width: auto; object-fit: contain;">
          <div class="card-body">
            <h5 class="card-title text-success">Apotek</h5>
            <p class="card-text">Tersedia berbagai obat-obatan dengan resep maupun bebas.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


  <!-- Testimoni -->
<section id="testimoni" class="testimonial py-5">
  <div class="container" data-aos="fade-up">
    <h2 class="text-center fw-bold mb-5 text-success">Apa Kata Pasien?</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="bg-white p-4 rounded shadow text-center">
          <img src="assets/images/dini.jfif" alt="Dini" class="rounded-circle mb-3" style="width: 120px; height: 120px; object-fit: cover;">
          <p>"Pelayanan sangat cepat dan dokter sangat ramah. Kliniknya juga bersih dan nyaman."</p>
          <strong>- Dini, Medan</strong>
        </div>
      </div>
      <div class="col-md-4">
        <div class="bg-white p-4 rounded shadow text-center">
          <img src="assets/images/ara.jpeg" alt="Sahara" class="rounded-circle mb-3" style="width: 120px; height: 120px; object-fit: cover;">
          <p>"Saya sangat puas karena bisa daftar dan bayar secara online. Sangat efisien!"</p>
          <strong>- Sahara, Medan</strong>
        </div>
      </div>
      <div class="col-md-4">
        <div class="bg-white p-4 rounded shadow text-center">
          <img src="assets/images/gosta.jfif" alt="Sari" class="rounded-circle mb-3" style="width: 120px; height: 120px; object-fit: cover;">
          <p>"Obat yang tersedia lengkap dan harga terjangkau. Apoteknya juga terpercaya."</p>
          <strong>- Gosta, Deli Serdang</strong>
        </div>
      </div>
    </div>
  </div>
</section>


  <!-- Kontak -->
  <section id="kontak" class="py-5 bg-light">
    <div class="container" data-aos="fade-up">
      <h2 class="text-center fw-bold mb-5 text-success">Hubungi Kami</h2>
      <form class="row g-3">
        <div class="col-md-6">
          <input type="text" class="form-control" placeholder="Nama Anda" required>
        </div>
        <div class="col-md-6">
          <input type="email" class="form-control" placeholder="Email Anda" required>
        </div>
        <div class="col-12">
          <textarea class="form-control" rows="4" placeholder="Pesan Anda" required></textarea>
        </div>
        <div class="col-12 text-center">
          <button type="submit" class="btn btn-success px-4">Kirim Pesan</button>
        </div>
      </form>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <p>Sistem Informasi Klinik Kesehatan Berkat Never Surrender</p>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- AOS JS -->
  <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>

</body>
</html>
