<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php'; // Memastikan user login dan role adalah pasien

check_login('pasien'); // Memastikan hanya pasien yang bisa akses

$id_pasien_pengguna = $_SESSION['id_pengguna'];
$conn = connect_db();

// Ambil id_pasien dari tabel pasien berdasarkan id_pengguna
$stmt_pasien_id = $conn->prepare("SELECT id_pasien, nomor_rekam_medis FROM pasien WHERE id_pengguna = ?");
$stmt_pasien_id->bind_param("i", $id_pasien_pengguna);
$stmt_pasien_id->execute();
$result_pasien_id = $stmt_pasien_id->get_result();
$pasien_data = $result_pasien_id->fetch_assoc();
$id_pasien = $pasien_data['id_pasien'] ?? null;
$nomor_rm = $pasien_data['nomor_rekam_medis'] ?? 'N/A';
$stmt_pasien_id->close();

$jumlah_konsultasi_mendatang = 0;
$jumlah_riwayat_konsultasi = 0;

if ($id_pasien) {
    // Hitung konsultasi mendatang
    $stmt_mendatang = $conn->prepare("SELECT COUNT(*) AS total FROM pendaftaran_konsultasi WHERE id_pasien = ? AND tanggal_konsultasi >= CURDATE() AND status_pendaftaran = 'Dikonfirmasi'");
    $stmt_mendatang->bind_param("i", $id_pasien);
    $stmt_mendatang->execute();
    $result_mendatang = $stmt_mendatang->get_result()->fetch_assoc();
    $jumlah_konsultasi_mendatang = $result_mendatang['total'];
    $stmt_mendatang->close();

    // Hitung riwayat konsultasi
    $stmt_riwayat = $conn->prepare("SELECT COUNT(*) AS total FROM pendaftaran_konsultasi WHERE id_pasien = ? AND status_pendaftaran = 'Selesai'");
    $stmt_riwayat->bind_param("i", $id_pasien);
    $stmt_riwayat->execute();
    $result_riwayat = $stmt_riwayat->get_result()->fetch_assoc();
    $jumlah_riwayat_konsultasi = $result_riwayat['total'];
    $stmt_riwayat->close();
}
$conn->close();
?>
<?php $page_title = "Dashboard Pasien"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Dashboard Pasien</h1>
</div>

<p>Selamat datang kembali, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>!</p>
<p>Nomor Rekam Medis Anda: <strong><?php echo htmlspecialchars($nomor_rm); ?></strong></p>

<div style="display: flex; gap: 20px; margin-top: 20px;">
    <div class="card" style="flex: 1;">
        <div class="card-header">
            <h6>Konsultasi Mendatang</h6>
        </div>
        <div class="card-body" style="text-align: center;">
            <h2 style="font-size: 3em; margin: 10px 0; color: #007bff;"><?php echo $jumlah_konsultasi_mendatang; ?></h2>
            <p>Jadwal konsultasi yang telah dikonfirmasi.</p>
            <a href="riwayat_konsultasi.php?filter=mendatang" class="btn btn-info btn-sm">Lihat Detail</a>
        </div>
    </div>

    <div class="card" style="flex: 1;">
        <div class="card-header">
            <h6>Riwayat Konsultasi</h6>
        </div>
        <div class="card-body" style="text-align: center;">
            <h2 style="font-size: 3em; margin: 10px 0; color: #28a745;"><?php echo $jumlah_riwayat_konsultasi; ?></h2>
            <p>Konsultasi yang telah selesai.</p>
            <a href="riwayat_konsultasi.php" class="btn btn-success btn-sm">Lihat Riwayat</a>
        </div>
    </div>
</div>

<div class="card" style="margin-top: 30px;">
    <div class="card-header">
        <h6>Aksi Cepat</h6>
    </div>
    <div class="card-body">
        <a href="pendaftaran_konsultasi.php" class="btn btn-primary" style="margin-right:10px;">Buat Pendaftaran Baru</a>
        <a href="profil.php" class="btn btn-secondary">Update Profil Saya</a>
    </div>
</div>

<?php include '../includes/footer.php'; ?>