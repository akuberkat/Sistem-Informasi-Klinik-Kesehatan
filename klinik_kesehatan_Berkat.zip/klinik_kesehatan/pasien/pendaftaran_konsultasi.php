<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
// Pastikan ../includes/auth.php ada dan berisi fungsi check_login
// Jika tidak, Anda bisa langsung memanggil check_login() dari functions.php jika sudah digabung
require_once '../includes/auth.php'; // Diasumsikan ini akan memanggil check_login('pasien') atau serupa

check_login('pasien'); // Memastikan hanya pasien yang bisa akses

$conn = connect_db();
$id_pengguna_pasien = $_SESSION['id_pengguna'];
$id_pasien = null;
$error_message = '';
$success_message = '';

// Ambil id_pasien dari tabel pasien berdasarkan id_pengguna
$stmt_get_pasien = $conn->prepare("SELECT id_pasien FROM pasien WHERE id_pengguna = ?");
if ($stmt_get_pasien) {
    $stmt_get_pasien->bind_param("i", $id_pengguna_pasien);
    $stmt_get_pasien->execute();
    $result_pasien = $stmt_get_pasien->get_result();
    if ($result_pasien->num_rows > 0) {
        $pasien_data = $result_pasien->fetch_assoc();
        $id_pasien = $pasien_data['id_pasien'];
    } else {
        $error_message = "Data pasien tidak ditemukan. Silakan hubungi administrasi.";
        // Redirect atau tindakan lain jika data pasien esensial tidak ada
    }
    $stmt_get_pasien->close();
} else {
    $error_message = "Kesalahan dalam menyiapkan query data pasien: " . $conn->error;
}


// Fetch daftar dokter untuk dropdown
$dokter_list = [];
$sql_dokter = "SELECT d.id_dokter, p.nama_lengkap, d.spesialisasi
               FROM dokter d
               JOIN pengguna p ON d.id_pengguna = p.id_pengguna
               WHERE p.role = 'dokter'
               ORDER BY p.nama_lengkap ASC"; // Anda bisa tambahkan filter status aktif dokter jika ada
$result_dokter = $conn->query($sql_dokter);
if ($result_dokter && $result_dokter->num_rows > 0) {
    while ($row = $result_dokter->fetch_assoc()) {
        $dokter_list[] = $row;
    }
}

// Proses form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $id_pasien) {
    $id_dokter_pilihan = sanitize_input($_POST['id_dokter']);
    $tanggal_konsultasi = sanitize_input($_POST['tanggal_konsultasi']);
    $jam_konsultasi = sanitize_input($_POST['jam_konsultasi']);
    $keluhan_utama = sanitize_input($_POST['keluhan_utama']);
    $status_pendaftaran = 'Menunggu Konfirmasi'; // Default status

    // Validasi sederhana
    if (empty($id_dokter_pilihan) || empty($tanggal_konsultasi) || empty($jam_konsultasi) || empty($keluhan_utama)) {
        $error_message = "Semua field wajib diisi.";
    } elseif (strtotime($tanggal_konsultasi) < strtotime(date('Y-m-d'))) {
        $error_message = "Tanggal konsultasi tidak boleh kurang dari hari ini.";
    } else {
        // Cek apakah pasien sudah mendaftar pada jam dan dokter yang sama (opsional, tapi bagus)
        $stmt_check_duplicate = $conn->prepare("SELECT id_pendaftaran FROM pendaftaran_konsultasi WHERE id_pasien = ? AND id_dokter = ? AND tanggal_konsultasi = ? AND jam_konsultasi = ? AND status_pendaftaran != 'Dibatalkan'");
        if($stmt_check_duplicate){
            $stmt_check_duplicate->bind_param("iiss", $id_pasien, $id_dokter_pilihan, $tanggal_konsultasi, $jam_konsultasi);
            $stmt_check_duplicate->execute();
            $result_duplicate = $stmt_check_duplicate->get_result();
            if($result_duplicate->num_rows > 0){
                $error_message = "Anda sudah memiliki jadwal konsultasi dengan dokter ini pada tanggal dan jam yang sama.";
            }
            $stmt_check_duplicate->close();
        } else {
             $error_message = "Gagal memeriksa duplikasi jadwal: " . $conn->error;
        }


        if(empty($error_message)) { // Hanya insert jika tidak ada error duplikasi
            $stmt_insert = $conn->prepare("INSERT INTO pendaftaran_konsultasi (id_pasien, id_dokter, tanggal_konsultasi, jam_konsultasi, keluhan_utama, status_pendaftaran) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt_insert) {
                $stmt_insert->bind_param("iissss", $id_pasien, $id_dokter_pilihan, $tanggal_konsultasi, $jam_konsultasi, $keluhan_utama, $status_pendaftaran);
                if ($stmt_insert->execute()) {
                    $success_message = "Pendaftaran konsultasi berhasil dikirim. Mohon tunggu konfirmasi dari resepsionis.";
                    // Kosongkan form atau redirect (opsional)
                    $_POST = array(); // Mengosongkan POST agar form bersih setelah submit berhasil
                } else {
                    $error_message = "Gagal menyimpan pendaftaran: " . $stmt_insert->error;
                }
                $stmt_insert->close();
            } else {
                $error_message = "Kesalahan dalam menyiapkan statement insert: " . $conn->error;
            }
        }
    }
}

$conn->close();
?>

<?php $page_title = "Pendaftaran Konsultasi"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Pendaftaran Konsultasi Baru</h1>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<?php if (!$id_pasien && empty($error_message)): // Tambahan kondisi untuk tidak menampilkan form jika id_pasien fundamental error ?>
    <div class="alert alert-warning">Tidak dapat memproses pendaftaran saat ini karena data profil pasien Anda belum lengkap atau tidak ditemukan. Harap hubungi administrasi.</div>
<?php else: ?>
<form action="pendaftaran_konsultasi.php" method="POST">
    <div class="card">
        <div class="card-header">
            <h6>Formulir Pendaftaran</h6>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="id_dokter">Pilih Dokter <span style="color:red;">*</span></label>
                <select name="id_dokter" id="id_dokter" class="form-control" required>
                    <option value="">-- Pilih Dokter --</option>
                    <?php foreach ($dokter_list as $dokter): ?>
                        <option value="<?php echo htmlspecialchars($dokter['id_dokter']); ?>" <?php echo (isset($_POST['id_dokter']) && $_POST['id_dokter'] == $dokter['id_dokter']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dokter['nama_lengkap']); ?> (<?php echo htmlspecialchars($dokter['spesialisasi']); ?>)
                        </option>
                    <?php endforeach; ?>
                    <?php if (empty($dokter_list)): ?>
                         <option value="" disabled>Tidak ada dokter tersedia saat ini.</option>
                    <?php endif; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="tanggal_konsultasi">Tanggal Konsultasi <span style="color:red;">*</span></label>
                <input type="date" name="tanggal_konsultasi" id="tanggal_konsultasi" class="form-control"
                       value="<?php echo isset($_POST['tanggal_konsultasi']) ? htmlspecialchars($_POST['tanggal_konsultasi']) : ''; ?>"
                       min="<?php echo date('Y-m-d'); ?>" required>
                <small class="form-text text-muted">Pilih tanggal yang diinginkan.</small>
            </div>

            <div class="form-group">
                <label for="jam_konsultasi">Jam Konsultasi <span style="color:red;">*</span></label>
                <input type="time" name="jam_konsultasi" id="jam_konsultasi" class="form-control"
                       value="<?php echo isset($_POST['jam_konsultasi']) ? htmlspecialchars($_POST['jam_konsultasi']) : ''; ?>" required>
                <small class="form-text text-muted">Masukkan perkiraan jam. Jadwal pasti akan dikonfirmasi oleh resepsionis.</small>
            </div>

            <div class="form-group">
                <label for="keluhan_utama">Keluhan Utama <span style="color:red;">*</span></label>
                <textarea name="keluhan_utama" id="keluhan_utama" rows="4" class="form-control" required><?php echo isset($_POST['keluhan_utama']) ? htmlspecialchars($_POST['keluhan_utama']) : ''; ?></textarea>
                <small class="form-text text-muted">Jelaskan secara singkat keluhan utama Anda.</small>
            </div>

            <div class="form-group">
                <?php if ($id_pasien): // Hanya tampilkan tombol jika id_pasien valid ?>
                <button type="submit" class="btn btn-primary">Kirim Pendaftaran</button>
                <?php else: ?>
                <button type="submit" class="btn btn-primary" disabled>Kirim Pendaftaran</button>
                <p style="color:red; margin-top:10px;">Pendaftaran tidak dapat diproses karena data profil Anda belum lengkap.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</form>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>