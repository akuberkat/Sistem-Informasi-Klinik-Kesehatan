<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php'; // Memastikan user login dan role adalah pasien

check_login('pasien');

$conn = connect_db();
$id_pengguna_pasien = $_SESSION['id_pengguna'];
$id_pasien = null;
$riwayat_konsultasi = [];
$error_message = '';

// Ambil id_pasien dari tabel pasien berdasarkan id_pengguna
$stmt_get_pasien = $conn->prepare("SELECT id_pasien FROM pasien WHERE id_pengguna = ?");
if ($stmt_get_pasien) {
    $stmt_get_pasien->bind_param("i", $id_pengguna_pasien);
    $stmt_get_pasien->execute();
    $result_pasien = $stmt_get_pasien->get_result();
    if ($result_pasien->num_rows > 0) {
        $pasien_data = $result_pasien->fetch_assoc();
        $id_pasien = $pasien_data['id_pasien'];
    } else {
        $error_message = "Data pasien tidak ditemukan.";
    }
    $stmt_get_pasien->close();
} else {
    $error_message = "Kesalahan dalam menyiapkan query data pasien: " . $conn->error;
}

// Jika id_pasien ditemukan, ambil riwayat konsultasi
if ($id_pasien) {
    $sql_riwayat = "SELECT
                        pk.id_pendaftaran,
                        pk.tanggal_konsultasi,
                        pk.jam_konsultasi,
                        pk.keluhan_utama,
                        pk.status_pendaftaran,
                        dok_pengguna.nama_lengkap AS nama_dokter,
                        dok.spesialisasi AS spesialisasi_dokter,
                        rm.id_rekam_medis,
                        rm.diagnosa -- Ambil diagnosa jika ada
                    FROM pendaftaran_konsultasi pk
                    JOIN dokter dok ON pk.id_dokter = dok.id_dokter
                    JOIN pengguna dok_pengguna ON dok.id_pengguna = dok_pengguna.id_pengguna
                    LEFT JOIN rekam_medis rm ON pk.id_pendaftaran = rm.id_pendaftaran -- LEFT JOIN karena rekam medis mungkin belum ada
                    WHERE pk.id_pasien = ?
                    ORDER BY pk.tanggal_konsultasi DESC, pk.jam_konsultasi DESC";

    $stmt_riwayat = $conn->prepare($sql_riwayat);
    if ($stmt_riwayat) {
        $stmt_riwayat->bind_param("i", $id_pasien);
        $stmt_riwayat->execute();
        $result_riwayat = $stmt_riwayat->get_result();
        while ($row = $result_riwayat->fetch_assoc()) {
            $riwayat_konsultasi[] = $row;
        }
        $stmt_riwayat->close();
    } else {
        $error_message = "Gagal mengambil data riwayat konsultasi: " . $conn->error;
    }
}

$conn->close();
?>

<?php $page_title = "Riwayat Konsultasi"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Riwayat Konsultasi Saya</h1>
</div>

<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<?php if (empty($riwayat_konsultasi) && empty($error_message)): ?>
    <div class="alert alert-info">Anda belum memiliki riwayat konsultasi. <a href="pendaftaran_konsultasi.php">Buat pendaftaran baru?</a></div>
<?php elseif (!empty($riwayat_konsultasi)): ?>
    <div class="card">
        <div class="card-header">
            <h6>Daftar Konsultasi</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Tanggal & Jam</th>
                            <th>Dokter</th>
                            <th>Spesialisasi</th>
                            <th>Keluhan Utama</th>
                            <th>Status</th>
                            <th>Diagnosa (Jika Selesai)</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($riwayat_konsultasi as $index => $konsultasi): ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td>
                                    <?php echo htmlspecialchars(format_tanggal_indonesia($konsultasi['tanggal_konsultasi'])); ?>
                                    <br>
                                    <small><?php echo htmlspecialchars(date("H:i", strtotime($konsultasi['jam_konsultasi']))); ?> WIB</small>
                                </td>
                                <td><?php echo htmlspecialchars($konsultasi['nama_dokter']); ?></td>
                                <td><?php echo htmlspecialchars($konsultasi['spesialisasi_dokter']); ?></td>
                                <td><?php echo nl2br(htmlspecialchars($konsultasi['keluhan_utama'])); ?></td>
                                <td>
                                    <?php
                                    $status_class = '';
                                    switch ($konsultasi['status_pendaftaran']) {
                                        case 'Menunggu Konfirmasi': $status_class = 'badge badge-warning'; break;
                                        case 'Dikonfirmasi': $status_class = 'badge badge-info'; break;
                                        case 'Selesai': $status_class = 'badge badge-success'; break;
                                        case 'Dibatalkan': $status_class = 'badge badge-danger'; break;
                                        default: $status_class = 'badge badge-secondary'; break;
                                    }
                                    ?>
                                    <span class="<?php echo $status_class; ?>"><?php echo htmlspecialchars($konsultasi['status_pendaftaran']); ?></span>
                                </td>
                                <td>
                                    <?php if ($konsultasi['status_pendaftaran'] == 'Selesai' && !empty($konsultasi['diagnosa'])): ?>
                                        <?php echo nl2br(htmlspecialchars($konsultasi['diagnosa'])); ?>
                                    <?php elseif ($konsultasi['status_pendaftaran'] == 'Selesai' && empty($konsultasi['diagnosa'])): ?>
                                        <small><em>Belum ada diagnosa.</em></small>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($konsultasi['status_pendaftaran'] == 'Selesai' && !empty($konsultasi['id_rekam_medis'])): ?>
                                        <a href="detail_rekam_medis.php?id_rm=<?php echo $konsultasi['id_rekam_medis']; ?>" class="btn btn-sm btn-primary">Lihat Detail RM</a>
                                    <?php elseif ($konsultasi['status_pendaftaran'] == 'Menunggu Konfirmasi' || $konsultasi['status_pendaftaran'] == 'Dikonfirmasi'): ?>
                                        <small><em>Tidak ada aksi</em></small>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>