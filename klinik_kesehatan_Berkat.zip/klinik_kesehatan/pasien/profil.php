<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('pasien');

$conn = connect_db();
$id_pengguna = $_SESSION['id_pengguna'];
$profil_pasien = null;
$error_message = '';
$success_message = '';

// Ambil data profil gabungan dari tabel pengguna dan pasien
$stmt_profil = $conn->prepare("SELECT
                                p.username, p.nama_lengkap, p.email, p.nomor_telepon, p.alamat,
                                ps.id_pasien, ps.nomor_rekam_medis, ps.tanggal_lahir, ps.jenis_kelamin, ps.foto_profil
                               FROM pengguna p
                               JOIN pasien ps ON p.id_pengguna = ps.id_pengguna
                               WHERE p.id_pengguna = ?");
if ($stmt_profil) {
    $stmt_profil->bind_param("i", $id_pengguna);
    $stmt_profil->execute();
    $result_profil = $stmt_profil->get_result();
    if ($result_profil->num_rows > 0) {
        $profil_pasien = $result_profil->fetch_assoc();
    } else {
        $error_message = "Data profil tidak ditemukan.";
    }
    $stmt_profil->close();
} else {
    $error_message = "Kesalahan query profil: " . $conn->error;
}

// Proses Update Profil
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profil']) && $profil_pasien) {
    $nama_lengkap = sanitize_input($_POST['nama_lengkap']);
    $email = sanitize_input($_POST['email']);
    $nomor_telepon = sanitize_input($_POST['nomor_telepon']);
    $alamat = sanitize_input($_POST['alamat']);
    $tanggal_lahir = sanitize_input($_POST['tanggal_lahir']);
    $jenis_kelamin = sanitize_input($_POST['jenis_kelamin']);
    // Untuk password dan foto profil, perlu penanganan khusus
    // $new_password = $_POST['new_password']; // Jika ada field password baru

    // Validasi
    if (empty($nama_lengkap) || empty($email)) {
        $error_message = "Nama Lengkap dan Email wajib diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Format email tidak valid.";
    } else {
        // Cek apakah email baru (jika berubah) sudah digunakan pengguna lain
        if (strtolower($email) != strtolower($profil_pasien['email'])) {
            $stmt_cek_email = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE email = ? AND id_pengguna != ?");
            $stmt_cek_email->bind_param("si", $email, $id_pengguna);
            $stmt_cek_email->execute();
            if ($stmt_cek_email->get_result()->num_rows > 0) {
                $error_message = "Email tersebut sudah digunakan oleh pengguna lain.";
            }
            $stmt_cek_email->close();
        }

        if (empty($error_message)) {
            $conn->begin_transaction(); // Mulai transaksi

            try {
                // Update tabel pengguna
                // Tambahkan logika untuk update password jika field password diisi
                // $password_query_part = "";
                // if (!empty($new_password)) {
                //     $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                //     $password_query_part = ", password = ?";
                // }
                // $sql_update_pengguna = "UPDATE pengguna SET nama_lengkap = ?, email = ?, nomor_telepon = ?, alamat = ? $password_query_part WHERE id_pengguna = ?";

                $sql_update_pengguna = "UPDATE pengguna SET nama_lengkap = ?, email = ?, nomor_telepon = ?, alamat = ? WHERE id_pengguna = ?";
                $stmt_update_pengguna = $conn->prepare($sql_update_pengguna);

                // if (!empty($new_password)) {
                //    $stmt_update_pengguna->bind_param("sssssi", $nama_lengkap, $email, $nomor_telepon, $alamat, $hashed_password, $id_pengguna);
                // } else {
                   $stmt_update_pengguna->bind_param("ssssi", $nama_lengkap, $email, $nomor_telepon, $alamat, $id_pengguna);
                // }
                $stmt_update_pengguna->execute();

                // Update tabel pasien
                // Tambahkan logika untuk upload foto profil
                $sql_update_pasien = "UPDATE pasien SET tanggal_lahir = ?, jenis_kelamin = ? WHERE id_pengguna = ?";
                $stmt_update_pasien = $conn->prepare($sql_update_pasien);
                $stmt_update_pasien->bind_param("ssi", $tanggal_lahir, $jenis_kelamin, $id_pengguna);
                $stmt_update_pasien->execute();

                $conn->commit(); // Commit transaksi jika semua berhasil
                $success_message = "Profil berhasil diperbarui.";

                // Update session jika nama berubah
                $_SESSION['nama_lengkap'] = $nama_lengkap;

                // Re-fetch profil untuk menampilkan data terbaru
                $stmt_profil->execute(); // Re-execute query profil yang sudah di-prepare
                $profil_pasien = $stmt_profil->get_result()->fetch_assoc();

            } catch (mysqli_sql_exception $exception) {
                $conn->rollback(); // Rollback jika ada error
                $error_message = "Gagal memperbarui profil: " . $exception->getMessage();
            }

            if(isset($stmt_update_pengguna)) $stmt_update_pengguna->close();
            if(isset($stmt_update_pasien)) $stmt_update_pasien->close();
        }
    }
}


// Proses Ganti Password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ganti_password']) && $profil_pasien) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];

    if (empty($current_password) || empty($new_password) || empty($confirm_new_password)) {
        $error_message = "Semua field password wajib diisi untuk ganti password.";
    } elseif ($new_password != $confirm_new_password) {
        $error_message = "Password baru dan konfirmasi password tidak cocok.";
    } elseif (strlen($new_password) < 6) { // Contoh validasi panjang password
        $error_message = "Password baru minimal 6 karakter.";
    } else {
        // Verifikasi password saat ini
        $stmt_pass = $conn->prepare("SELECT password FROM pengguna WHERE id_pengguna = ?");
        $stmt_pass->bind_param("i", $id_pengguna);
        $stmt_pass->execute();
        $result_pass = $stmt_pass->get_result();
        $user_data = $result_pass->fetch_assoc();
        $stmt_pass->close();

        if ($user_data && password_verify($current_password, $user_data['password'])) {
            $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt_update_pass = $conn->prepare("UPDATE pengguna SET password = ? WHERE id_pengguna = ?");
            $stmt_update_pass->bind_param("si", $hashed_new_password, $id_pengguna);
            if ($stmt_update_pass->execute()) {
                $success_message = "Password berhasil diganti.";
            } else {
                $error_message = "Gagal mengganti password: " . $stmt_update_pass->error;
            }
            $stmt_update_pass->close();
        } else {
            $error_message = "Password saat ini salah.";
        }
    }
}


$conn->close();
?>

<?php $page_title = "Profil Saya"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Profil Saya</h1>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<?php if ($profil_pasien): ?>
<div class="row">
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header">
                <h6>Foto Profil</h6>
            </div>
            <div class="card-body text-center">
                <img src="../assets/images/berkat.<?php echo !empty($profil_pasien['foto_profil']) ? htmlspecialchars($profil_pasien['foto_profil']) : 'default_pasien.png'; ?>"
                     alt="Foto Profil" class="img-fluid rounded-circle" style="width: 150px; height: 150px; object-fit: cover; border: 3px solid #ddd;">
                <h5 class="mt-3"><?php echo htmlspecialchars($profil_pasien['nama_lengkap']); ?></h5>
                <p class="text-muted">No. RM: <?php echo htmlspecialchars($profil_pasien['nomor_rekam_medis']); ?></p>
                </div>
        </div>

        <div class="card">
             <div class="card-header">
                <h6>Ganti Password</h6>
            </div>
            <div class="card-body">
                <form action="profil.php" method="POST">
                    <input type="hidden" name="ganti_password" value="1">
                    <div class="form-group">
                        <label for="current_password">Password Saat Ini</label>
                        <input type="password" name="current_password" id="current_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">Password Baru</label>
                        <input type="password" name="new_password" id="new_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_new_password">Konfirmasi Password Baru</label>
                        <input type="password" name="confirm_new_password" id="confirm_new_password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-warning btn-block">Ganti Password</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                 <h6>Informasi Profil</h6>
                 <button class="btn btn-sm btn-info" onclick="toggleEditForm()">Edit Profil</button>
            </div>
            <div class="card-body">
                <table class="table table-borderless profile-table">
                    <tr>
                        <th width="30%">Username</th>
                        <td>: <?php echo htmlspecialchars($profil_pasien['username']); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Lengkap</th>
                        <td>: <?php echo htmlspecialchars($profil_pasien['nama_lengkap']); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td>: <?php echo htmlspecialchars($profil_pasien['email']); ?></td>
                    </tr>
                    <tr>
                        <th>Nomor Telepon</th>
                        <td>: <?php echo htmlspecialchars($profil_pasien['nomor_telepon'] ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td>: <?php echo nl2br(htmlspecialchars($profil_pasien['alamat'] ?: '-')); ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Lahir</th>
                        <td>: <?php echo htmlspecialchars(format_tanggal_indonesia($profil_pasien['tanggal_lahir']) ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Jenis Kelamin</th>
                        <td>: <?php echo htmlspecialchars($profil_pasien['jenis_kelamin'] ?: '-'); ?></td>
                    </tr>
                </table>

                <div id="editProfileForm" style="display:none; margin-top: 20px; padding-top:20px; border-top: 1px solid #eee;">
                    <h5>Edit Informasi Profil</h5>
                    <form action="profil.php" method="POST">
                        <input type="hidden" name="update_profil" value="1">
                        <div class="form-group">
                            <label for="nama_lengkap">Nama Lengkap <span style="color:red;">*</span></label>
                            <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" value="<?php echo htmlspecialchars($profil_pasien['nama_lengkap']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email <span style="color:red;">*</span></label>
                            <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($profil_pasien['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="nomor_telepon">Nomor Telepon</label>
                            <input type="tel" name="nomor_telepon" id="nomor_telepon" class="form-control" value="<?php echo htmlspecialchars($profil_pasien['nomor_telepon']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <textarea name="alamat" id="alamat" rows="3" class="form-control"><?php echo htmlspecialchars($profil_pasien['alamat']); ?></textarea>
                        </div>
                         <div class="form-group">
                            <label for="tanggal_lahir">Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control" value="<?php echo htmlspecialchars($profil_pasien['tanggal_lahir']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="jenis_kelamin">Jenis Kelamin</label>
                            <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                                <option value="Laki-laki" <?php echo ($profil_pasien['jenis_kelamin'] == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
                                <option value="Perempuan" <?php echo ($profil_pasien['jenis_kelamin'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success">Simpan Perubahan</button>
                        <button type="button" class="btn btn-secondary" onclick="toggleEditForm()">Batal</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .profile-table th { text-align: left; font-weight: bold; }
    .profile-table td { padding-left: 10px; }
</style>

<script>
function toggleEditForm() {
    var form = document.getElementById('editProfileForm');
    var displayInfo = document.querySelector('.profile-table'); // Asumsi tabel info utama
    if (form.style.display === 'none') {
        form.style.display = 'block';
        // displayInfo.style.display = 'none'; // Opsional: sembunyikan info display saat form muncul
    } else {
        form.style.display = 'none';
        // displayInfo.style.display = 'table'; // Opsional: tampilkan kembali info display
    }
}
</script>

<?php else: ?>
    <div class="alert alert-warning">Tidak dapat memuat data profil. Silakan coba lagi atau hubungi administrator.</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>