<?php
session_start();

// Include file-file yang dibutuhkan
require_once 'config/database.php';
require_once 'includes/functions.php';

// Jika pengguna sudah login, arahkan ke dashboard yang sesuai
if (isset($_SESSION['id_pengguna']) && isset($_SESSION['role'])) {
    redirect_to_dashboard($_SESSION['role']);
}

$error_message = '';
$username_value = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = sanitize_input($_POST['username']);
        $password = $_POST['password'];
        $username_value = $username;

        if (empty($username) || empty($password)) {
            $error_message = "Username dan Password wajib diisi.";
        } else {
            $conn = connect_db();
            if (!$conn) {
                $error_message = "Kesalahan koneksi ke database. Silakan coba lagi nanti.";
            } else {
                $stmt = $conn->prepare("SELECT id_pengguna, username, password, role, nama_lengkap, status_akun FROM pengguna WHERE username = ?");
                if (!$stmt) {
                    $error_message = "Kesalahan internal server (prepare failed): " . $conn->error;
                } else {
                    $stmt->bind_param("s", $username);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows == 1) {
                        $user = $result->fetch_assoc();

                        if ($user['status_akun'] == 0) {
                            $error_message = "Akun Anda tidak aktif. Silakan hubungi administrator.";
                        } elseif (password_verify($password, $user['password'])) {
                            $_SESSION['id_pengguna'] = $user['id_pengguna'];
                            $_SESSION['username'] = $user['username'];
                            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
                            $_SESSION['role'] = $user['role'];

                            $update_stmt = $conn->prepare("UPDATE pengguna SET tanggal_login_terakhir = NOW() WHERE id_pengguna = ?");
                            if ($update_stmt) {
                                $update_stmt->bind_param("i", $user['id_pengguna']);
                                $update_stmt->execute();
                                $update_stmt->close();
                            }

                            redirect_to_dashboard($user['role']);
                        } else {
                            $error_message = "Username atau Password salah.";
                        }
                    } else {
                        $error_message = "Username atau Password salah.";
                    }
                    $stmt->close();
                }
                $conn->close();
            }
        }
    } else {
        $error_message = "Formulir tidak lengkap.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login - Sistem Informasi Klinik Berkat</title>
    
    <!-- Google Fonts: Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #d1fae5; /* Hijau muda sesuai index.php */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            box-sizing: border-box;
        }
        .login-container {
            background: linear-gradient(180deg, rgb(136, 214, 178) 0%, #6ee7b7 100%);
            padding: 40px 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            color: #065f46;
            text-align: center;
        }
        .login-container img.logo {
            max-width: 120px;
            margin-bottom: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .login-container h2 {
            font-weight: 800;
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .login-container p.subtitle {
            font-weight: 400;
            font-size: 1.1rem;
            margin-bottom: 25px;
            color: #065f46cc;
        }
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        .form-group label {
            font-weight: 600;
            font-size: 0.95rem;
            color: #065f46dd;
            display: block;
            margin-bottom: 8px;
        }
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #7dd3fc; /* border biru muda */
            border-radius: 30px;
            font-size: 1rem;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }
        .form-group input[type="text"]:focus,
        .form-group input[type="password"]:focus {
            border-color: #0f8d65; /* hijau toska fokus */
            outline: none;
            box-shadow: 0 0 8px #0f8d65aa;
        }
        .login-button {
            background-color: #ffffff;
            color: rgb(15, 141, 101);
            font-weight: 600;
            border-radius: 30px;
            padding: 12px 0;
            border: 2px solid #ffffff;
            width: 100%;
            font-size: 1.1rem;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: background-color 0.3s ease-in-out, color 0.3s ease-in-out;
        }
        .login-button:hover {
            background-color: #ecfdf5;
            color: #065f46;
            border-color: #065f46;
        }
        .register-link {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #065f46cc;
        }
        .register-link a {
            color: #065f46;
            font-weight: 600;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
        .error-message-login {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 6px;
            font-size: 0.9em;
            text-align: left;
        }
        /* Debug info styles */
        .debug-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 6px;
            font-size: 0.85em;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="login-container" data-aos="fade-up">
        <img src="assets/images/logoku.png" alt="Logo Klinik Berkat" class="logo" />
        <h2>Selamat Datang!</h2>
        <p class="subtitle">Silakan login untuk mengakses sistem informasi klinik.</p>

        <?php if (!empty($error_message)): ?>
            <div class="error-message-login">
                <i class="fas fa-exclamation-triangle"></i> <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <!-- Debug: Tampilkan informasi untuk testing (hapus setelah selesai debug) -->
        <?php if (isset($_POST['username']) && !empty($_POST['username'])): ?>
            <div class="debug-info">
                <strong>Debug Info:</strong><br />
                Username yang diinput: <?php echo htmlspecialchars($_POST['username']); ?><br />
                Password length: <?php echo strlen($_POST['password']); ?> karakter
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST" novalidate>
            <div class="form-group">
                <label for="username">Username</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Masukkan username Anda"
                    value="<?php echo htmlspecialchars($username_value); ?>"
                    required
                    autocomplete="username"
                />
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Masukkan password Anda"
                    required
                    autocomplete="current-password"
                />
            </div>
            <button type="submit" class="login-button">
                Login <i class="fas fa-sign-in-alt"></i>
            </button>
        </form>

        <div class="register-link">
            Pasien baru? <a href="register.php">Daftar di sini</a>
        </div>
    </div>

    <!-- Bootstrap JS & AOS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
</body>
</html>
