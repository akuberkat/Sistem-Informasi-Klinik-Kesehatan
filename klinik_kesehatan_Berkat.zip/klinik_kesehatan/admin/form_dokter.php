<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('admin');
$conn = connect_db();
$page_title = "Tambah Dokter Baru";
$action = "tambah";

$dokter_data = [
    'id_pengguna' => null, 'username' => '', 'nama_lengkap' => '', 'email' => '',
    'nomor_telepon' => '', 'alamat' => '', 'password' => '',
    'id_dokter' => null, 'spesialisasi' => '', 'nomor_sip' => '', 'foto_profil' => ''
];
$error_message = '';
$success_message = '';


if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id_pengguna'])) {
    $page_title = "Edit Data Dokter";
    $action = "edit";
    $id_pengguna_edit = intval($_GET['id_pengguna']);

    $stmt = $conn->prepare("SELECT u.*, d.id_dokter, d.spesialisasi, d.nomor_sip, d.foto_profil
                           FROM pengguna u
                           LEFT JOIN dokter d ON u.id_pengguna = d.id_pengguna
                           WHERE u.id_pengguna = ? AND u.role = 'dokter'");
    if ($stmt) {
        $stmt->bind_param("i", $id_pengguna_edit);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $dokter_data_db = $result->fetch_assoc();
            // Map to $dokter_data, ensure all keys exist
            foreach ($dokter_data_db as $key => $value) {
                if (array_key_exists($key, $dokter_data)) {
                    $dokter_data[$key] = $value;
                }
            }
             // Ensure specific doctor fields are mapped if not directly named
            if(isset($dokter_data_db['id_dokter'])) $dokter_data['id_dokter'] = $dokter_data_db['id_dokter'];
            if(isset($dokter_data_db['spesialisasi'])) $dokter_data['spesialisasi'] = $dokter_data_db['spesialisasi'];
            if(isset($dokter_data_db['nomor_sip'])) $dokter_data['nomor_sip'] = $dokter_data_db['nomor_sip'];
            if(isset($dokter_data_db['foto_profil'])) $dokter_data['foto_profil'] = $dokter_data_db['foto_profil'];

        } else {
            $_SESSION['error_message'] = "Data dokter tidak ditemukan atau bukan role dokter.";
            header("Location: kelola_dokter.php");
            exit;
        }
        $stmt->close();
    } else {
        $_SESSION['error_message'] = "Gagal menyiapkan query: " . $conn->error;
        header("Location: kelola_dokter.php");
        exit;
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize_input($_POST['username']);
    $nama_lengkap = sanitize_input($_POST['nama_lengkap']);
    $email = sanitize_input($_POST['email']);
    $password_input = $_POST['password']; // Jangan sanitize password sebelum hash
    $nomor_telepon = sanitize_input($_POST['nomor_telepon']);
    $alamat = sanitize_input($_POST['alamat']);
    $spesialisasi = sanitize_input($_POST['spesialisasi']);
    $nomor_sip = sanitize_input($_POST['nomor_sip']);
    $role = 'dokter'; // Fixed role

    $current_foto = isset($_POST['current_foto_profil']) ? $_POST['current_foto_profil'] : '';
    $new_foto_filename = $current_foto; // Default to current foto

    // Validasi Dasar
    if (empty($username) || empty($nama_lengkap) || empty($email) || empty($spesialisasi)) {
        $error_message = "Username, Nama Lengkap, Email, dan Spesialisasi wajib diisi.";
    } elseif ($action == 'tambah' && empty($password_input)) {
        $error_message = "Password wajib diisi untuk dokter baru.";
    } elseif (strlen($password_input) > 0 && strlen($password_input) < 6) {
        $error_message = "Password minimal 6 karakter.";
    } else {
        // Handle Foto Profil Upload
        if (isset($_FILES['foto_profil']) && $_FILES['foto_profil']['error'] == UPLOAD_ERR_OK) {
            $upload_dir = '../assets/images/foto_dokter/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

            $file_extension = strtolower(pathinfo($_FILES['foto_profil']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            $max_file_size = 2 * 1024 * 1024; // 2MB

            if (!in_array($file_extension, $allowed_extensions)) {
                $error_message = "Format file foto tidak valid. Hanya JPG, JPEG, PNG, GIF.";
            } elseif ($_FILES['foto_profil']['size'] > $max_file_size) {
                $error_message = "Ukuran file foto terlalu besar (Maks 2MB).";
            } else {
                // Hapus foto lama jika ada dan bukan default, dan foto baru diupload
                if (!empty($current_foto) && $current_foto != 'default_dokter.png' && file_exists($upload_dir . $current_foto)) {
                    unlink($upload_dir . $current_foto);
                }
                $new_foto_filename = "dokter_" . time() . "_" . rand(1000,9999) . "." . $file_extension;
                if (!move_uploaded_file($_FILES['foto_profil']['tmp_name'], $upload_dir . $new_foto_filename)) {
                    $error_message = "Gagal upload foto profil.";
                    $new_foto_filename = $current_foto; // Kembalikan ke foto lama jika upload gagal
                }
            }
        } elseif (isset($_FILES['foto_profil']) && $_FILES['foto_profil']['error'] != UPLOAD_ERR_NO_FILE) {
             $error_message = "Error saat upload foto: " . $_FILES['foto_profil']['error'];
        }


        if (empty($error_message)) {
            $conn->begin_transaction();
            try {
                if ($action == 'tambah') {
                    // Cek username & email unik
                    $stmt_cek = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE username = ? OR email = ?");
                    $stmt_cek->bind_param("ss", $username, $email);
                    $stmt_cek->execute();
                    if($stmt_cek->get_result()->num_rows > 0) {
                        throw new Exception("Username atau Email sudah terdaftar.");
                    }
                    $stmt_cek->close();

                    $hashed_password = password_hash($password_input, PASSWORD_DEFAULT);
                    $stmt_pengguna = $conn->prepare("INSERT INTO pengguna (username, password, nama_lengkap, email, nomor_telepon, alamat, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    if (!$stmt_pengguna) throw new Exception("Gagal siapkan pengguna (tambah): ".$conn->error);
                    $stmt_pengguna->bind_param("sssssss", $username, $hashed_password, $nama_lengkap, $email, $nomor_telepon, $alamat, $role);
                    if (!$stmt_pengguna->execute()) throw new Exception("Gagal simpan pengguna: ".$stmt_pengguna->error);
                    $id_pengguna_baru = $stmt_pengguna->insert_id;
                    $stmt_pengguna->close();

                    $stmt_dokter = $conn->prepare("INSERT INTO dokter (id_pengguna, spesialisasi, nomor_sip, foto_profil) VALUES (?, ?, ?, ?)");
                    if (!$stmt_dokter) throw new Exception("Gagal siapkan dokter (tambah): ".$conn->error);
                    $stmt_dokter->bind_param("isss", $id_pengguna_baru, $spesialisasi, $nomor_sip, $new_foto_filename);
                    if (!$stmt_dokter->execute()) throw new Exception("Gagal simpan dokter: ".$stmt_dokter->error);
                    $stmt_dokter->close();
                    $_SESSION['success_message'] = "Dokter baru berhasil ditambahkan.";

                } elseif ($action == 'edit' && isset($_POST['id_pengguna_hidden'])) {
                    $id_pengguna_update = intval($_POST['id_pengguna_hidden']);
                     // Cek email unik (jika berubah)
                    if (strtolower($email) != strtolower($dokter_data['email'])) { // Asumsi $dokter_data sudah terisi data lama
                        $stmt_cek_email = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE email = ? AND id_pengguna != ?");
                        $stmt_cek_email->bind_param("si", $email, $id_pengguna_update);
                        $stmt_cek_email->execute();
                        if ($stmt_cek_email->get_result()->num_rows > 0) {
                            throw new Exception("Email sudah digunakan oleh pengguna lain.");
                        }
                        $stmt_cek_email->close();
                    }


                    $sql_update_pengguna = "UPDATE pengguna SET nama_lengkap = ?, email = ?, nomor_telepon = ?, alamat = ?";
                    $params_pengguna = [$nama_lengkap, $email, $nomor_telepon, $alamat];
                    $types_pengguna = "ssss";
                    if (!empty($password_input)) {
                        $hashed_password = password_hash($password_input, PASSWORD_DEFAULT);
                        $sql_update_pengguna .= ", password = ?";
                        $params_pengguna[] = $hashed_password;
                        $types_pengguna .= "s";
                    }
                    $sql_update_pengguna .= " WHERE id_pengguna = ?";
                    $params_pengguna[] = $id_pengguna_update;
                    $types_pengguna .= "i";

                    $stmt_pengguna = $conn->prepare($sql_update_pengguna);
                    if (!$stmt_pengguna) throw new Exception("Gagal siapkan pengguna (edit): ".$conn->error);
                    $stmt_pengguna->bind_param($types_pengguna, ...$params_pengguna);
                    if (!$stmt_pengguna->execute()) throw new Exception("Gagal update pengguna: ".$stmt_pengguna->error);
                    $stmt_pengguna->close();

                    // Update dokter, cek dulu jika ada id_dokter (misal dari admin menambah user lalu promote jadi dokter)
                    if($dokter_data['id_dokter']){
                        $stmt_dokter = $conn->prepare("UPDATE dokter SET spesialisasi = ?, nomor_sip = ?, foto_profil = ? WHERE id_pengguna = ?");
                         if (!$stmt_dokter) throw new Exception("Gagal siapkan dokter (edit): ".$conn->error);
                        $stmt_dokter->bind_param("sssi", $spesialisasi, $nomor_sip, $new_foto_filename, $id_pengguna_update);
                    } else { // Jika belum ada entri dokter (misal pengguna biasa dipromote jadi dokter)
                        $stmt_dokter = $conn->prepare("INSERT INTO dokter (id_pengguna, spesialisasi, nomor_sip, foto_profil) VALUES (?, ?, ?, ?)");
                        if (!$stmt_dokter) throw new Exception("Gagal siapkan dokter (insert on edit): ".$conn->error);
                        $stmt_dokter->bind_param("isss", $id_pengguna_update, $spesialisasi, $nomor_sip, $new_foto_filename);
                    }
                    if (!$stmt_dokter->execute()) throw new Exception("Gagal simpan data dokter: ".$stmt_dokter->error);
                    $stmt_dokter->close();
                    $_SESSION['success_message'] = "Data dokter berhasil diperbarui.";
                }
                $conn->commit();
                header("Location: kelola_dokter.php");
                exit;
            } catch (Exception $e) {
                $conn->rollback();
                $error_message = $e->getMessage();
            }
        }
    }
    // Repopulate $dokter_data on error for sticky form
    $dokter_data['username'] = $username;
    $dokter_data['nama_lengkap'] = $nama_lengkap;
    $dokter_data['email'] = $email;
    $dokter_data['nomor_telepon'] = $nomor_telepon;
    $dokter_data['alamat'] = $alamat;
    $dokter_data['spesialisasi'] = $spesialisasi;
    $dokter_data['nomor_sip'] = $nomor_sip;
    $dokter_data['foto_profil'] = $new_foto_filename; // Tampilkan foto yg baru diupload jika ada, atau yg lama
}

?>
<?php include '../includes/header.php'; ?>
<div class="page-header">
    <h1><?php echo $page_title; ?></h1>
    <a href="kelola_dokter.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left"></i> Kembali ke Daftar Dokter</a>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <form action="form_dokter.php<?php echo ($action == 'edit' && $dokter_data['id_pengguna']) ? '?action=edit&id_pengguna='.$dokter_data['id_pengguna'] : ''; ?>" method="POST" enctype="multipart/form-data">
            <?php if ($action == 'edit' && $dokter_data['id_pengguna']): ?>
                <input type="hidden" name="id_pengguna_hidden" value="<?php echo $dokter_data['id_pengguna']; ?>">
                <input type="hidden" name="current_foto_profil" value="<?php echo htmlspecialchars($dokter_data['foto_profil']); ?>">
            <?php endif; ?>

            <h5>Data Akun Pengguna</h5>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="username">Username <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($dokter_data['username']); ?>" <?php echo ($action == 'edit') ? 'readonly' : 'required'; ?>>
                     <?php if ($action == 'edit'): ?><small class="form-text text-muted">Username tidak dapat diubah.</small><?php endif; ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="password">Password <?php echo ($action == 'tambah') ? '<span class="text-danger">*</span>' : ''; ?></label>
                    <input type="password" class="form-control" id="password" name="password" <?php echo ($action == 'tambah') ? 'required' : ''; ?>>
                    <?php if ($action == 'edit'): ?><small class="form-text text-muted">Kosongkan jika tidak ingin mengubah password.</small><?php endif; ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="nama_lengkap">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?php echo htmlspecialchars($dokter_data['nama_lengkap']); ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="email">Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($dokter_data['email']); ?>" required>
                </div>
            </div>
             <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="nomor_telepon">Nomor Telepon</label>
                    <input type="tel" class="form-control" id="nomor_telepon" name="nomor_telepon" value="<?php echo htmlspecialchars($dokter_data['nomor_telepon']); ?>">
                </div>
                 <div class="form-group col-md-6">
                    <label for="alamat">Alamat</label>
                    <textarea class="form-control" id="alamat" name="alamat" rows="2"><?php echo htmlspecialchars($dokter_data['alamat']); ?></textarea>
                </div>
            </div>
            <hr>
            <h5>Data Spesifik Dokter</h5>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="spesialisasi">Spesialisasi <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="spesialisasi" name="spesialisasi" value="<?php echo htmlspecialchars($dokter_data['spesialisasi']); ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="nomor_sip">Nomor SIP</label>
                    <input type="text" class="form-control" id="nomor_sip" name="nomor_sip" value="<?php echo htmlspecialchars($dokter_data['nomor_sip']); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="foto_profil">Foto Profil</label>
                <input type="file" class="form-control-file" id="foto_profil" name="foto_profil">
                <?php if ($action == 'edit' && !empty($dokter_data['foto_profil']) && $dokter_data['foto_profil'] != 'default_dokter.png'): ?>
                    <small class="form-text text-muted">Foto saat ini: <a href="../assets/images/foto_dokter/<?php echo htmlspecialchars($dokter_data['foto_profil']); ?>" target="_blank"><?php echo htmlspecialchars($dokter_data['foto_profil']); ?></a>. Upload file baru untuk mengganti.</small>
                <?php elseif ($action == 'edit' && ($dokter_data['foto_profil'] == 'default_dokter.png' || empty($dokter_data['foto_profil']))): ?>
                     <small class="form-text text-muted">Belum ada foto profil (menggunakan default). Upload file baru untuk menambah.</small>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?php echo ($action == 'edit') ? 'Simpan Perubahan' : 'Tambah Dokter'; ?></button>
        </form>
    </div>
</div>
<?php include '../includes/footer.php'; ?>