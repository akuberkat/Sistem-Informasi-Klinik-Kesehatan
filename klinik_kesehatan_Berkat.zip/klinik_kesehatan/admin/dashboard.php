<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('admin');

$conn = connect_db();
$nama_admin = $_SESSION['nama_lengkap'];
$error_message = '';

// Statistik
$total_pengguna = 0;
$total_pasien = 0;
$total_dokter = 0;
$total_resepsionis = 0;
$pendaftaran_bulan_ini = 0;
$konsultasi_selesai_bulan_ini = 0;

// 1. Total Pengguna per role
$stmt_roles = $conn->prepare("SELECT role, COUNT(id_pengguna) as jumlah FROM pengguna GROUP BY role");
if ($stmt_roles) {
    $stmt_roles->execute();
    $result_roles = $stmt_roles->get_result();
    while($row = $result_roles->fetch_assoc()){
        $total_pengguna += $row['jumlah'];
        if($row['role'] == 'pasien') $total_pasien = $row['jumlah'];
        if($row['role'] == 'dokter') $total_dokter = $row['jumlah'];
        if($row['role'] == 'resepsionis') $total_resepsionis = $row['jumlah'];
    }
    $stmt_roles->close();
} else { $error_message .= " Gagal mengambil data role pengguna. "; }

// 2. Pendaftaran Bulan Ini
$bulan_ini_awal = date('Y-m-01');
$bulan_ini_akhir = date('Y-m-t');
$stmt_pendaftaran = $conn->prepare("SELECT COUNT(id_pendaftaran) AS total FROM pendaftaran_konsultasi WHERE tanggal_dibuat BETWEEN ? AND ?");
if ($stmt_pendaftaran) {
    $stmt_pendaftaran->bind_param("ss", $bulan_ini_awal, $bulan_ini_akhir);
    $stmt_pendaftaran->execute();
    $pendaftaran_bulan_ini = $stmt_pendaftaran->get_result()->fetch_assoc()['total'];
    $stmt_pendaftaran->close();
} else { $error_message .= " Gagal mengambil data pendaftaran bulan ini. "; }

// 3. Konsultasi Selesai Bulan Ini
$stmt_selesai = $conn->prepare("SELECT COUNT(id_pendaftaran) AS total FROM pendaftaran_konsultasi WHERE status_pendaftaran = 'Selesai' AND tanggal_konsultasi BETWEEN ? AND ?");
if ($stmt_selesai) {
    $stmt_selesai->bind_param("ss", $bulan_ini_awal, $bulan_ini_akhir);
    $stmt_selesai->execute();
    $konsultasi_selesai_bulan_ini = $stmt_selesai->get_result()->fetch_assoc()['total'];
    $stmt_selesai->close();
} else { $error_message .= " Gagal mengambil data konsultasi selesai bulan ini. "; }

$conn->close();
?>

<?php $page_title = "Dashboard Admin"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Dashboard Administrator</h1>
    <p class="lead">Selamat datang, <?php echo htmlspecialchars($nama_admin); ?>!</p>
</div>

<?php if (!empty($error_message)): ?>
    <div class="alert alert-warning"><?php echo "Terjadi beberapa masalah saat mengambil data: " . $error_message; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Pengguna</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_pengguna; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-users fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Pasien</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_pasien; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-user-injured fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Dokter</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_dokter; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-user-md fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-secondary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Total Resepsionis</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_resepsionis; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-user-tie fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pendaftaran Bulan Ini</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $pendaftaran_bulan_ini; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-calendar-plus fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
     <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Konsultasi Selesai (Bulan Ini)</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $konsultasi_selesai_bulan_ini; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-calendar-check fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card shadow">
            <div class="card-header">
                <h6><i class="fas fa-cogs"></i> Menu Administrasi</h6>
            </div>
            <div class="card-body">
                <a href="kelola_pengguna.php" class="btn btn-lg btn-primary m-2"><i class="fas fa-users-cog"></i> Kelola Pengguna</a>
                <a href="kelola_dokter.php" class="btn btn-lg btn-info m-2"><i class="fas fa-user-md"></i> Kelola Dokter & Jadwal</a>
                <a href="laporan.php" class="btn btn-lg btn-success m-2"><i class="fas fa-chart-line"></i> Lihat Laporan</a>
                </div>
        </div>
    </div>
</div>
<style>
    /* Warna hijau kesehatan */
    :root {
        --hijau-utama: #28a745;
        --hijau-muda: #1cc88a;
        --hijau-teal: #20c997;
        --hijau-lembut: #a8e6cf;
        --abu-tekstil: #5a5c69;
    }

    .card.border-left-primary { border-left: .25rem solid var(--hijau-utama) !important; }
    .card.border-left-success { border-left: .25rem solid var(--hijau-muda) !important; }
    .card.border-left-info   { border-left: .25rem solid var(--hijau-teal) !important; }
    .card.border-left-warning { border-left: .25rem solid #ffc107 !important; }
    .card.border-left-danger  { border-left: .25rem solid #dc3545 !important; }
    .card.border-left-secondary { border-left: .25rem solidrgb(0, 0, 0) !important; }

    .text-primary { color: var(--hijau-utama) !important; }
    .text-success { color: var(--hijau-muda) !important; }
    .text-info    { color: var(--hijau-teal) !important; }
    .text-secondary { color:rgb(0, 1, 2) !important; }

    .btn-primary { background-color: var(--hijau-utama); border-color: var(--hijau-utama); }
    .btn-primary:hover { background-color: #218838; border-color: #1e7e34; }

    .btn-success { background-color: var(--hijau-muda); border-color: var(--hijau-muda); }
    .btn-info { background-color: var(--hijau-teal); border-color: var(--hijau-teal); }

    .text-gray-300 { color: #d4edda !important; }
    .text-gray-800 { color: var(--abu-tekstil) !important; }

    .shadow {
        box-shadow: 0 .15rem 1.75rem 0 rgba(40, 167, 69, 0.15)!important;
    }

    /* Sidebar tetap dengan latar hijau tua */
.sidebar {
    background-color: #14532d !important;  /* Hijau tua solid */
    color: white;
}

/* Untuk item sidebar (jika menggunakan class nav-item dan nav-link) */
.sidebar .nav-item .nav-link {
    color: #ffffff !important;
}

.sidebar .nav-item .nav-link:hover {
    background-color: #1e7e34 !important; /* Hijau hover */
    color: #ffffff !important;
}

/* Aktif link highlight */
.sidebar .nav-item.active .nav-link {
    background-color: #1cc88a !important; /* Hijau muda untuk highlight */
    color: #ffffff !important;
}
/* Navbar atas hijau muda */
.navbar {
    background-color: #1cc88a !important;
    color: white !important;
}

/* Teks di dalam navbar */
.navbar .nav-link,
.navbar .navbar-brand,
.navbar .dropdown-toggle {
    color: #ffffff !important;
}

/* Hover efek navbar */
.navbar .nav-link:hover {
    color: #f8f9fc !important;
}

</style>

<?php include '../includes/footer.php'; ?>