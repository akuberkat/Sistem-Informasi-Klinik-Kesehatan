<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('admin');
$conn = connect_db();
$error_message = '';
$success_message = '';

$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : 'list');
$id_pengguna_edit = isset($_GET['id_pengguna']) ? intval($_GET['id_pengguna']) : (isset($_POST['id_pengguna_hidden']) ? intval($_POST['id_pengguna_hidden']) : null);

$user_data = [
    'id_pengguna' => null, 'username' => '', 'nama_lengkap' => '', 'email' => '',
    'nomor_telepon' => '', 'alamat' => '', 'role' => 'pasien', 'status_akun' => 1
];

// Handle Tambah / Edit Pengguna
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($action == 'simpan_tambah' || $action == 'simpan_edit')) {
    $username = sanitize_input($_POST['username']);
    $nama_lengkap = sanitize_input($_POST['nama_lengkap']);
    $email = sanitize_input($_POST['email']);
    $password_input = $_POST['password'];
    $role = sanitize_input($_POST['role']);
    $nomor_telepon = sanitize_input($_POST['nomor_telepon']);
    $alamat = sanitize_input($_POST['alamat']);
    $status_akun = isset($_POST['status_akun']) ? intval($_POST['status_akun']) : 0; // 1 for active, 0 for inactive


    if (empty($username) || empty($nama_lengkap) || empty($email) || empty($role)) {
        $error_message = "Username, Nama Lengkap, Email, dan Role wajib diisi.";
    } elseif (($action == 'simpan_tambah' && empty($password_input)) || (strlen($password_input) > 0 && strlen($password_input) < 6) ) {
        $error_message = ($action == 'simpan_tambah') ? "Password wajib diisi untuk pengguna baru (min 6 karakter)." : "Password baru minimal 6 karakter.";
    } else {
        try {
            if ($action == 'simpan_tambah') {
                // Cek username & email unik
                $stmt_cek = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE username = ? OR email = ?");
                $stmt_cek->bind_param("ss", $username, $email);
                $stmt_cek->execute();
                if($stmt_cek->get_result()->num_rows > 0) { throw new Exception("Username atau Email sudah terdaftar."); }
                $stmt_cek->close();

                $hashed_password = password_hash($password_input, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO pengguna (username, password, nama_lengkap, email, role, nomor_telepon, alamat, status_akun) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                if(!$stmt) throw new Exception("Gagal siapkan tambah pengguna: ".$conn->error);
                $stmt->bind_param("sssssssi", $username, $hashed_password, $nama_lengkap, $email, $role, $nomor_telepon, $alamat, $status_akun);
                if(!$stmt->execute()) throw new Exception("Gagal simpan pengguna: ".$stmt->error);
                $new_id_pengguna = $stmt->insert_id;

                // Jika role dokter, buat entri di tabel dokter (kosong dulu, bisa dilengkapi di kelola dokter)
                if ($role == 'dokter') {
                    $stmt_dok = $conn->prepare("INSERT INTO dokter (id_pengguna, spesialisasi, nomor_sip) VALUES (?, 'Belum Diisi', 'Belum Diisi')");
                    $stmt_dok->bind_param("i", $new_id_pengguna);
                    $stmt_dok->execute();
                    $stmt_dok->close();
                }
                // Jika role pasien, buat entri di tabel pasien (kosong dulu, bisa dilengkapi di data pasien oleh resepsionis/pasien sendiri)
                if ($role == 'pasien') {
                    $nomor_rm_auto = "RM" . str_pad($new_id_pengguna, 5, "0", STR_PAD_LEFT) . date("Ym");
                    $stmt_pas = $conn->prepare("INSERT INTO pasien (id_pengguna, nomor_rekam_medis) VALUES (?, ?)");
                    $stmt_pas->bind_param("is", $new_id_pengguna, $nomor_rm_auto);
                    $stmt_pas->execute();
                    $stmt_pas->close();
                }

                $stmt->close();
                $success_message = "Pengguna baru '$nama_lengkap' ($role) berhasil ditambahkan.";
                $action = 'list'; // Kembali ke list setelah berhasil

            } elseif ($action == 'simpan_edit' && $id_pengguna_edit) {
                 // Cek email unik jika berubah
                $stmt_cek_current_email = $conn->prepare("SELECT email FROM pengguna WHERE id_pengguna = ?");
                $stmt_cek_current_email->bind_param("i", $id_pengguna_edit);
                $stmt_cek_current_email->execute();
                $current_email_db = $stmt_cek_current_email->get_result()->fetch_assoc()['email'];
                $stmt_cek_current_email->close();

                if (strtolower($email) != strtolower($current_email_db)) {
                    $stmt_cek_email = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE email = ? AND id_pengguna != ?");
                    $stmt_cek_email->bind_param("si", $email, $id_pengguna_edit);
                    $stmt_cek_email->execute();
                    if ($stmt_cek_email->get_result()->num_rows > 0) { throw new Exception("Email sudah digunakan pengguna lain."); }
                    $stmt_cek_email->close();
                }

                $sql_update = "UPDATE pengguna SET nama_lengkap = ?, email = ?, role = ?, nomor_telepon = ?, alamat = ?, status_akun = ?";
                $params_update = [$nama_lengkap, $email, $role, $nomor_telepon, $alamat, $status_akun];
                $types_update = "sssssi";
                if (!empty($password_input)) {
                    $hashed_password = password_hash($password_input, PASSWORD_DEFAULT);
                    $sql_update .= ", password = ?";
                    $params_update[] = $hashed_password;
                    $types_update .= "s";
                }
                $sql_update .= " WHERE id_pengguna = ?";
                $params_update[] = $id_pengguna_edit;
                $types_update .= "i";

                $stmt = $conn->prepare($sql_update);
                if(!$stmt) throw new Exception("Gagal siapkan edit pengguna: ".$conn->error);
                $stmt->bind_param($types_update, ...$params_update);
                if(!$stmt->execute()) throw new Exception("Gagal update pengguna: ".$stmt->error);
                $stmt->close();
                $success_message = "Data pengguna '$nama_lengkap' berhasil diperbarui.";
                $action = 'list'; // Kembali ke list
            }
        } catch (Exception $e) {
            $error_message = $e->getMessage();
            // Repopulate form data for sticky form on error
            $user_data = $_POST;
            $user_data['id_pengguna'] = $id_pengguna_edit; // Keep id for edit form
        }
    }
}

// Handle Ambil Data untuk Edit
if ($action == 'edit' && $id_pengguna_edit && $_SERVER['REQUEST_METHOD'] != 'POST') { // Hanya fetch jika bukan POST (untuk menghindari override data error)
    $stmt = $conn->prepare("SELECT * FROM pengguna WHERE id_pengguna = ?");
    if($stmt){
        $stmt->bind_param("i", $id_pengguna_edit);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user_data_db = $result->fetch_assoc();
             foreach ($user_data_db as $key => $value) {
                if (array_key_exists($key, $user_data)) {
                    $user_data[$key] = $value;
                }
            }
        } else {
            $error_message = "Pengguna tidak ditemukan."; $action = 'list';
        }
        $stmt->close();
    } else { $error_message = "Gagal mengambil data pengguna untuk diedit."; $action = 'list';}
}


// Handle Hapus Pengguna (Soft delete: ubah status_akun menjadi 0 atau -1)
if ($action == 'hapus' && $id_pengguna_edit) {
    // Pastikan tidak menghapus diri sendiri atau admin utama
    if ($id_pengguna_edit == $_SESSION['id_pengguna']) {
        $error_message = "Anda tidak dapat menghapus akun Anda sendiri.";
    } else {
        // Cek apakah user yg akan dihapus adalah satu-satunya admin (jika ada logika ini)
        // Untuk contoh, kita set status_akun = 0 (Tidak Aktif)
        $stmt = $conn->prepare("UPDATE pengguna SET status_akun = 0, username = CONCAT(username, '_deleted_', id_pengguna), email = CONCAT(email, '_deleted_', id_pengguna) WHERE id_pengguna = ?");
        // Menambahkan _deleted_ pada username dan email untuk membebaskan unique constraint jika ingin mendaftar ulang
        if($stmt){
            $stmt->bind_param("i", $id_pengguna_edit);
            if($stmt->execute()){
                $success_message = "Pengguna berhasil dinonaktifkan (dihapus secara logis).";
            } else { $error_message = "Gagal menonaktifkan pengguna: " . $stmt->error; }
            $stmt->close();
        } else { $error_message = "Gagal menyiapkan statement nonaktifkan.";}
    }
    $action = 'list'; // Kembali ke list
}


// Fetch Daftar Pengguna untuk tampilan list
$user_list = [];
$filter_role_val = isset($_GET['filter_role']) ? sanitize_input($_GET['filter_role']) : '';
$search_user_val = isset($_GET['search_user']) ? sanitize_input($_GET['search_user']) : '';

$sql_users = "SELECT id_pengguna, username, nama_lengkap, email, role, nomor_telepon, tanggal_registrasi, status_akun FROM pengguna WHERE 1=1 ";
$params_user_filter = [];
$types_user_filter = "";

if (!empty($filter_role_val)) {
    $sql_users .= " AND role = ? ";
    $params_user_filter[] = $filter_role_val;
    $types_user_filter .= "s";
}
if (!empty($search_user_val)) {
    $sql_users .= " AND (nama_lengkap LIKE ? OR username LIKE ? OR email LIKE ?) ";
    $search_like_user = "%" . $search_user_val . "%";
    array_push($params_user_filter, $search_like_user, $search_like_user, $search_like_user);
    $types_user_filter .= "sss";
}
$sql_users .= " ORDER BY nama_lengkap ASC";

$stmt_users = $conn->prepare($sql_users);
if($stmt_users){
    if(!empty($params_user_filter)){
        $stmt_users->bind_param($types_user_filter, ...$params_user_filter);
    }
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();
    while($row = $result_users->fetch_assoc()){
        $user_list[] = $row;
    }
    $stmt_users->close();
} else {
    $error_message .= " Gagal mengambil daftar pengguna: " . $conn->error;
}

$conn->close();
$roles_option = ['pasien', 'dokter', 'resepsionis', 'admin'];
?>

<?php $page_title = "Kelola Pengguna Sistem"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header d-flex justify-content-between align-items-center">
    <h1><?php echo $page_title; ?></h1>
    <?php if ($action == 'list'): ?>
    <a href="kelola_pengguna.php?action=tambah" class="btn btn-success"><i class="fas fa-user-plus"></i> Tambah Pengguna Baru</a>
    <?php else: ?>
    <a href="kelola_pengguna.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left"></i> Kembali ke Daftar Pengguna</a>
    <?php endif; ?>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>


<?php if ($action == 'tambah' || $action == 'edit'): ?>
<div class="card">
    <div class="card-header">
        <h6><i class="fas fa-user-edit"></i> <?php echo ($action == 'tambah') ? 'Form Tambah Pengguna Baru' : 'Form Edit Pengguna: ' . htmlspecialchars($user_data['nama_lengkap']); ?></h6>
    </div>
    <div class="card-body">
        <form action="kelola_pengguna.php" method="POST">
            <input type="hidden" name="action" value="<?php echo ($action == 'tambah') ? 'simpan_tambah' : 'simpan_edit'; ?>">
            <?php if ($action == 'edit' && $user_data['id_pengguna']): ?>
                <input type="hidden" name="id_pengguna_hidden" value="<?php echo $user_data['id_pengguna']; ?>">
            <?php endif; ?>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="username">Username <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user_data['username']); ?>" <?php echo ($action == 'edit') ? 'readonly' : 'required'; ?>>
                    <?php if ($action == 'edit'): ?><small class="form-text text-muted">Username tidak dapat diubah.</small><?php endif; ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="password">Password <?php echo ($action == 'tambah') ? '<span class="text-danger">*</span>' : ''; ?></label>
                    <input type="password" class="form-control" id="password" name="password" <?php echo ($action == 'tambah') ? 'required' : ''; ?>>
                    <?php if ($action == 'edit'): ?><small class="form-text text-muted">Kosongkan jika tidak ingin mengubah password.</small><?php endif; ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="nama_lengkap">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?php echo htmlspecialchars($user_data['nama_lengkap']); ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="email">Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="role">Role <span class="text-danger">*</span></label>
                    <select id="role" name="role" class="form-control" required>
                        <?php foreach($roles_option as $r): ?>
                            <option value="<?php echo $r; ?>" <?php echo ($user_data['role'] == $r) ? 'selected' : ''; ?>><?php echo ucfirst($r); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="nomor_telepon">Nomor Telepon</label>
                    <input type="tel" class="form-control" id="nomor_telepon" name="nomor_telepon" value="<?php echo htmlspecialchars($user_data['nomor_telepon']); ?>">
                </div>
                <div class="form-group col-md-4">
                    <label for="status_akun">Status Akun</label>
                    <select id="status_akun" name="status_akun" class="form-control">
                        <option value="1" <?php echo ($user_data['status_akun'] == 1) ? 'selected' : ''; ?>>Aktif</option>
                        <option value="0" <?php echo ($user_data['status_akun'] == 0) ? 'selected' : ''; ?>>Tidak Aktif</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo htmlspecialchars($user_data['alamat']); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Pengguna</button>
        </form>
    </div>
</div>

<?php else: // Tampilan List Pengguna ?>
<div class="card mb-3">
    <div class="card-header">
        <h6><i class="fas fa-filter"></i> Filter Pengguna</h6>
    </div>
    <div class="card-body">
        <form action="kelola_pengguna.php" method="GET" class="form-row align-items-end">
            <input type="hidden" name="action" value="list">
            <div class="form-group col-md-4">
                <label for="search_user">Cari (Nama, Username, Email)</label>
                <input type="text" name="search_user" id="search_user" class="form-control" value="<?php echo htmlspecialchars($search_user_val); ?>" placeholder="Masukkan kata kunci...">
            </div>
            <div class="form-group col-md-3">
                <label for="filter_role">Role</label>
                <select name="filter_role" id="filter_role" class="form-control">
                    <option value="">Semua Role</option>
                     <?php foreach($roles_option as $r): ?>
                        <option value="<?php echo $r; ?>" <?php echo ($filter_role_val == $r) ? 'selected' : ''; ?>><?php echo ucfirst($r); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group col-md-3">
                <button type="submit" class="btn btn-primary mr-2"><i class="fas fa-search"></i> Filter</button>
                <a href="kelola_pengguna.php?action=list" class="btn btn-secondary"><i class="fas fa-sync-alt"></i> Reset</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php if ($action == 'list'): ?>
<div class="card">
    <div class="card-header">
        <h6><i class="fas fa-users"></i> Daftar Pengguna</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover w-100">
                <thead class="thead-light">
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Nama Lengkap</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Telepon</th>
                        <th>Tanggal Registrasi</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($user_list) > 0): ?>
                        <?php foreach ($user_list as $index => $user): ?>
                        <tr>
                            <td><?php echo $index + 1; ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['nama_lengkap']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo ucfirst($user['role']); ?></td>
                            <td><?php echo htmlspecialchars($user['nomor_telepon']); ?></td>
                            <td><?php echo date('d M Y', strtotime($user['tanggal_registrasi'])); ?></td>
                            <td>
                                <span class="badge badge-<?php echo $user['status_akun'] ? 'success' : 'secondary'; ?>">
                                    <?php echo $user['status_akun'] ? 'Aktif' : 'Nonaktif'; ?>
                                </span>
                            </td>
                            <td>
                                <a href="kelola_pengguna.php?action=edit&id_pengguna=<?php echo $user['id_pengguna']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                <a href="kelola_pengguna.php?action=hapus&id_pengguna=<?php echo $user['id_pengguna']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus pengguna ini?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="text-center">Tidak ada pengguna ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php endif; // End of List Pengguna ?>
<?php include '../includes/footer.php'; 