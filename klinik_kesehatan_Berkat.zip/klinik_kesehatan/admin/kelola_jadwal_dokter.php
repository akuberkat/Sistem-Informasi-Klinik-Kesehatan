<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('admin');
$conn = connect_db();
$error_message = '';
$success_message = '';

$id_dokter_kelola = null;
$nama_dokter_kelola = '';
$jadwal_list = [];

if (!isset($_GET['id_dokter']) || !is_numeric($_GET['id_dokter'])) {
    $_SESSION['error_message'] = "ID Dokter tidak valid untuk kelola jadwal.";
    header("Location: kelola_dokter.php");
    exit;
}
$id_dokter_kelola = intval($_GET['id_dokter']);

// Get dokter's name
$stmt_nama_dok = $conn->prepare("SELECT p.nama_lengkap FROM dokter d JOIN pengguna p ON d.id_pengguna = p.id_pengguna WHERE d.id_dokter = ?");
if($stmt_nama_dok){
    $stmt_nama_dok->bind_param("i", $id_dokter_kelola);
    $stmt_nama_dok->execute();
    $result_nama = $stmt_nama_dok->get_result();
    if($result_nama->num_rows > 0){
        $nama_dokter_kelola = $result_nama->fetch_assoc()['nama_lengkap'];
    } else {
        $_SESSION['error_message'] = "Dokter tidak ditemukan.";
        header("Location: kelola_dokter.php");
        exit;
    }
    $stmt_nama_dok->close();
} else {
    $_SESSION['error_message'] = "Gagal mengambil nama dokter.";
    header("Location: kelola_dokter.php");
    exit;
}


// Handle Tambah/Edit Jadwal
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_jadwal_edit = isset($_POST['id_jadwal']) ? intval($_POST['id_jadwal']) : null;
    $hari = sanitize_input($_POST['hari']);
    $jam_mulai = sanitize_input($_POST['jam_mulai']);
    $jam_selesai = sanitize_input($_POST['jam_selesai']);
    $status_ketersediaan = sanitize_input($_POST['status_ketersediaan']);

    if (empty($hari) || empty($jam_mulai) || empty($jam_selesai) || empty($status_ketersediaan)) {
        $error_message = "Semua field jadwal wajib diisi.";
    } elseif (strtotime($jam_mulai) >= strtotime($jam_selesai)) {
        $error_message = "Jam mulai harus sebelum jam selesai.";
    } else {
        if ($id_jadwal_edit) { // Edit
            $stmt = $conn->prepare("UPDATE jadwal_dokter SET hari = ?, jam_mulai = ?, jam_selesai = ?, status_ketersediaan = ? WHERE id_jadwal = ? AND id_dokter = ?");
            if($stmt){
                $stmt->bind_param("ssssii", $hari, $jam_mulai, $jam_selesai, $status_ketersediaan, $id_jadwal_edit, $id_dokter_kelola);
                if ($stmt->execute()) {
                    $success_message = "Jadwal berhasil diperbarui.";
                } else { $error_message = "Gagal perbarui jadwal: " . $stmt->error; }
                $stmt->close();
            } else { $error_message = "Gagal siapkan update jadwal: " . $conn->error; }
        } else { // Tambah
            $stmt = $conn->prepare("INSERT INTO jadwal_dokter (id_dokter, hari, jam_mulai, jam_selesai, status_ketersediaan) VALUES (?, ?, ?, ?, ?)");
            if($stmt){
                $stmt->bind_param("issss", $id_dokter_kelola, $hari, $jam_mulai, $jam_selesai, $status_ketersediaan);
                if ($stmt->execute()) {
                    $success_message = "Jadwal baru berhasil ditambahkan.";
                } else { $error_message = "Gagal tambah jadwal: " . $stmt->error; }
                $stmt->close();
            } else { $error_message = "Gagal siapkan tambah jadwal: " . $conn->error; }
        }
    }
}

// Handle Hapus Jadwal
if (isset($_GET['action']) && $_GET['action'] == 'hapus_jadwal' && isset($_GET['id_jadwal'])) {
    $id_jadwal_hapus = intval($_GET['id_jadwal']);
    $stmt = $conn->prepare("DELETE FROM jadwal_dokter WHERE id_jadwal = ? AND id_dokter = ?");
    if($stmt){
        $stmt->bind_param("ii", $id_jadwal_hapus, $id_dokter_kelola);
        if ($stmt->execute()) {
            $success_message = "Jadwal berhasil dihapus.";
        } else { $error_message = "Gagal hapus jadwal: " . $stmt->error; }
        $stmt->close();
    } else { $error_message = "Gagal siapkan hapus jadwal: " . $conn->error; }
    // Redirect untuk clear GET params
    header("Location: kelola_jadwal_dokter.php?id_dokter=" . $id_dokter_kelola . "&success=" . urlencode($success_message) . "&error=" . urlencode($error_message));
    exit;
}

if(isset($_GET['success']) && !empty($_GET['success'])) $success_message = urldecode($_GET['success']);
if(isset($_GET['error']) && !empty($_GET['error'])) $error_message = urldecode($_GET['error']);


// Fetch existing schedules
$stmt_jadwal = $conn->prepare("SELECT * FROM jadwal_dokter WHERE id_dokter = ? ORDER BY FIELD(hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'), jam_mulai ASC");
if($stmt_jadwal){
    $stmt_jadwal->bind_param("i", $id_dokter_kelola);
    $stmt_jadwal->execute();
    $result_jadwal = $stmt_jadwal->get_result();
    while($row = $result_jadwal->fetch_assoc()){
        $jadwal_list[] = $row;
    }
    $stmt_jadwal->close();
} else {
    $error_message .= " Gagal mengambil daftar jadwal dokter. " . $conn->error;
}

$conn->close();

$hari_options = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
$status_options = ['Tersedia', 'Tidak Tersedia', 'Cuti'];
?>

<?php $page_title = "Kelola Jadwal Dokter: " . htmlspecialchars($nama_dokter_kelola); ?>
<?php include '../includes/header.php'; ?>

<div class="page-header d-flex justify-content-between align-items-center">
    <h1><?php echo $page_title; ?></h1>
    <a href="kelola_dokter.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left"></i> Kembali ke Daftar Dokter</a>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-plus-circle"></i> Tambah/Edit Jadwal</h6>
            </div>
            <div class="card-body">
                <form action="kelola_jadwal_dokter.php?id_dokter=<?php echo $id_dokter_kelola; ?>" method="POST">
                    <input type="hidden" name="id_jadwal" id="id_jadwal_edit" value="">
                    <div class="form-group">
                        <label for="hari">Hari <span class="text-danger">*</span></label>
                        <select name="hari" id="hari_edit" class="form-control" required>
                            <?php foreach($hari_options as $h): ?>
                                <option value="<?php echo $h; ?>"><?php echo $h; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="jam_mulai">Jam Mulai <span class="text-danger">*</span></label>
                        <input type="time" name="jam_mulai" id="jam_mulai_edit" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="jam_selesai">Jam Selesai <span class="text-danger">*</span></label>
                        <input type="time" name="jam_selesai" id="jam_selesai_edit" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="status_ketersediaan">Status Ketersediaan <span class="text-danger">*</span></label>
                        <select name="status_ketersediaan" id="status_ketersediaan_edit" class="form-control" required>
                             <?php foreach($status_options as $s): ?>
                                <option value="<?php echo $s; ?>"><?php echo $s; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Jadwal</button>
                    <button type="button" class="btn btn-secondary" onclick="resetFormJadwal()">Batal Edit</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-calendar-alt"></i> Daftar Jadwal Tersimpan</h6>
            </div>
            <div class="card-body">
                <?php if (!empty($jadwal_list)): ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th>Hari</th>
                                <th>Jam Mulai</th>
                                <th>Jam Selesai</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($jadwal_list as $jadwal): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($jadwal['hari']); ?></td>
                                <td><?php echo htmlspecialchars(date("H:i", strtotime($jadwal['jam_mulai']))); ?></td>
                                <td><?php echo htmlspecialchars(date("H:i", strtotime($jadwal['jam_selesai']))); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo ($jadwal['status_ketersediaan'] == 'Tersedia') ? 'success' : (($jadwal['status_ketersediaan'] == 'Cuti') ? 'warning' : 'danger'); ?>">
                                        <?php echo htmlspecialchars($jadwal['status_ketersediaan']); ?>
                                    </span>
                                </td>
                                <td class="action-buttons">
                                    <button class="btn btn-info btn-sm" onclick="editJadwal(<?php echo htmlspecialchars(json_encode($jadwal)); ?>)" title="Edit"><i class="fas fa-edit"></i></button>
                                    <a href="kelola_jadwal_dokter.php?id_dokter=<?php echo $id_dokter_kelola; ?>&action=hapus_jadwal&id_jadwal=<?php echo $jadwal['id_jadwal']; ?>"
                                       class="btn btn-danger btn-sm" title="Hapus"
                                       onclick="return confirm('Anda yakin ingin menghapus jadwal ini?')"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                    <p class="text-muted">Belum ada jadwal yang diatur untuk dokter ini.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<script>
function editJadwal(jadwal) {
    document.getElementById('id_jadwal_edit').value = jadwal.id_jadwal;
    document.getElementById('hari_edit').value = jadwal.hari;
    document.getElementById('jam_mulai_edit').value = jadwal.jam_mulai;
    document.getElementById('jam_selesai_edit').value = jadwal.jam_selesai;
    document.getElementById('status_ketersediaan_edit').value = jadwal.status_ketersediaan;
    window.scrollTo(0, 0); // Scroll to top to see the form
}
function resetFormJadwal() {
    document.getElementById('id_jadwal_edit').value = '';
    document.querySelector('form action="kelola_jadwal_dokter.php?id_dokter=<?php echo $id_dokter_kelola; ?>"').reset(); // Reset form
}
</script>
<?php include '../includes/footer.php'; ?>