<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('admin');
$conn = connect_db();
$error_message = '';
$success_message = '';

// Handler Hapus Dokter (Hard Delete)
if (isset($_GET['action']) && $_GET['action'] == 'hapus' && isset($_GET['id_pengguna'])) {
    $id_pengguna_hapus = intval($_GET['id_pengguna']);
    try {
        $conn->begin_transaction();
        $stmt1 = $conn->prepare("DELETE FROM dokter WHERE id_pengguna = ?");
        $stmt1->bind_param("i", $id_pengguna_hapus);
        $stmt1->execute();
        $stmt2 = $conn->prepare("DELETE FROM pengguna WHERE id_pengguna = ?");
        $stmt2->bind_param("i", $id_pengguna_hapus);
        $stmt2->execute();
        $conn->commit();
        $_SESSION['success_message'] = "Dokter berhasil dihapus.";
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_message'] = "Gagal menghapus dokter: " . $e->getMessage();
    }
    header("Location: kelola_dokter.php");
    exit;
}

$dokter_list = [];
$sql = "SELECT d.id_dokter, d.id_pengguna, d.spesialisasi, d.nomor_sip, d.foto_profil,
               u.nama_lengkap, u.username, u.email, u.nomor_telepon, u.status_akun
        FROM dokter d
        JOIN pengguna u ON d.id_pengguna = u.id_pengguna
        ORDER BY u.nama_lengkap ASC";
$result = $conn->query($sql);
if ($result) {
    while($row = $result->fetch_assoc()){
        $dokter_list[] = $row;
    }
} else {
    $error_message = "Gagal mengambil data dokter: " . $conn->error;
}

if(isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
if(isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

$conn->close();
?>

<?php $page_title = "Kelola Dokter"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header d-flex justify-content-between align-items-center">
    <h1>Kelola Data Dokter</h1>
    <a href="form_dokter.php?action=tambah" class="btn btn-success"><i class="fas fa-user-md"></i> Tambah Dokter Baru</a>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h6><i class="fas fa-list"></i> Daftar Dokter</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-sm">
                <thead class="thead-light">
                    <tr>
                        <th>No.</th>
                        <th>Foto</th>
                        <th>Nama Lengkap (Username)</th>
                        <th>Email</th>
                        <th>No. Telepon</th>
                        <th>Spesialisasi</th>
                        <th>No. SIP</th>
                        <th>Status Akun</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($dokter_list)): ?>
                        <?php foreach ($dokter_list as $index => $dokter): ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td>
                                    <img src="../assets/images/berkat.png/<?php echo !empty($dokter['foto_profil']) ? htmlspecialchars($dokter['foto_profil']) : 'default_dokter.png'; ?>"
                                         alt="Foto <?php echo htmlspecialchars($dokter['nama_lengkap']); ?>"
                                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 50%;">
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($dokter['nama_lengkap']); ?>
                                    <br><small class="text-muted">(<?php echo htmlspecialchars($dokter['username']); ?>)</small>
                                </td>
                                <td><?php echo htmlspecialchars($dokter['email']); ?></td>
                                <td><?php echo htmlspecialchars($dokter['nomor_telepon'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($dokter['spesialisasi']); ?></td>
                                <td><?php echo htmlspecialchars($dokter['nomor_sip'] ?: '-'); ?></td>
                                <td>
                                    <?php
                                        $status_akun_text = isset($dokter['status_akun']) && $dokter['status_akun'] == 1 ? 'Aktif' : 'Tidak Aktif';
                                        $status_akun_class = isset($dokter['status_akun']) && $dokter['status_akun'] == 1 ? 'badge badge-success' : 'badge badge-danger';
                                        if (!isset($dokter['status_akun'])) {
                                            $status_akun_text = 'Aktif';
                                            $status_akun_class = 'badge badge-success';
                                        }
                                    ?>
                                    <span class="<?php echo $status_akun_class; ?>"><?php echo $status_akun_text; ?></span>
                                </td>
                                <td>
                                    <a href="form_dokter.php?action=edit&id_pengguna=<?php echo $dokter['id_pengguna']; ?>">Edit</a> |
                                    <a href="kelola_dokter.php?action=hapus&id_pengguna=<?php echo $dokter['id_pengguna']; ?>"
                                       onclick="return confirm('Yakin ingin menghapus dokter ini?');">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="text-center">Belum ada data dokter.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>
