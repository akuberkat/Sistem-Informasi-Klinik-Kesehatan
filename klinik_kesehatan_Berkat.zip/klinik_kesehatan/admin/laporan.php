<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('admin');
$conn = connect_db();
$error_message = '';

// Default rentang tanggal: bulan ini
$tanggal_mulai_default = date('Y-m-01');
$tanggal_selesai_default = date('Y-m-t');

$filter_tanggal_mulai = isset($_GET['tanggal_mulai']) && !empty($_GET['tanggal_mulai']) ? sanitize_input($_GET['tanggal_mulai']) : $tanggal_mulai_default;
$filter_tanggal_selesai = isset($_GET['tanggal_selesai']) && !empty($_GET['tanggal_selesai']) ? sanitize_input($_GET['tanggal_selesai']) : $tanggal_selesai_default;

// Laporan Pendaftaran
$laporan_pendaftaran = [
    'Menunggu Konfirmasi' => 0,
    'Dikonfirmasi' => 0,
    'Selesai' => 0,
    'Dibatalkan' => 0,
    'Total' => 0
];
$stmt_lap_daftar = $conn->prepare("SELECT status_pendaftaran, COUNT(id_pendaftaran) as jumlah FROM pendaftaran_konsultasi WHERE DATE(tanggal_dibuat) BETWEEN ? AND ? GROUP BY status_pendaftaran");
if($stmt_lap_daftar){
    $stmt_lap_daftar->bind_param("ss", $filter_tanggal_mulai, $filter_tanggal_selesai);
    $stmt_lap_daftar->execute();
    $result_lap_daftar = $stmt_lap_daftar->get_result();
    while($row = $result_lap_daftar->fetch_assoc()){
        if(array_key_exists($row['status_pendaftaran'], $laporan_pendaftaran)){
            $laporan_pendaftaran[$row['status_pendaftaran']] = $row['jumlah'];
        }
        $laporan_pendaftaran['Total'] += $row['jumlah'];
    }
    $stmt_lap_daftar->close();
} else { $error_message .= " Gagal mengambil laporan pendaftaran. "; }


// Laporan Pendapatan (Sederhana dari tabel pembayaran)
$total_pendapatan = 0;
$detail_pendapatan_per_dokter = [];

$sql_pendapatan = "SELECT SUM(pb.total_biaya) AS total
                   FROM pembayaran pb
                   JOIN pendaftaran_konsultasi pk ON pb.id_pendaftaran = pk.id_pendaftaran
                   WHERE pb.status_pembayaran = 'Lunas' AND DATE(pb.tanggal_pembayaran) BETWEEN ? AND ?";
$stmt_lap_pendapatan = $conn->prepare($sql_pendapatan);
if($stmt_lap_pendapatan){
    $stmt_lap_pendapatan->bind_param("ss", $filter_tanggal_mulai, $filter_tanggal_selesai);
    $stmt_lap_pendapatan->execute();
    $result_total = $stmt_lap_pendapatan->get_result()->fetch_assoc()['total'];
    $total_pendapatan = $result_total ?: 0;
    $stmt_lap_pendapatan->close();
} else { $error_message .= " Gagal mengambil laporan total pendapatan. "; }


// Detail Pendapatan per Dokter
$sql_detail_dokter = "SELECT dok_pengguna.nama_lengkap as nama_dokter, SUM(pb.total_biaya) as total_dokter, COUNT(pb.id_pembayaran) as jumlah_transaksi
                      FROM pembayaran pb
                      JOIN pendaftaran_konsultasi pk ON pb.id_pendaftaran = pk.id_pendaftaran
                      JOIN dokter dok ON pk.id_dokter = dok.id_dokter
                      JOIN pengguna dok_pengguna ON dok.id_pengguna = dok_pengguna.id_pengguna
                      WHERE pb.status_pembayaran = 'Lunas' AND DATE(pb.tanggal_pembayaran) BETWEEN ? AND ?
                      GROUP BY pk.id_dokter, dok_pengguna.nama_lengkap
                      ORDER BY total_dokter DESC";
$stmt_detail_dokter = $conn->prepare($sql_detail_dokter);
if($stmt_detail_dokter){
    $stmt_detail_dokter->bind_param("ss", $filter_tanggal_mulai, $filter_tanggal_selesai);
    $stmt_detail_dokter->execute();
    $result_detail = $stmt_detail_dokter->get_result();
    while($row = $result_detail->fetch_assoc()){
        $detail_pendapatan_per_dokter[] = $row;
    }
    $stmt_detail_dokter->close();
} else { $error_message .= " Gagal mengambil detail pendapatan per dokter. "; }


$conn->close();
?>
<?php $page_title = "Laporan Klinik"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1><?php echo $page_title; ?></h1>
</div>

<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<div class="card mb-4">
    <div class="card-header">
        <h6><i class="fas fa-filter"></i> Filter Laporan Berdasarkan Tanggal</h6>
    </div>
    <div class="card-body">
        <form action="laporan.php" method="GET" class="form-row align-items-end">
            <div class="form-group col-md-4">
                <label for="tanggal_mulai">Tanggal Mulai</label>
                <input type="date" name="tanggal_mulai" id="tanggal_mulai" class="form-control" value="<?php echo htmlspecialchars($filter_tanggal_mulai); ?>" required>
            </div>
            <div class="form-group col-md-4">
                <label for="tanggal_selesai">Tanggal Selesai</label>
                <input type="date" name="tanggal_selesai" id="tanggal_selesai" class="form-control" value="<?php echo htmlspecialchars($filter_tanggal_selesai); ?>" required>
            </div>
            <div class="form-group col-md-auto">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Tampilkan Laporan</button>
            </div>
        </form>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-calendar-alt"></i> Laporan Pendaftaran (<?php echo format_tanggal_indonesia($filter_tanggal_mulai) . " - " . format_tanggal_indonesia($filter_tanggal_selesai); ?>)</h6>
            </div>
            <div class="card-body">
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">Menunggu Konfirmasi <span class="badge badge-warning badge-pill"><?php echo $laporan_pendaftaran['Menunggu Konfirmasi']; ?></span></li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">Dikonfirmasi <span class="badge badge-info badge-pill"><?php echo $laporan_pendaftaran['Dikonfirmasi']; ?></span></li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">Selesai <span class="badge badge-success badge-pill"><?php echo $laporan_pendaftaran['Selesai']; ?></span></li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">Dibatalkan <span class="badge badge-danger badge-pill"><?php echo $laporan_pendaftaran['Dibatalkan']; ?></span></li>
                    <li class="list-group-item d-flex justify-content-between align-items-center font-weight-bold">Total Pendaftaran <span class="badge badge-primary badge-pill"><?php echo $laporan_pendaftaran['Total']; ?></span></li>
                </ul>
                </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-success"><i class="fas fa-money-bill-wave"></i> Laporan Pendapatan (<?php echo format_tanggal_indonesia($filter_tanggal_mulai) . " - " . format_tanggal_indonesia($filter_tanggal_selesai); ?>)</h6>
            </div>
            <div class="card-body">
                <h4 class="text-center font-weight-bold mb-3">Total Pendapatan: Rp <?php echo number_format($total_pendapatan, 0, ',', '.'); ?></h4>
                <?php if(!empty($detail_pendapatan_per_dokter)): ?>
                    <h6 class="mt-4">Detail per Dokter:</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead class="thead-light">
                                <tr>
                                    <th>Nama Dokter</th>
                                    <th>Jumlah Transaksi Lunas</th>
                                    <th>Total Pendapatan (Rp)</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach($detail_pendapatan_per_dokter as $detail_dok): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($detail_dok['nama_dokter']); ?></td>
                                    <td class="text-center"><?php echo htmlspecialchars($detail_dok['jumlah_transaksi']); ?></td>
                                    <td class="text-right"><?php echo htmlspecialchars(number_format($detail_dok['total_dokter'], 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center">Tidak ada data pendapatan untuk periode ini.</p>
                <?php endif; ?>
                 </div>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>