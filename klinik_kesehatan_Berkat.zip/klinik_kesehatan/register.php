<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (isset($_SESSION['id_pengguna'])) {
    redirect_to_dashboard($_SESSION['role']);
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $raw_password = $_POST['password']; // Password mentah
    $nama_lengkap = $_POST['nama_lengkap'];
    $email = $_POST['email'];
    $nomor_telepon = $_POST['nomor_telepon'];
    $alamat = $_POST['alamat'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $role = 'pasien';

    // Validasi sederhana (tambahkan validasi lebih lengkap)
    if (empty($username) || empty($raw_password) || empty($nama_lengkap) || empty($email)) {
        $error_message = "Semua field yang bertanda bintang (*) wajib diisi.";
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Format email tidak valid.";
    } else {
        $conn = connect_db();

        // Cek apakah username atau email sudah ada
        $stmt_check = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE username = ? OR email = ?");
        if (!$stmt_check) {
            $error_message = "Kesalahan persiapan statement cek: " . $conn->error;
        } else {
            $stmt_check->bind_param("ss", $username, $email);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0) {
                $error_message = "Username atau Email sudah terdaftar.";
            } else {
                // Hash password
                $hashed_password = password_hash($raw_password, PASSWORD_DEFAULT);

                // Insert ke tabel pengguna
                $stmt_pengguna = $conn->prepare("INSERT INTO pengguna (username, password, nama_lengkap, role, email, nomor_telepon, alamat) VALUES (?, ?, ?, ?, ?, ?, ?)");
                if (!$stmt_pengguna) {
                    $error_message = "Kesalahan persiapan statement pengguna: " . $conn->error;
                } else {
                    $stmt_pengguna->bind_param("sssssss", $username, $hashed_password, $nama_lengkap, $role, $email, $nomor_telepon, $alamat);

                    if ($stmt_pengguna->execute()) {
                        $id_pengguna_baru = $stmt_pengguna->insert_id;
                        // Buat nomor rekam medis unik (contoh sederhana)
                        $nomor_rekam_medis = "RM" . str_pad($id_pengguna_baru, 5, "0", STR_PAD_LEFT) . date("Y");

                        // Insert ke tabel pasien
                        $stmt_pasien = $conn->prepare("INSERT INTO pasien (id_pengguna, nomor_rekam_medis, tanggal_lahir, jenis_kelamin) VALUES (?, ?, ?, ?)");
                        if (!$stmt_pasien) {
                            $error_message = "Kesalahan persiapan statement pasien: " . $conn->error;
                        } else {
                            $stmt_pasien->bind_param("isss", $id_pengguna_baru, $nomor_rekam_medis, $tanggal_lahir, $jenis_kelamin);
                            if ($stmt_pasien->execute()) {
                                $success_message = "Registrasi berhasil! Silakan login.";
                                // Kosongkan form atau redirect ke login
                            } else {
                                $error_message = "Gagal menyimpan data pasien: " . $stmt_pasien->error;
                                // Mungkin perlu menghapus data pengguna yang sudah terinput jika data pasien gagal
                                $conn->query("DELETE FROM pengguna WHERE id_pengguna = $id_pengguna_baru");
                            }
                            $stmt_pasien->close();
                        }
                    } else {
                        $error_message = "Gagal menyimpan data pengguna: " . $stmt_pengguna->error;
                    }
                    $stmt_pengguna->close();
                }
            }
            $stmt_check->close();
        }
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Pasien - Sistem Informasi Klinik</title>
    <link rel="stylesheet" href="assets/css/style.css">
     <style>
        body { font-family: Arial, sans-serif; background-color: #f4f7f6; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; padding: 20px 0; }
        .register-container { background-color: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 450px; text-align: center; }
        .register-container img.logo { max-width: 120px; margin-bottom: 15px; }
        .register-container h2 { margin-bottom: 20px; color: #333; }
        .register-container .form-group { margin-bottom: 15px; text-align: left; }
        .register-container .form-group label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
        .register-container .form-group input, .register-container .form-group select, .register-container .form-group textarea { width: calc(100% - 22px); padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .register-container .form-group textarea { resize: vertical; min-height: 60px; }
        .register-container button { background-color: #28a745; color: white; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer; width: 100%; font-size: 16px; }
        .register-container button:hover { background-color: #218838; }
        .register-container .login-link { margin-top: 15px; font-size: 0.9em; }
        .register-container .login-link a { color: #007bff; text-decoration: none; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; font-size: 0.9em; }
        .success-message { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error-message { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>
    <div class="register-container">
        <img src="assets/images/logoku.png" alt="Logo Klinik" class="logo">
        <h2>Registrasi Pasien Baru</h2>
        <?php if (!empty($success_message)): ?>
            <p class="message success-message"><?php echo $success_message; ?></p>
        <?php endif; ?>
        <?php if (!empty($error_message)): ?>
            <p class="message error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <form action="register.php" method="POST">
            <div class="form-group">
                <label for="nama_lengkap">Nama Lengkap <span style="color:red;">*</span></label>
                <input type="text" id="nama_lengkap" name="nama_lengkap" required>
            </div>
            <div class="form-group">
                <label for="username">Username <span style="color:red;">*</span></label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password <span style="color:red;">*</span></label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="email">Email <span style="color:red;">*</span></label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="nomor_telepon">Nomor Telepon</label>
                <input type="tel" id="nomor_telepon" name="nomor_telepon">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <textarea id="alamat" name="alamat"></textarea>
            </div>
            <div class="form-group">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <input type="date" id="tanggal_lahir" name="tanggal_lahir">
            </div>
            <div class="form-group">
                <label for="jenis_kelamin">Jenis Kelamin</label>
                <select id="jenis_kelamin" name="jenis_kelamin">
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>
            <button type="submit">Daftar</button>
        </form>
        <div class="login-link">
            Sudah punya akun? <a href="login.php">Login di sini</a>
        </div>
    </div>
</body>
</html>