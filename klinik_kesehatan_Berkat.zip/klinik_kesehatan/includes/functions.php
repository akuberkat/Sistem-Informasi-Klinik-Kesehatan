<?php
// File: includes/functions.php

/**
 * Membersihkan input dari karakter yang tidak diinginkan untuk mencegah XSS dasar.
 * @param string $data Data input.
 * @return string Data yang sudah dibersihkan.
 */
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Mengarahkan pengguna ke dashboard yang sesuai berdasarkan role mereka.
 * @param string $role Role pengguna ('admin', 'dokter', 'resepsionis', 'pasien').
 * @param string $base_path Path dasar relatif dari file yang memanggil. Default '../'.
 */
function redirect_to_dashboard($role, $base_path = '') {
    // Jika base_path tidak di-set secara eksplisit, kita coba tentukan
    // Namun, lebih baik base_path ditentukan dari file pemanggil jika struktur kompleks
    // Untuk struktur kita, dari index.php (root), pathnya langsung ke folder aktor.
    // Dari dalam folder aktor, pathnya akan '../<folder_aktor>/dashboard.php'

    $target_path = '';
    switch (strtolower($role)) {
        case 'admin':
            $target_path = $base_path . 'admin/dashboard.php';
            break;
        case 'dokter':
            $target_path = $base_path . 'dokter/dashboard.php';
            break;
        case 'resepsionis':
            $target_path = $base_path . 'resepsionis/dashboard.php';
            break;
        case 'pasien':
            $target_path = $base_path . 'pasien/dashboard.php';
            break;
        default:
            $target_path = $base_path . 'index.php'; // Halaman login default jika role tidak dikenal
            break;
    }
    header("Location: " . $target_path);
    exit();
}


/**
 * Memformat tanggal dari format YYYY-MM-DD ke format Indonesia (DD NamaBulan YYYY).
 * @param string|null $tanggal Tanggal dalam format YYYY-MM-DD atau datetime.
 * @param bool $with_time Jika true, sertakan waktu (HH:MM).
 * @return string Tanggal yang sudah diformat atau '-' jika tanggal tidak valid.
 */
function format_tanggal_indonesia($tanggal, $with_time = false) {
    if (empty($tanggal) || $tanggal == '0000-00-00' || $tanggal == '0000-00-00 00:00:00') {
        return '-';
    }

    try {
        $date_obj = new DateTime($tanggal);
    } catch (Exception $e) {
        return '-'; // Tanggal tidak valid
    }

    $bulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];

    $hari_angka = $date_obj->format('d');
    $bulan_angka = (int)$date_obj->format('m');
    $tahun_angka = $date_obj->format('Y');

    $format_indonesia = $hari_angka . ' ' . $bulan[$bulan_angka] . ' ' . $tahun_angka;

    if ($with_time) {
        $format_indonesia .= ', ' . $date_obj->format('H:i') . ' WIB';
    }

    return $format_indonesia;
}

/**
 * Menghasilkan Nomor Rekam Medis unik (contoh sederhana).
 * Format: RM<IDPenggunaDenganPadding><TahunBulan>
 * @param int $id_pengguna ID pengguna pasien.
 * @return string Nomor Rekam Medis.
 */
function generate_nomor_rekam_medis($id_pengguna) {
    return "RM" . str_pad($id_pengguna, 5, "0", STR_PAD_LEFT) . date("ym");
}

/**
 * Menghasilkan username unik sederhana jika diperlukan saat registrasi oleh admin/resepsionis.
 * @param string $nama_lengkap Nama lengkap pengguna.
 * @param mysqli $conn Objek koneksi database untuk memeriksa keunikan.
 * @return string Username yang unik.
 */
function generate_unique_username($nama_lengkap, $conn) {
    $base_username = strtolower(str_replace(' ', '.', preg_replace('/[^a-zA-Z0-9\s]/', '', $nama_lengkap)));
    if (empty($base_username)) {
        $base_username = 'user';
    }

    $username = $base_username;
    $counter = 1;
    while (true) {
        $stmt_check = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE username = ?");
        $stmt_check->bind_param("s", $username);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows == 0) {
            $stmt_check->close();
            return $username;
        }
        $stmt_check->close();
        $username = $base_username . $counter;
        $counter++;
    }
}
/**
 * Melakukan logout user: menghapus session dan redirect ke halaman login.
 */
function logout_user() {
    session_start();
    session_unset();
    session_destroy();
    header("Location: index.php"); // Ubah jika login.php ada di folder berbeda
    exit();
}


?>