<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['role']) || !isset($_SESSION['nama_lengkap'])) {
    header('Location: ../login.php');
    exit();
}

$role = $_SESSION['role'];
$nama = $_SESSION['nama_lengkap'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klinik Sehat Bahagia</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Tambahan styling langsung jika perlu */
        body { font-family: 'Segoe UI', sans-serif; margin: 0; background: #f8f9fa; }
        .navbar, .sidebar, .footer, .main-content { box-sizing: border-box; }
        /* ... styling dari sebelumnya boleh disatukan di style.css ... */
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo">
            <a href="#">
                <img src="../assets/images/logoku.png" alt="Logo"> Klinik Sehat Bahagia
            </a>
        </div>
        <div class="user-info">
            Selamat datang, <strong><?= htmlspecialchars($nama) ?></strong> (<?= ucfirst(htmlspecialchars($role)) ?>)
            <a href="../logout.php" class="nav-links logout">Logout</a>
        </div>
    </nav>

    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="profile-info">
<?php
$gambarProfil = 'default.png';
if ($role == 'pasien') {
    $gambarProfil = 'sahara.jpeg';
} elseif ($role == 'dokter') {
    $gambarProfil = 'berkat.png';
} elseif ($role == 'resepsionis') {
    $gambarProfil = 'resep1.jpg';
} elseif ($role == 'admin') {
    $gambarProfil = 'admin.jfif';
}
?>
<img src="../assets/images/<?= htmlspecialchars($gambarProfil) ?>" alt="Foto Profil">
            <h4><?= htmlspecialchars($nama) ?></h4>
            <p><?= ucfirst(htmlspecialchars($role)) ?></p>
        </div>
        <ul>
            <?php
            $base = "../";
            switch ($role) {
                case 'pasien':
                    echo '<li><a href="'.$base.'pasien/dashboard.php">Dashboard</a></li>';
                    echo '<li><a href="'.$base.'pasien/pendaftaran_konsultasi.php">Pendaftaran Konsultasi</a></li>';
                    echo '<li><a href="'.$base.'pasien/riwayat_konsultasi.php">Riwayat Konsultasi</a></li>';
                    echo '<li><a href="'.$base.'pasien/profil.php">Profil Saya</a></li>';
                    break;
                case 'dokter':
                    echo '<li><a href="'.$base.'dokter/dashboard.php">Dashboard</a></li>';
                    echo '<li><a href="'.$base.'dokter/jadwal_saya.php">Jadwal Saya</a></li>';
                    echo '<li><a href="'.$base.'dokter/cari_rekam_medis.php">Rekam Medis Pasien</a></li>';
                    echo '<li><a href="'.$base.'dokter/profil.php">Profil Saya</a></li>';
                    break;
                case 'resepsionis':
                    echo '<li><a href="'.$base.'resepsionis/dashboard.php">Dashboard</a></li>';
                    echo '<li><a href="'.$base.'resepsionis/kelola_pendaftaran.php">Kelola Pendaftaran</a></li>';
                    echo '<li><a href="'.$base.'resepsionis/data_pasien.php">Data Pasien</a></li>';
                    echo '<li><a href="'.$base.'resepsionis/kelola_pembayaran.php">Kelola Pembayaran</a></li>';
                    break;
                case 'admin':
                    echo '<li><a href="'.$base.'admin/dashboard.php">Dashboard</a></li>';
                    echo '<li><a href="'.$base.'admin/kelola_pengguna.php">Kelola Pengguna</a></li>';
                    echo '<li><a href="'.$base.'admin/kelola_dokter.php">Kelola Dokter & Jadwal</a></li>';
                    break;
            }
            ?>
        </ul>
    </aside>

    <!-- Konten Utama -->
    <main class="main-content">
