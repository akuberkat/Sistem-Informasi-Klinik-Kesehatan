<?php
// File: includes/auth.php

if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Pastikan session selalu dimulai jika file ini di-include
}

/**
 * Memeriksa apakah pengguna sudah login.
 * @return bool True jika sudah login, false jika belum.
 */
function is_logged_in() {
    return isset($_SESSION['id_pengguna']);
}

/**
 * Memeriksa apakah pengguna sudah login dan (opsional) memiliki role tertentu.
 * Jika tidak memenuhi, akan redirect ke halaman login atau halaman yang ditentukan.
 * @param string|array|null $required_role Role yang dibutuhkan. Bisa string tunggal, array role, atau null (hanya cek login).
 * @param string $redirect_url URL untuk redirect jika otorisasi gagal (default ke index.php di root).
 */
function check_login($required_role = null, $redirect_url = null) {
    // Tentukan path root relatif dari lokasi file auth.php
    // Diasumsikan auth.php ada di 'includes/', jadi '../' adalah root.
    $base_redirect_path = '../index.php';
    if ($redirect_url === null) {
        $redirect_url = $base_redirect_path;
    }

    if (!is_logged_in()) {
        $_SESSION['error_message'] = "Anda harus login untuk mengakses halaman ini.";
        header("Location: " . $redirect_url);
        exit();
    }

    if ($required_role !== null) {
        $user_role = isset($_SESSION['role']) ? strtolower($_SESSION['role']) : '';
        $has_required_role = false;

        if (is_array($required_role)) {
            foreach ($required_role as $role) {
                if (strtolower($role) == $user_role) {
                    $has_required_role = true;
                    break;
                }
            }
        } else {
            if (strtolower($required_role) == $user_role) {
                $has_required_role = true;
            }
        }

        if (!$has_required_role) {
            $_SESSION['error_message'] = "Anda tidak memiliki izin untuk mengakses halaman ini.";
            // Redirect ke dashboard default pengguna jika mereka login tapi role salah,
            // atau ke halaman login jika ingin lebih strict.
            // Untuk contoh ini, kita redirect ke dashboard default mereka jika login.
            if(isset($_SESSION['role'])){
                 // Panggil redirect_to_dashboard dengan path yang benar relatif dari folder includes
                 // Karena auth.php ada di 'includes', maka base path untuk redirect_to_dashboard adalah '../'
                 // Namun, redirect_to_dashboard sendiri sudah mengasumsikan path dari root jika base_path kosong.
                 // Mari kita panggil dengan base_path yang tepat.
                 // Jika halaman pemanggil ada di 'pasien/', maka base_path untuk redirect_to_dashboard dari auth.php adalah '../'
                 // Jika index.php (root) memanggil auth.php (seharusnya tidak), maka base_path ''
                 // Karena auth.php akan diinclude dari file di dalam folder aktor (misal pasien/dashboard.php)
                 // maka path '../' untuk redirect_to_dashboard akan benar mengarah ke root.

                // Jika pengguna memiliki role tapi tidak sesuai, redirect ke dashboard mereka sendiri
                // atau tampilkan pesan error saja di halaman saat ini (lebih aman).
                // Untuk saat ini, kita akan redirect ke halaman unauthorized.
                // Atau, kita bisa menggunakan redirect_to_dashboard default mereka:
                // redirect_to_dashboard($_SESSION['role'], '../'); // Perlu penyesuaian path

                // Cara lebih aman: tampilkan pesan error dan exit, atau redirect ke halaman akses ditolak
                // header("Location: " . $base_redirect_path . "?error=unauthorized"); // atau halaman akses_ditolak.php
                // Untuk sekarang, kita akan redirect ke halaman utama jika role tidak cocok
                // Jika ada halaman "unauthorized.php" di root:
                // header("Location: ../unauthorized.php");
                // Jika tidak, redirect ke dashboard mereka sendiri sebagai fallback aman
                if (function_exists('redirect_to_dashboard')) { // Pastikan fungsi ada
                    // Path dari includes/auth.php ke folder aktor
                    // Misalnya, jika kita di admin/dashboard.php, dan memanggil auth.php,
                    // redirect_to_dashboard akan dipanggil dengan base_path = '../'
                    // Jika kita berada di admin/dashboard.php, $_SESSION['role'] = 'admin'
                    // redirect_to_dashboard('admin', '../') -> ../admin/dashboard.php (ini adalah halaman saat ini)
                    // Jadi, jika role tidak cocok, kita harus redirect ke halaman login atau halaman "akses ditolak"
                    // Untuk penyederhanaan, kita redirect ke halaman login saja.
                    header("Location: " . $redirect_url . "?error=unauthorized_role");
                    exit();
                } else {
                     // Fallback jika redirect_to_dashboard tidak tersedia di scope ini
                    header("Location: " . $redirect_url . "?error=unauthorized_role_fallback");
                    exit();
                }
            } else {
                // Jika session role tidak ada (seharusnya tidak terjadi jika sudah login)
                 header("Location: " . $redirect_url . "?error=session_role_missing");
                exit();
            }
        }
    }
}


?>