<?php
// Script untuk membuat akun baru dengan password yang di-hash
// Jalankan sekali saja, lalu hapus file ini untuk keamanan

// Koneksi database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_klinik";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "<h2>Membuat Akun Baru untuk Sistem Klinik</h2>";

// Data akun yang akan dibuat
$accounts = [
    [
        'username' => 'admin_new',
        'password' => 'admin123',
        'nama_lengkap' => 'Administrator Sistem',
        'role' => 'admin',
        'email' => 'admin.new@klinik.com',
        'nomor_telepon' => '08123456789',
        'alamat' => 'Jl. Admin No. 1, Kota Admin'
    ],
    [
        'username' => 'dr.andi',
        'password' => 'dokter123',
        'nama_lengkap' => 'Dr. Andi Pratama',
        'role' => 'dokter',
        'email' => 'andi.pratama@klinik.com',
        'nomor_telepon' => '08123456780',
        'alamat' => 'Jl. Dokter Andi No. 15, Kota Sehat'
    ],
    [
        'username' => 'dr.maya',
        'password' => 'dokter123',
        'nama_lengkap' => 'Dr. Maya Sari',
        'role' => 'dokter',
        'email' => 'maya.sari@klinik.com',
        'nomor_telepon' => '08123456781',
        'alamat' => 'Jl. Dokter Maya No. 20, Kota Sehat'
    ],
    [
        'username' => 'resepsionis1',
        'password' => 'resep123',
        'nama_lengkap' => 'Siti Nurhaliza',
        'role' => 'resepsionis',
        'email' => 'siti.nurhaliza@klinik.com',
        'nomor_telepon' => '08123456782',
        'alamat' => 'Jl. Resepsionis No. 5, Kota Sehat'
    ],
    [
        'username' => 'resepsionis2',
        'password' => 'resep123',
        'nama_lengkap' => 'Dewi Anggraini',
        'role' => 'resepsionis',
        'email' => 'dewi.anggraini@klinik.com',
        'nomor_telepon' => '08123456783',
        'alamat' => 'Jl. Resepsionis No. 10, Kota Sehat'
    ]
];

echo "<table border='1' cellpadding='10' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background-color: #f2f2f2;'>
        <th>Username</th>
        <th>Password</th>
        <th>Nama Lengkap</th>
        <th>Role</th>
        <th>Status</th>
      </tr>";

foreach ($accounts as $account) {
    // Hash password menggunakan password_hash()
    $hashed_password = password_hash($account['password'], PASSWORD_DEFAULT);
    
    // Cek apakah username atau email sudah ada
    $check_stmt = $conn->prepare("SELECT username, email FROM pengguna WHERE username = ? OR email = ?");
    $check_stmt->bind_param("ss", $account['username'], $account['email']);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $existing = $check_result->fetch_assoc();
        echo "<tr>";
        echo "<td>" . $account['username'] . "</td>";
        echo "<td>" . $account['password'] . "</td>";
        echo "<td>" . $account['nama_lengkap'] . "</td>";
        echo "<td>" . $account['role'] . "</td>";
        if ($existing['username'] == $account['username']) {
            echo "<td style='color: orange;'>Username sudah ada - dilewati</td>";
        } else {
            echo "<td style='color: orange;'>Email sudah ada - dilewati</td>";
        }
        echo "</tr>";
        $check_stmt->close();
        continue;
    }
    $check_stmt->close();
    
    // Insert akun baru
    $stmt = $conn->prepare("INSERT INTO pengguna (username, password, nama_lengkap, role, email, nomor_telepon, alamat, status_akun, tanggal_registrasi, foto_profil) VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW(), 'default_avatar.png')");
    
    if ($stmt) {
        $stmt->bind_param("sssssss", 
            $account['username'], 
            $hashed_password, 
            $account['nama_lengkap'], 
            $account['role'], 
            $account['email'], 
            $account['nomor_telepon'], 
            $account['alamat']
        );
        
        if ($stmt->execute()) {
            echo "<tr>";
            echo "<td>" . $account['username'] . "</td>";
            echo "<td>" . $account['password'] . "</td>";
            echo "<td>" . $account['nama_lengkap'] . "</td>";
            echo "<td>" . $account['role'] . "</td>";
            echo "<td style='color: green;'>✓ Berhasil dibuat</td>";
            echo "</tr>";
        } else {
            echo "<tr>";
            echo "<td>" . $account['username'] . "</td>";
            echo "<td>" . $account['password'] . "</td>";
            echo "<td>" . $account['nama_lengkap'] . "</td>";
            echo "<td>" . $account['role'] . "</td>";
            echo "<td style='color: red;'>✗ Error: " . $stmt->error . "</td>";
            echo "</tr>";
        }
        $stmt->close();
    } else {
        echo "<tr>";
        echo "<td>" . $account['username'] . "</td>";
        echo "<td>" . $account['password'] . "</td>";
        echo "<td>" . $account['nama_lengkap'] . "</td>";
        echo "<td>" . $account['role'] . "</td>";
        echo "<td style='color: red;'>✗ Error prepare statement</td>";
        echo "</tr>";
    }
}

echo "</table>";

echo "<br><h3>Informasi Login:</h3>";
echo "<ul>";
echo "<li><strong>Admin:</strong> username = 'admin_new', password = 'admin123'</li>";
echo "<li><strong>Dokter 1:</strong> username = 'dr.andi', password = 'dokter123'</li>";
echo "<li><strong>Dokter 2:</strong> username = 'dr.maya', password = 'dokter123'</li>";
echo "<li><strong>Resepsionis 1:</strong> username = 'resepsionis1', password = 'resep123'</li>";
echo "<li><strong>Resepsionis 2:</strong> username = 'resepsionis2', password = 'resep123'</li>";
echo "</ul>";

echo "<br><p style='color: red; font-weight: bold;'>PENTING: Hapus file ini setelah selesai untuk keamanan!</p>";

$conn->close();
?>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background-color: #f5f5f5;
}
table {
    background-color: white;
    margin: 20px 0;
}
th {
    background-color: #007bff;
    color: white;
}
</style>