// Contoh JavaScript sederhana (jika dibutuhkan)
document.addEventListener('DOMContentLoaded', function() {
    // Misalnya, konfirmasi sebelum menghapus
    const deleteButtons = document.querySelectorAll('.delete-link'); // Jika Anda punya link dengan class .delete-link
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            if (!confirm('Apakah Anda yakin ingin menghapus data ini?')) {
                event.preventDefault();
            }
        });
    });

    // Contoh untuk toggle active class di sidebar (jika belum ada dari PHP)
    const currentLocation = window.location.href;
    const sidebarLinks = document.querySelectorAll('.sidebar ul li a');
    sidebarLinks.forEach(link => {
        if (link.href === currentLocation) {
            link.parentElement.classList.add('active');
        }
    });
});