<?php
// File: config/database.php

define('DB_SERVER', 'localhost');   // Server database Anda, biasanya 'localhost'
define('DB_USERNAME', 'root');      // Username database Anda
define('DB_PASSWORD', '');          // Password database Anda (kosongkan jika tidak ada)
define('DB_NAME', 'db_klinik');     // Nama database yang telah Anda buat

/**
 * Fungsi untuk membuat koneksi ke database.
 * @return mysqli|false Objek koneksi mysqli jika berhasil, false jika gagal.
 */
function connect_db() {
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    // Periksa koneksi
    if ($conn->connect_error) {
        // Jangan tampilkan error detail di produksi, cukup catat log atau pesan umum
        // die("Koneksi database gagal: " . $conn->connect_error);
        error_log("Koneksi database gagal: " . $conn->connect_error);
        return false; // atau throw new Exception("Tidak dapat terhubung ke database.");
    }

    // Set charset ke utf8mb4 untuk dukungan karakter yang lebih luas
    if (!$conn->set_charset("utf8mb4")) {
        error_log("Error loading character set utf8mb4: " . $conn->error);
    }

    return $conn;
}
?>