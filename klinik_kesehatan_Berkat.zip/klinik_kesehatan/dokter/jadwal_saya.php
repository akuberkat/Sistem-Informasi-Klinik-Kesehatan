<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('dokter');

$conn = connect_db();
$id_pengguna_dokter = $_SESSION['id_pengguna'];
$id_dokter = null;
$jadwal_konsultasi = [];
$error_message = '';

// Filter
$filter_tanggal = isset($_GET['tanggal']) ? sanitize_input($_GET['tanggal']) : '';
$filter_status = isset($_GET['status']) ? sanitize_input($_GET['status']) : ''; // Contoh: 'Dikonfirmasi', 'Selesai'
$filter_nama_pasien = isset($_GET['nama_pasien']) ? sanitize_input($_GET['nama_pasien']) : '';

// Ambil id_dokter
$stmt_get_dokter = $conn->prepare("SELECT id_dokter FROM dokter WHERE id_pengguna = ?");
if ($stmt_get_dokter) {
    $stmt_get_dokter->bind_param("i", $id_pengguna_dokter);
    $stmt_get_dokter->execute();
    $result_dokter = $stmt_get_dokter->get_result();
    if ($result_dokter->num_rows > 0) {
        $id_dokter = $result_dokter->fetch_assoc()['id_dokter'];
    } else {
        $error_message = "Data detail dokter tidak ditemukan.";
    }
    $stmt_get_dokter->close();
} else {
    $error_message = "Kesalahan query data dokter: " . $conn->error;
}

if ($id_dokter) {
    $params = [$id_dokter];
    $types = "i";

    $sql_jadwal = "SELECT
                        pk.id_pendaftaran,
                        pk.tanggal_konsultasi,
                        pk.jam_konsultasi,
                        pk.keluhan_utama,
                        pk.status_pendaftaran,
                        pasien_pengguna.nama_lengkap AS nama_pasien,
                        pas.nomor_rekam_medis
                   FROM pendaftaran_konsultasi pk
                   JOIN pasien pas ON pk.id_pasien = pas.id_pasien
                   JOIN pengguna pasien_pengguna ON pas.id_pengguna = pasien_pengguna.id_pengguna
                   WHERE pk.id_dokter = ? ";

    if (!empty($filter_tanggal)) {
        $sql_jadwal .= " AND pk.tanggal_konsultasi = ? ";
        $params[] = $filter_tanggal;
        $types .= "s";
    }
    if (!empty($filter_status)) {
        $sql_jadwal .= " AND pk.status_pendaftaran = ? ";
        $params[] = $filter_status;
        $types .= "s";
    }
     if (!empty($filter_nama_pasien)) {
        $sql_jadwal .= " AND pasien_pengguna.nama_lengkap LIKE ? ";
        $params[] = "%" . $filter_nama_pasien . "%";
        $types .= "s";
    }

    $sql_jadwal .= " ORDER BY pk.tanggal_konsultasi ASC, pk.jam_konsultasi ASC";

    $stmt_jadwal = $conn->prepare($sql_jadwal);
    if ($stmt_jadwal) {
        // Dynamically bind parameters
        if (!empty($params) && !empty($types)) {
             $stmt_jadwal->bind_param($types, ...$params);
        }

        $stmt_jadwal->execute();
        $result_jadwal = $stmt_jadwal->get_result();
        while ($row = $result_jadwal->fetch_assoc()) {
            $jadwal_konsultasi[] = $row;
        }
        $stmt_jadwal->close();
    } else {
        $error_message .= " Gagal mengambil data jadwal konsultasi: " . $conn->error;
    }
}

$conn->close();
?>

<?php $page_title = "Jadwal Konsultasi Saya"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Jadwal Konsultasi Saya</h1>
</div>

<?php if (!empty($error_message) && strpos($error_message, "Data detail dokter tidak ditemukan") !== false): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php else: ?>
    <?php if (!empty($error_message)): ?>
        <div class="alert alert-warning"><?php echo "Terjadi beberapa masalah saat mengambil data: " . $error_message; ?></div>
    <?php endif; ?>

    <div class="card mb-3">
        <div class="card-header">
            <h6><i class="fas fa-filter"></i> Filter Jadwal</h6>
        </div>
        <div class="card-body">
            <form action="jadwal_saya.php" method="GET" class="form-row align-items-end">
                <div class="col-md-3 form-group">
                    <label for="tanggal">Tanggal</label>
                    <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?php echo htmlspecialchars($filter_tanggal); ?>">
                </div>
                <div class="col-md-3 form-group">
                    <label for="status">Status Pendaftaran</label>
                    <select name="status" id="status" class="form-control">
                        <option value="">Semua Status</option>
                        <option value="Menunggu Konfirmasi" <?php echo ($filter_status == 'Menunggu Konfirmasi') ? 'selected' : ''; ?>>Menunggu Konfirmasi</option>
                        <option value="Dikonfirmasi" <?php echo ($filter_status == 'Dikonfirmasi') ? 'selected' : ''; ?>>Dikonfirmasi</option>
                        <option value="Selesai" <?php echo ($filter_status == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                        <option value="Dibatalkan" <?php echo ($filter_status == 'Dibatalkan') ? 'selected' : ''; ?>>Dibatalkan</option>
                    </select>
                </div>
                 <div class="col-md-3 form-group">
                    <label for="nama_pasien">Nama Pasien</label>
                    <input type="text" name="nama_pasien" id="nama_pasien" class="form-control" value="<?php echo htmlspecialchars($filter_nama_pasien); ?>" placeholder="Cari nama pasien...">
                </div>
                <div class="col-md-3 form-group">
                    <button type="submit" class="btn btn-primary mr-2"><i class="fas fa-search"></i> Terapkan Filter</button>
                    <a href="jadwal_saya.php" class="btn btn-secondary"><i class="fas fa-sync-alt"></i> Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h6>Daftar Semua Jadwal Konsultasi</h6>
        </div>
        <div class="card-body">
            <?php if (!empty($jadwal_konsultasi)): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Tanggal & Jam</th>
                                <th>Nama Pasien</th>
                                <th>No. RM</th>
                                <th>Keluhan Utama</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($jadwal_konsultasi as $index => $jadwal): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td>
                                        <?php echo htmlspecialchars(format_tanggal_indonesia($jadwal['tanggal_konsultasi'])); ?><br>
                                        <small><?php echo htmlspecialchars(date("H:i", strtotime($jadwal['jam_konsultasi']))); ?> WIB</small>
                                    </td>
                                    <td><?php echo htmlspecialchars($jadwal['nama_pasien']); ?></td>
                                    <td><?php echo htmlspecialchars($jadwal['nomor_rekam_medis']); ?></td>
                                    <td><?php echo nl2br(htmlspecialchars($jadwal['keluhan_utama'])); ?></td>
                                    <td>
                                        <?php
                                        $status_class = '';
                                        switch ($jadwal['status_pendaftaran']) {
                                            case 'Menunggu Konfirmasi': $status_class = 'badge badge-warning'; break;
                                            case 'Dikonfirmasi': $status_class = 'badge badge-info'; break;
                                            case 'Selesai': $status_class = 'badge badge-success'; break;
                                            case 'Dibatalkan': $status_class = 'badge badge-danger'; break;
                                            default: $status_class = 'badge badge-secondary'; break;
                                        }
                                        ?>
                                        <span class="<?php echo $status_class; ?>"><?php echo htmlspecialchars($jadwal['status_pendaftaran']); ?></span>
                                    </td>
                                    <td> <?php if ($jadwal['status_pendaftaran'] == 'Dikonfirmasi'): ?>
                                            <a href="proses_konsultasi.php?id_pendaftaran=<?php echo $jadwal['id_pendaftaran']; ?>" class="btn btn-sm btn-success">Proses Konsultasi</a>
                                        <?php elseif ($jadwal['status_pendaftaran'] == 'Selesai'): ?>
                                            <a href="lihat_rekam_medis.php?id_pendaftaran=<?php echo $jadwal['id_pendaftaran']; ?>" class="btn btn-sm btn-primary">Lihat RM</a>
                                        <?php else: ?>
                                            <small><em>Tunggu Konfirmasi</em></small>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">Tidak ada jadwal konsultasi yang sesuai dengan filter Anda, atau Anda belum memiliki jadwal.</p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; // Penutup else dari error_message Data detail dokter ?>
<?php include '../includes/footer.php'; ?>