<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('dokter');

$conn = connect_db();
$id_pengguna_dokter_login = $_SESSION['id_pengguna'];
$id_dokter_login = null; // ID dokter dari tabel dokter
$rekam_medis_detail = null;
$error_message = '';
$id_pendaftaran_url = null;

// Ambil id_dokter dari session dokter yang login (dari tabel dokter)
$stmt_get_id_dokter = $conn->prepare("SELECT id_dokter FROM dokter WHERE id_pengguna = ?");
if ($stmt_get_id_dokter) {
    $stmt_get_id_dokter->bind_param("i", $id_pengguna_dokter_login);
    $stmt_get_id_dokter->execute();
    $result_id_dokter = $stmt_get_id_dokter->get_result();
    if ($result_id_dokter->num_rows > 0) {
        $id_dokter_login = $result_id_dokter->fetch_assoc()['id_dokter'];
    } else {
        $error_message = "Data spesifik dokter tidak ditemukan untuk akun Anda.";
    }
    $stmt_get_id_dokter->close();
} else {
    $error_message = "Gagal mengambil data dokter login: " . $conn->error;
}


if (isset($_GET['id_pendaftaran']) && is_numeric($_GET['id_pendaftaran'])) {
    $id_pendaftaran_url = intval($_GET['id_pendaftaran']);

    if (empty($error_message)) { // Lanjutkan hanya jika tidak ada error sebelumnya
        // Query untuk mengambil detail rekam medis, pendaftaran, pasien, dan dokter yang menangani
        $sql = "SELECT
                    rm.*, -- Semua kolom dari rekam_medis
                    pk.tanggal_konsultasi, pk.jam_konsultasi, pk.keluhan_utama AS keluhan_awal_pendaftaran,
                    pas_p.nama_lengkap AS nama_pasien, pas.nomor_rekam_medis, pas.tanggal_lahir AS tanggal_lahir_pasien, pas.jenis_kelamin AS jenis_kelamin_pasien,
                    dok_p.nama_lengkap AS nama_dokter_pemeriksa, dok.spesialisasi AS spesialisasi_dokter_pemeriksa,
                    pk.id_dokter AS id_dokter_pada_pendaftaran -- Untuk verifikasi akses
                FROM rekam_medis rm
                JOIN pendaftaran_konsultasi pk ON rm.id_pendaftaran = pk.id_pendaftaran
                JOIN pasien pas ON rm.id_pasien = pas.id_pasien
                JOIN pengguna pas_p ON pas.id_pengguna = pas_p.id_pengguna
                JOIN dokter dok ON rm.id_dokter = dok.id_dokter -- Dokter yang mengisi RM
                JOIN pengguna dok_p ON dok.id_pengguna = dok_p.id_pengguna
                WHERE rm.id_pendaftaran = ?";

        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $id_pendaftaran_url);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $rekam_medis_detail = $result->fetch_assoc();

                // Verifikasi apakah dokter yang login berhak melihat
                // Dokter yang login haruslah dokter yang menangani pendaftaran ini ATAU dokter yang mengisi RM ini.
                // Untuk sistem yang lebih kompleks, bisa ada aturan berbagi RM.
                // Di sini, kita asumsikan dokter yang login (id_dokter_login) harus sama dengan dokter yang mengisi RM (rekam_medis_detail['id_dokter'])
                // atau dokter yang tertera pada pendaftaran (rekam_medis_detail['id_dokter_pada_pendaftaran'])
                if ($id_dokter_login != $rekam_medis_detail['id_dokter'] && $id_dokter_login != $rekam_medis_detail['id_dokter_pada_pendaftaran']) {
                     // Jika klinik mengizinkan semua dokter melihat RM pasien yang sama, kondisi ini bisa dihilangkan atau disesuaikan.
                    // $error_message = "Anda tidak memiliki izin untuk melihat rekam medis ini.";
                    // $rekam_medis_detail = null; // Kosongkan detail jika tidak berhak
                    // Untuk sekarang, kita biarkan dokter melihat jika datanya ada,
                    // namun idealnya ada pengecekan role dan hak akses yang lebih ketat.
                }

            } else {
                $error_message = "Rekam medis untuk pendaftaran ini tidak ditemukan.";
            }
            $stmt->close();
        } else {
            $error_message = "Gagal mengambil data rekam medis: " . $conn->error;
        }
    }
} else {
    $error_message = "ID Pendaftaran tidak valid atau tidak disertakan.";
}

$conn->close();
?>

<?php $page_title = "Detail Rekam Medis"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header d-flex justify-content-between align-items-center">
    <h1><?php echo $page_title; ?></h1>
    <a href="<?php echo isset($_SERVER['HTTP_REFERER']) ? htmlspecialchars($_SERVER['HTTP_REFERER']) : 'jadwal_saya.php'; ?>" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left"></i> Kembali
    </a>
</div>

<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<?php if ($rekam_medis_detail && empty($error_message)): ?>
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Rekam Medis Pasien: <?php echo htmlspecialchars($rekam_medis_detail['nama_pasien']); ?> (No. RM: <?php echo htmlspecialchars($rekam_medis_detail['nomor_rekam_medis']); ?>)</h5>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <h6>Informasi Pasien</h6>
                    <table class="table table-sm table-borderless">
                        <tr>
                            <th width="40%">Nama Pasien</th>
                            <td>: <?php echo htmlspecialchars($rekam_medis_detail['nama_pasien']); ?></td>
                        </tr>
                        <tr>
                            <th>Nomor Rekam Medis</th>
                            <td>: <?php echo htmlspecialchars($rekam_medis_detail['nomor_rekam_medis']); ?></td>
                        </tr>
                        <tr>
                            <th>Tanggal Lahir</th>
                            <td>: <?php echo htmlspecialchars(format_tanggal_indonesia($rekam_medis_detail['tanggal_lahir_pasien'])); ?></td>
                        </tr>
                        <tr>
                            <th>Jenis Kelamin</th>
                            <td>: <?php echo htmlspecialchars($rekam_medis_detail['jenis_kelamin_pasien']); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6>Informasi Konsultasi</h6>
                    <table class="table table-sm table-borderless">
                        <tr>
                            <th width="40%">Tanggal Konsultasi</th>
                            <td>: <?php echo htmlspecialchars(format_tanggal_indonesia($rekam_medis_detail['tanggal_konsultasi'])); ?> Jam <?php echo htmlspecialchars(date("H:i", strtotime($rekam_medis_detail['jam_konsultasi']))); ?></td>
                        </tr>
                         <tr>
                            <th>Tanggal Periksa (RM)</th>
                            <td>: <?php echo htmlspecialchars(format_tanggal_indonesia($rekam_medis_detail['tanggal_periksa'], true)); ?></td>
                        </tr>
                        <tr>
                            <th>Dokter Pemeriksa</th>
                            <td>: Dr. <?php echo htmlspecialchars($rekam_medis_detail['nama_dokter_pemeriksa']); ?> <small>(<?php echo htmlspecialchars($rekam_medis_detail['spesialisasi_dokter_pemeriksa']); ?>)</small></td>
                        </tr>
                        <tr>
                            <th>Keluhan Awal</th>
                            <td>: <?php echo nl2br(htmlspecialchars($rekam_medis_detail['keluhan_awal_pendaftaran'])); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <hr>

            <h6>Detail Pemeriksaan Medis</h6>
            <div class="rm-section mt-3">
                <h6 class="text-info">Anamnesis</h6>
                <p><?php echo nl2br(htmlspecialchars($rekam_medis_detail['anamnesis'] ?: '-')); ?></p>
            </div>

            <div class="rm-section mt-3">
                <h6 class="text-info">Pemeriksaan Fisik</h6>
                <p><?php echo nl2br(htmlspecialchars($rekam_medis_detail['pemeriksaan_fisik'] ?: '-')); ?></p>
            </div>

            <div class="rm-section mt-3">
                <h6 class="text-info">Diagnosa</h6>
                <p><?php echo nl2br(htmlspecialchars($rekam_medis_detail['diagnosa'] ?: '-')); ?></p>
            </div>

            <div class="rm-section mt-3">
                <h6 class="text-info">Tindakan / Terapi / Resep Obat</h6>
                <p><?php echo nl2br(htmlspecialchars($rekam_medis_detail['tindakan_obat'] ?: '-')); ?></p>
            </div>

            <div class="rm-section mt-3">
                <h6 class="text-info">Catatan Dokter Tambahan</h6>
                <p><?php echo nl2br(htmlspecialchars($rekam_medis_detail['catatan_dokter'] ?: '-')); ?></p>
            </div>
        </div>
        <div class="card-footer text-right">
            <button class="btn btn-outline-info" onclick="window.print();"><i class="fas fa-print"></i> Cetak Rekam Medis</button>
            </div>
    </div>
<style>
    .rm-section { margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px dashed #eee; }
    .rm-section:last-child { border-bottom: none; }
    .rm-section h6 { font-weight: bold; }
    .table-sm th, .table-sm td { padding: .3rem .5rem; }
    @media print {
        body * { visibility: hidden; }
        .page-header, .sidebar, .navbar, .footer, .btn, .alert { display: none !important; }
        .card.shadow, .card.shadow * { visibility: visible; }
        .card.shadow { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 0; border: none; box-shadow: none !important; }
        .card-header.bg-primary { background-color: #fff !important; color: #000 !important; border-bottom: 1px solid #ccc;}
        .card-header.bg-primary h5 { font-size: 1.5rem; text-align: center;}
        .card-body { padding: 10px; }
        .text-info { color: #000 !important;} /* Agar terbaca saat print hitam putih */
        a[href]:after { content: none !important; } /* Hindari URL muncul saat print */
    }
</style>
<?php else: ?>
    <?php if(empty($error_message)): // Jika tidak ada error spesifik tapi data tidak ada ?>
    <div class="alert alert-warning">Detail rekam medis tidak dapat ditampilkan.</div>
    <?php endif; ?>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>