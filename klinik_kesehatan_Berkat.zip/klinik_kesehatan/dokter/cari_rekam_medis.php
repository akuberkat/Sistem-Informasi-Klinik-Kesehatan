<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('dokter');

$conn = connect_db();
$id_pengguna_dokter_login = $_SESSION['id_pengguna'];
$id_dokter_login = null;

$search_term = isset($_GET['search_term']) ? sanitize_input($_GET['search_term']) : '';
$pasien_terpilih_detail = null;
$riwayat_konsultasi_pasien = [];
$pasien_search_results = [];
$error_message = '';
$id_pasien_terpilih = isset($_GET['id_pasien']) ? intval($_GET['id_pasien']) : null;

// Ambil id_dokter dari session dokter yang login
if ($conn) {
    $stmt_get_id_dokter = $conn->prepare("SELECT id_dokter FROM dokter WHERE id_pengguna = ?");
    if ($stmt_get_id_dokter) {
        $stmt_get_id_dokter->bind_param("i", $id_pengguna_dokter_login);
        $stmt_get_id_dokter->execute();
        $result_id_dokter = $stmt_get_id_dokter->get_result();
        if ($result_id_dokter->num_rows > 0) {
            $id_dokter_login = $result_id_dokter->fetch_assoc()['id_dokter'];
        } else {
            $error_message = "Data spesifik dokter untuk akun Anda tidak ditemukan.";
        }
        $stmt_get_id_dokter->close();
    } else {
        $error_message = "Gagal menyiapkan query data dokter: " . $conn->error;
    }
} else {
    $error_message = "Tidak dapat terhubung ke database.";
}

if ($_SERVER['REQUEST_METHOD'] == 'GET' && !empty($search_term) && empty($id_pasien_terpilih)) {
    // Proses pencarian pasien
    $sql_search_pasien = "SELECT p.id_pasien, u.nama_lengkap, p.nomor_rekam_medis, p.tanggal_lahir, p.jenis_kelamin
                          FROM pasien p
                          JOIN pengguna u ON p.id_pengguna = u.id_pengguna
                          WHERE u.nama_lengkap LIKE ? OR p.nomor_rekam_medis LIKE ?";
    $stmt_search = $conn->prepare($sql_search_pasien);
    if ($stmt_search) {
        $search_like = "%" . $search_term . "%";
        $stmt_search->bind_param("ss", $search_like, $search_like);
        $stmt_search->execute();
        $result_search = $stmt_search->get_result();
        while ($row = $result_search->fetch_assoc()) {
            $pasien_search_results[] = $row;
        }
        if (empty($pasien_search_results)) {
            $error_message = "Pasien dengan nama atau No. RM '$search_term' tidak ditemukan.";
        }
        $stmt_search->close();
    } else {
        $error_message = "Gagal melakukan pencarian pasien: " . $conn->error;
    }
} elseif ($id_pasien_terpilih && $id_dokter_login) {
    // Jika id_pasien dipilih (dari hasil search atau direct link), tampilkan detail dan riwayatnya
    $stmt_detail_pasien = $conn->prepare("SELECT p.id_pasien, u.nama_lengkap, p.nomor_rekam_medis, p.tanggal_lahir, p.jenis_kelamin FROM pasien p JOIN pengguna u ON p.id_pengguna = u.id_pengguna WHERE p.id_pasien = ?");
    if ($stmt_detail_pasien) {
        $stmt_detail_pasien->bind_param("i", $id_pasien_terpilih);
        $stmt_detail_pasien->execute();
        $result_detail = $stmt_detail_pasien->get_result();
        if ($result_detail->num_rows > 0) {
            $pasien_terpilih_detail = $result_detail->fetch_assoc();

            // Ambil riwayat konsultasi pasien (hanya yang ditangani dokter ini, atau semua?)
            // Untuk contoh, kita ambil semua yg statusnya 'Selesai' untuk pasien ini,
            // dan dokter bisa melihat RM jika dia yg menangani atau kebijakan lain.
            // Link ke lihat_rekam_medis.php akan tetap ada, tapi halaman itu yg akan cek hak akses detailnya.
            $sql_riwayat = "SELECT pk.id_pendaftaran, pk.tanggal_konsultasi, pk.jam_konsultasi, dok_p.nama_lengkap AS nama_dokter_rm, rm.diagnosa
                            FROM pendaftaran_konsultasi pk
                            LEFT JOIN rekam_medis rm ON pk.id_pendaftaran = rm.id_pendaftaran
                            JOIN dokter d ON pk.id_dokter = d.id_dokter
                            JOIN pengguna dok_p ON d.id_pengguna = dok_p.id_pengguna
                            WHERE pk.id_pasien = ? AND pk.status_pendaftaran = 'Selesai'
                            ORDER BY pk.tanggal_konsultasi DESC, pk.jam_konsultasi DESC";
            $stmt_riwayat = $conn->prepare($sql_riwayat);
            if ($stmt_riwayat) {
                $stmt_riwayat->bind_param("i", $id_pasien_terpilih);
                $stmt_riwayat->execute();
                $result_riwayat = $stmt_riwayat->get_result();
                while ($row = $result_riwayat->fetch_assoc()) {
                    $riwayat_konsultasi_pasien[] = $row;
                }
                $stmt_riwayat->close();
            } else {
                $error_message = "Gagal mengambil riwayat konsultasi pasien: " . $conn->error;
            }
        } else {
            $error_message = "Detail pasien tidak ditemukan.";
        }
        $stmt_detail_pasien->close();
    } else {
        $error_message = "Gagal mengambil detail pasien: " . $conn->error;
    }
}


if($conn) $conn->close();
?>

<?php $page_title = "Cari & Riwayat Rekam Medis Pasien"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1><?php echo $page_title; ?></h1>
</div>

<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<div class="card shadow mb-4">
    <div class="card-header">
        <h6><i class="fas fa-search"></i> Cari Pasien</h6>
    </div>
    <div class="card-body">
        <form action="cari_rekam_medis.php" method="GET" class="form-inline">
            <div class="form-group mb-2 mr-sm-2">
                <label for="search_term" class="sr-only">Kata Kunci</label>
                <input type="text" class="form-control" id="search_term" name="search_term" value="<?php echo htmlspecialchars($search_term); ?>" placeholder="Nama Pasien atau No. RM" style="min-width: 300px;">
            </div>
            <button type="submit" class="btn btn-primary mb-2"><i class="fas fa-search"></i> Cari</button>
            <?php if(!empty($search_term) || $id_pasien_terpilih): ?>
                 <a href="cari_rekam_medis.php" class="btn btn-secondary mb-2 ml-2"><i class="fas fa-sync-alt"></i> Reset Pencarian</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php if (!empty($search_term) && empty($id_pasien_terpilih) && !empty($pasien_search_results)): ?>
    <div class="card shadow mb-4">
        <div class="card-header">
            <h6><i class="fas fa-users"></i> Hasil Pencarian Pasien</h6>
        </div>
        <div class="card-body">
            <div class="list-group">
                <?php foreach ($pasien_search_results as $pasien): ?>
                    <a href="cari_rekam_medis.php?id_pasien=<?php echo $pasien['id_pasien']; ?>&search_term=<?php echo urlencode($search_term); ?>" class="list-group-item list-group-item-action">
                        <strong><?php echo htmlspecialchars($pasien['nama_lengkap']); ?></strong> (No. RM: <?php echo htmlspecialchars($pasien['nomor_rekam_medis']); ?>)
                        <br><small>Lahir: <?php echo htmlspecialchars(format_tanggal_indonesia($pasien['tanggal_lahir'])); ?> | <?php echo htmlspecialchars($pasien['jenis_kelamin']); ?></small>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>


<?php if ($pasien_terpilih_detail): ?>
    <div class="card shadow mb-4">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">Riwayat Rekam Medis untuk: <?php echo htmlspecialchars($pasien_terpilih_detail['nama_lengkap']); ?> (No. RM: <?php echo htmlspecialchars($pasien_terpilih_detail['nomor_rekam_medis']); ?>)</h5>
        </div>
        <div class="card-body">
            <p>
                <strong>Tanggal Lahir:</strong> <?php echo htmlspecialchars(format_tanggal_indonesia($pasien_terpilih_detail['tanggal_lahir'])); ?> |
                <strong>Jenis Kelamin:</strong> <?php echo htmlspecialchars($pasien_terpilih_detail['jenis_kelamin']); ?>
            </p>
            <hr>
            <?php if (!empty($riwayat_konsultasi_pasien)): ?>
                <h6>Daftar Kunjungan (Status Selesai):</h6>
                <div class="table-responsive">
                    <table class="table table-hover table-sm table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th>Tanggal Konsultasi</th>
                                <th>Jam</th>
                                <th>Dokter Pemeriksa</th>
                                <th>Diagnosa Awal (jika ada)</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($riwayat_konsultasi_pasien as $riwayat): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars(format_tanggal_indonesia($riwayat['tanggal_konsultasi'])); ?></td>
                                    <td><?php echo htmlspecialchars(date("H:i", strtotime($riwayat['jam_konsultasi']))); ?></td>
                                    <td>Dr. <?php echo htmlspecialchars($riwayat['nama_dokter_rm']); ?></td>
                                    <td><?php echo htmlspecialchars($riwayat['diagnosa'] ?: '-'); ?></td>
                                    <td>
                                        <a href="lihat_rekam_medis.php?id_pendaftaran=<?php echo $riwayat['id_pendaftaran']; ?>" class="btn btn-primary btn-sm" title="Lihat Detail RM">
                                            <i class="fas fa-file-medical"></i> Lihat Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">Belum ada riwayat konsultasi yang selesai untuk pasien ini.</p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>


<?php include '../includes/footer.php'; ?>