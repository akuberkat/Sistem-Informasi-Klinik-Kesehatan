<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('dokter'); // Memastikan hanya dokter yang bisa akses

$conn = connect_db();
$id_pengguna_dokter = $_SESSION['id_pengguna'];
$id_dokter = null;
$nama_dokter = $_SESSION['nama_lengkap']; // Ambil dari session untuk efisiensi
$spesialisasi_dokter = '';
$error_message = '';

// Statistik
$jumlah_pasien_hari_ini = 0;
$jumlah_konsultasi_mendatang = 0;
$jadwal_singkat_hari_ini = [];

// Ambil id_dokter dan spesialisasi dari tabel dokter
$stmt_get_dokter = $conn->prepare("SELECT id_dokter, spesialisasi FROM dokter WHERE id_pengguna = ?");
if ($stmt_get_dokter) {
    $stmt_get_dokter->bind_param("i", $id_pengguna_dokter);
    $stmt_get_dokter->execute();
    $result_dokter = $stmt_get_dokter->get_result();
    if ($result_dokter->num_rows > 0) {
        $dokter_data = $result_dokter->fetch_assoc();
        $id_dokter = $dokter_data['id_dokter'];
        $spesialisasi_dokter = $dokter_data['spesialisasi'];
    } else {
        $error_message = "Data detail dokter tidak ditemukan. Harap hubungi admin.";
    }
    $stmt_get_dokter->close();
} else {
    $error_message = "Kesalahan query data dokter: " . $conn->error;
}

if ($id_dokter) {
    $today = date("Y-m-d");

    // 1. Jumlah pasien hari ini (status Dikonfirmasi)
    $stmt_pasien_today = $conn->prepare("SELECT COUNT(id_pendaftaran) AS total FROM pendaftaran_konsultasi WHERE id_dokter = ? AND tanggal_konsultasi = ? AND status_pendaftaran = 'Dikonfirmasi'");
    if ($stmt_pasien_today) {
        $stmt_pasien_today->bind_param("is", $id_dokter, $today);
        $stmt_pasien_today->execute();
        $result_count_today = $stmt_pasien_today->get_result()->fetch_assoc();
        $jumlah_pasien_hari_ini = $result_count_today['total'];
        $stmt_pasien_today->close();
    } else {
        $error_message .= " Gagal mengambil jumlah pasien hari ini. ";
    }

    // 2. Jumlah total konsultasi mendatang (status Dikonfirmasi, dari hari ini ke depan)
    $stmt_konsultasi_mendatang = $conn->prepare("SELECT COUNT(id_pendaftaran) AS total FROM pendaftaran_konsultasi WHERE id_dokter = ? AND tanggal_konsultasi >= ? AND status_pendaftaran = 'Dikonfirmasi'");
    if ($stmt_konsultasi_mendatang) {
        $stmt_konsultasi_mendatang->bind_param("is", $id_dokter, $today);
        $stmt_konsultasi_mendatang->execute();
        $result_count_mendatang = $stmt_konsultasi_mendatang->get_result()->fetch_assoc();
        $jumlah_konsultasi_mendatang = $result_count_mendatang['total'];
        $stmt_konsultasi_mendatang->close();
    } else {
        $error_message .= " Gagal mengambil jumlah konsultasi mendatang. ";
    }

    // 3. Daftar singkat pasien hari ini (misal 5 teratas berdasarkan jam)
    $sql_jadwal_singkat = "SELECT
                                pk.id_pendaftaran,
                                pk.jam_konsultasi,
                                pk.keluhan_utama,
                                pasien_pengguna.nama_lengkap AS nama_pasien,
                                pas.nomor_rekam_medis
                           FROM pendaftaran_konsultasi pk
                           JOIN pasien pas ON pk.id_pasien = pas.id_pasien
                           JOIN pengguna pasien_pengguna ON pas.id_pengguna = pasien_pengguna.id_pengguna
                           WHERE pk.id_dokter = ? AND pk.tanggal_konsultasi = ? AND pk.status_pendaftaran = 'Dikonfirmasi'
                           ORDER BY pk.jam_konsultasi ASC
                           LIMIT 5";
    $stmt_jadwal_singkat = $conn->prepare($sql_jadwal_singkat);
    if ($stmt_jadwal_singkat) {
        $stmt_jadwal_singkat->bind_param("is", $id_dokter, $today);
        $stmt_jadwal_singkat->execute();
        $result_jadwal_singkat = $stmt_jadwal_singkat->get_result();
        while ($row = $result_jadwal_singkat->fetch_assoc()) {
            $jadwal_singkat_hari_ini[] = $row;
        }
        $stmt_jadwal_singkat->close();
    } else {
        $error_message .= " Gagal mengambil jadwal singkat hari ini. ";
    }
}

$conn->close();
?>

<?php $page_title = "Dashboard Dokter"; ?>
<?php include '../includes/header.php'; // Header akan menampilkan nama dari $_SESSION['nama_lengkap'] ?>

<div class="page-header">
    <h1>Dashboard Dokter</h1>
    <p class="lead">Selamat datang kembali, Dr. <?php echo htmlspecialchars($nama_dokter); ?>!</p>
    <?php if ($spesialisasi_dokter): ?>
        <p>Spesialisasi: <?php echo htmlspecialchars($spesialisasi_dokter); ?></p>
    <?php endif; ?>
</div>

<?php if (!empty($error_message) && strpos($error_message, "Data detail dokter tidak ditemukan") !== false): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php else: ?>
    <?php if (!empty($error_message)): ?>
        <div class="alert alert-warning"><?php echo "Terjadi beberapa masalah saat mengambil data: " . $error_message; ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6 col-lg-4 mb-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-user-md"></i> Pasien Hari Ini</h5>
                    <p class="card-text" style="font-size: 2.5em; font-weight: bold;"><?php echo $jumlah_pasien_hari_ini; ?></p>
                    <p class="card-text"><small>(Status: Dikonfirmasi)</small></p>
                    <a href="jadwal_saya.php?filter=hari_ini" class="btn btn-light btn-sm">Lihat Detail</a>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4 mb-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <h5 class="card-title"><i class="far fa-calendar-alt"></i> Konsultasi Mendatang</h5>
                    <p class="card-text" style="font-size: 2.5em; font-weight: bold;"><?php echo $jumlah_konsultasi_mendatang; ?></p>
                    <p class="card-text"><small>(Status: Dikonfirmasi)</small></p>
                    <a href="jadwal_saya.php" class="btn btn-light btn-sm">Lihat Semua Jadwal</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-3">
            <div class="card">
                 <div class="card-header">
                    <h6>Aksi Cepat</h6>
                </div>
                <div class="card-body">
                    <a href="jadwal_saya.php" class="btn btn-success btn-block mb-2"><i class="fas fa-calendar-check"></i> Kelola Jadwal Konsultasi</a>
                    <a href="cari_rekam_medis.php" class="btn btn-warning btn-block"><i class="fas fa-search"></i> Cari Rekam Medis Pasien</a>
                    </div>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h6><i class="fas fa-clipboard-list"></i> Pratinjau Jadwal Hari Ini (<?php echo format_tanggal_indonesia(date("Y-m-d")); ?>) - Maks. 5</h6>
        </div>
        <div class="card-body">
            <?php if (!empty($jadwal_singkat_hari_ini)): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Jam</th>
                                <th>Nama Pasien</th>
                                <th>No. RM</th>
                                <th>Keluhan Utama</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($jadwal_singkat_hari_ini as $jadwal): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars(date("H:i", strtotime($jadwal['jam_konsultasi']))); ?></td>
                                    <td><?php echo htmlspecialchars($jadwal['nama_pasien']); ?></td>
                                    <td><?php echo htmlspecialchars($jadwal['nomor_rekam_medis']); ?></td>
                                    <td><?php echo nl2br(htmlspecialchars(substr($jadwal['keluhan_utama'], 0, 50) . (strlen($jadwal['keluhan_utama']) > 50 ? '...' : ''))); ?></td>
                                    <td>
                                        <a href="proses_konsultasi.php?id_pendaftaran=<?php echo $jadwal['id_pendaftaran']; ?>" class="btn btn-sm btn-success">Proses</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                 <a href="jadwal_saya.php?filter=hari_ini" class="btn btn-outline-primary mt-2 btn-sm">Lihat Semua Jadwal Hari Ini</a>
            <?php else: ?>
                <p class="text-muted">Tidak ada jadwal konsultasi yang dikonfirmasi untuk hari ini.</p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; // Penutup else dari error_message Data detail dokter ?>
<?php include '../includes/footer.php'; ?>