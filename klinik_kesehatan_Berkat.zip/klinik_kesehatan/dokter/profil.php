<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('dokter');

$conn = connect_db();
$id_pengguna = $_SESSION['id_pengguna'];
$profil_dokter = null;
$error_message = '';
$success_message = '';

// Ambil data profil gabungan dari tabel pengguna dan dokter
$stmt_profil = $conn->prepare("SELECT
                                p.username, p.nama_lengkap, p.email, p.nomor_telepon, p.alamat,
                                d.id_dokter, d.spesialisasi, d.nomor_sip, d.foto_profil
                               FROM pengguna p
                               JOIN dokter d ON p.id_pengguna = d.id_pengguna
                               WHERE p.id_pengguna = ?");
if ($stmt_profil) {
    $stmt_profil->bind_param("i", $id_pengguna);
    $stmt_profil->execute();
    $result_profil = $stmt_profil->get_result();
    if ($result_profil->num_rows > 0) {
        $profil_dokter = $result_profil->fetch_assoc();
    } else {
        $error_message = "Data profil dokter tidak ditemukan.";
    }
    // Jangan tutup $stmt_profil di sini jika akan di-re-execute
} else {
    $error_message = "Kesalahan query profil: " . $conn->error;
}

// Proses Update Profil Data Teks
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profil_data']) && $profil_dokter) {
    $nama_lengkap = sanitize_input($_POST['nama_lengkap']);
    $email = sanitize_input($_POST['email']);
    $nomor_telepon = sanitize_input($_POST['nomor_telepon']);
    $alamat = sanitize_input($_POST['alamat']);
    $spesialisasi = sanitize_input($_POST['spesialisasi']);
    $nomor_sip = sanitize_input($_POST['nomor_sip']); // Nomor SIP bisa jadi sensitif, pertimbangkan siapa yang boleh edit

    // Validasi
    if (empty($nama_lengkap) || empty($email) || empty($spesialisasi)) {
        $error_message = "Nama Lengkap, Email, dan Spesialisasi wajib diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Format email tidak valid.";
    } else {
        // Cek apakah email baru (jika berubah) sudah digunakan pengguna lain
        if (strtolower($email) != strtolower($profil_dokter['email'])) {
            $stmt_cek_email = $conn->prepare("SELECT id_pengguna FROM pengguna WHERE email = ? AND id_pengguna != ?");
            if ($stmt_cek_email) {
                $stmt_cek_email->bind_param("si", $email, $id_pengguna);
                $stmt_cek_email->execute();
                if ($stmt_cek_email->get_result()->num_rows > 0) {
                    $error_message = "Email tersebut sudah digunakan oleh pengguna lain.";
                }
                $stmt_cek_email->close();
            } else {
                 $error_message = "Gagal melakukan pengecekan email.";
            }
        }

        if (empty($error_message)) {
            $conn->begin_transaction();
            try {
                // Update tabel pengguna
                $sql_update_pengguna = "UPDATE pengguna SET nama_lengkap = ?, email = ?, nomor_telepon = ?, alamat = ? WHERE id_pengguna = ?";
                $stmt_update_pengguna = $conn->prepare($sql_update_pengguna);
                if (!$stmt_update_pengguna) throw new Exception("Gagal menyiapkan statement pengguna: " . $conn->error);
                $stmt_update_pengguna->bind_param("ssssi", $nama_lengkap, $email, $nomor_telepon, $alamat, $id_pengguna);
                if (!$stmt_update_pengguna->execute()) throw new Exception("Gagal update pengguna: " . $stmt_update_pengguna->error);
                $stmt_update_pengguna->close();

                // Update tabel dokter
                $sql_update_dokter = "UPDATE dokter SET spesialisasi = ?, nomor_sip = ? WHERE id_pengguna = ?";
                $stmt_update_dokter = $conn->prepare($sql_update_dokter);
                if (!$stmt_update_dokter) throw new Exception("Gagal menyiapkan statement dokter: " . $conn->error);
                $stmt_update_dokter->bind_param("ssi", $spesialisasi, $nomor_sip, $id_pengguna);
                if (!$stmt_update_dokter->execute()) throw new Exception("Gagal update dokter: " . $stmt_update_dokter->error);
                $stmt_update_dokter->close();

                $conn->commit();
                $success_message = "Profil berhasil diperbarui.";
                $_SESSION['nama_lengkap'] = $nama_lengkap; // Update session

                // Re-fetch profil untuk menampilkan data terbaru
                if ($stmt_profil) { // Pastikan $stmt_profil masih valid
                    $stmt_profil->execute();
                    $profil_dokter = $stmt_profil->get_result()->fetch_assoc();
                }

            } catch (Exception $e) {
                $conn->rollback();
                $error_message = "Gagal memperbarui profil: " . $e->getMessage();
            }
        }
    }
}

// Proses Ganti Password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ganti_password']) && $profil_dokter) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];

    if (empty($current_password) || empty($new_password) || empty($confirm_new_password)) {
        $error_message = "Semua field password wajib diisi.";
    } elseif ($new_password != $confirm_new_password) {
        $error_message = "Password baru dan konfirmasi password tidak cocok.";
    } elseif (strlen($new_password) < 6) {
        $error_message = "Password baru minimal 6 karakter.";
    } else {
        $stmt_pass = $conn->prepare("SELECT password FROM pengguna WHERE id_pengguna = ?");
        if ($stmt_pass) {
            $stmt_pass->bind_param("i", $id_pengguna);
            $stmt_pass->execute();
            $result_pass = $stmt_pass->get_result();
            $user_data = $result_pass->fetch_assoc();
            $stmt_pass->close();

            if ($user_data && password_verify($current_password, $user_data['password'])) {
                $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt_update_pass = $conn->prepare("UPDATE pengguna SET password = ? WHERE id_pengguna = ?");
                if ($stmt_update_pass) {
                    $stmt_update_pass->bind_param("si", $hashed_new_password, $id_pengguna);
                    if ($stmt_update_pass->execute()) {
                        $success_message = "Password berhasil diganti.";
                    } else {
                        $error_message = "Gagal mengganti password: " . $stmt_update_pass->error;
                    }
                    $stmt_update_pass->close();
                } else {
                    $error_message = "Gagal menyiapkan statement ganti password.";
                }
            } else {
                $error_message = "Password saat ini salah.";
            }
        } else {
            $error_message = "Gagal memverifikasi password saat ini.";
        }
    }
}


// Proses Ganti Foto Profil
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_foto_profil']) && isset($_FILES['foto_profil_baru']) && $profil_dokter) {
    $foto_file = $_FILES['foto_profil_baru'];
    if ($foto_file['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../assets/images/foto_dokter/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true); // Buat direktori jika belum ada
        }
        $file_extension = strtolower(pathinfo($foto_file['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        $max_file_size = 2 * 1024 * 1024; // 2MB

        if (!in_array($file_extension, $allowed_extensions)) {
            $error_message = "Format file foto tidak valid. Hanya JPG, JPEG, PNG, GIF yang diizinkan.";
        } elseif ($foto_file['size'] > $max_file_size) {
            $error_message = "Ukuran file foto terlalu besar. Maksimal 2MB.";
        } else {
            $new_filename = "dokter_" . $id_pengguna . "_" . time() . "." . $file_extension;
            $destination = $upload_dir . $new_filename;

            if (move_uploaded_file($foto_file['tmp_name'], $destination)) {
                // Hapus foto lama jika ada dan bukan default
                $foto_lama = $profil_dokter['foto_profil'];
                if (!empty($foto_lama) && $foto_lama != 'default_dokter.png' && file_exists($upload_dir . $foto_lama)) {
                    unlink($upload_dir . $foto_lama);
                }

                // Update database
                $stmt_update_foto = $conn->prepare("UPDATE dokter SET foto_profil = ? WHERE id_pengguna = ?");
                if ($stmt_update_foto) {
                    $stmt_update_foto->bind_param("si", $new_filename, $id_pengguna);
                    if ($stmt_update_foto->execute()) {
                        $success_message = "Foto profil berhasil diperbarui.";
                        // Re-fetch profil
                        if ($stmt_profil) {
                            $stmt_profil->execute();
                            $profil_dokter = $stmt_profil->get_result()->fetch_assoc();
                        }
                    } else {
                        $error_message = "Gagal update database foto profil: " . $stmt_update_foto->error;
                    }
                    $stmt_update_foto->close();
                } else {
                     $error_message = "Gagal menyiapkan statement update foto.";
                }
            } else {
                $error_message = "Gagal memindahkan file foto yang diupload.";
            }
        }
    } elseif ($foto_file['error'] !== UPLOAD_ERR_NO_FILE) {
        $error_message = "Terjadi kesalahan saat upload foto: " . $foto_file['error'];
    }
}


if ($stmt_profil) $stmt_profil->close(); // Tutup statement profil setelah semua operasi selesai
$conn->close();
?>

<?php $page_title = "Profil Dokter"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1>Profil Saya</h1>
</div>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
<?php endif; ?>

<?php if ($profil_dokter): ?>
<div class="row">
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header">
                <h6>Foto Profil</h6>
            </div>
            <div class="card-body text-center">
                <img src="../assets/images/berkat.png/<?php echo !empty($profil_dokter['foto_profil']) ? htmlspecialchars($profil_dokter['foto_profil']) : 'default_dokter.png'; ?>"
                     alt="Foto Profil Dokter" class="img-fluid rounded-circle mb-2" style="width: 150px; height: 150px; object-fit: cover; border: 3px solid #ddd;">
                <h5 class="mt-2"><?php echo htmlspecialchars($profil_dokter['nama_lengkap']); ?></h5>
                <p class="text-muted"><?php echo htmlspecialchars($profil_dokter['spesialisasi']); ?></p>

                <form action="profil.php" method="POST" enctype="multipart/form-data" class="mt-3">
                    <input type="hidden" name="update_foto_profil" value="1">
                    <div class="form-group">
                        <label for="foto_profil_baru" class="small">Pilih foto baru (max 2MB):</label>
                        <input type="file" name="foto_profil_baru" id="foto_profil_baru" class="form-control-file form-control-sm" required>
                    </div>
                    <button type="submit" class="btn btn-sm btn-info btn-block">Ganti Foto</button>
                </form>
            </div>
        </div>

        <div class="card">
             <div class="card-header">
                <h6>Ganti Password</h6>
            </div>
            <div class="card-body">
                <form action="profil.php" method="POST">
                    <input type="hidden" name="ganti_password" value="1">
                    <div class="form-group">
                        <label for="current_password">Password Saat Ini</label>
                        <input type="password" name="current_password" id="current_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">Password Baru</label>
                        <input type="password" name="new_password" id="new_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_new_password">Konfirmasi Password Baru</label>
                        <input type="password" name="confirm_new_password" id="confirm_new_password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-warning btn-block">Ganti Password</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                 <h6>Informasi Profil</h6>
                 <button class="btn btn-sm btn-info" onclick="toggleEditFormDokter()">Edit Detail Profil</button>
            </div>
            <div class="card-body">
                <table class="table table-borderless profile-table dokter-profile-view">
                    <tr><th width="30%">Username</th><td>: <?php echo htmlspecialchars($profil_dokter['username']); ?></td></tr>
                    <tr><th>Nama Lengkap</th><td>: <?php echo htmlspecialchars($profil_dokter['nama_lengkap']); ?></td></tr>
                    <tr><th>Email</th><td>: <?php echo htmlspecialchars($profil_dokter['email']); ?></td></tr>
                    <tr><th>Nomor Telepon</th><td>: <?php echo htmlspecialchars($profil_dokter['nomor_telepon'] ?: '-'); ?></td></tr>
                    <tr><th>Alamat</th><td>: <?php echo nl2br(htmlspecialchars($profil_dokter['alamat'] ?: '-')); ?></td></tr>
                    <tr><th>Spesialisasi</th><td>: <?php echo htmlspecialchars($profil_dokter['spesialisasi']); ?></td></tr>
                    <tr><th>Nomor SIP</th><td>: <?php echo htmlspecialchars($profil_dokter['nomor_sip'] ?: '-'); ?></td></tr>
                </table>

                <div id="editProfileFormDokter" style="display:none; margin-top: 20px; padding-top:20px; border-top: 1px solid #eee;">
                    <h5>Edit Detail Informasi Profil</h5>
                    <form action="profil.php" method="POST">
                        <input type="hidden" name="update_profil_data" value="1">
                        <div class="form-group">
                            <label for="nama_lengkap">Nama Lengkap <span style="color:red;">*</span></label>
                            <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" value="<?php echo htmlspecialchars($profil_dokter['nama_lengkap']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email <span style="color:red;">*</span></label>
                            <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($profil_dokter['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="nomor_telepon">Nomor Telepon</label>
                            <input type="tel" name="nomor_telepon" id="nomor_telepon" class="form-control" value="<?php echo htmlspecialchars($profil_dokter['nomor_telepon']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <textarea name="alamat" id="alamat" rows="3" class="form-control"><?php echo htmlspecialchars($profil_dokter['alamat']); ?></textarea>
                        </div>
                         <div class="form-group">
                            <label for="spesialisasi">Spesialisasi <span style="color:red;">*</span></label>
                            <input type="text" name="spesialisasi" id="spesialisasi" class="form-control" value="<?php echo htmlspecialchars($profil_dokter['spesialisasi']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="nomor_sip">Nomor SIP</label>
                            <input type="text" name="nomor_sip" id="nomor_sip" class="form-control" value="<?php echo htmlspecialchars($profil_dokter['nomor_sip']); ?>">
                        </div>
                        <button type="submit" class="btn btn-success">Simpan Perubahan Detail</button>
                        <button type="button" class="btn btn-secondary" onclick="toggleEditFormDokter()">Batal</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .profile-table th { text-align: left; font-weight: bold; }
    .profile-table td { padding-left: 10px; }
</style>

<script>
function toggleEditFormDokter() {
    var form = document.getElementById('editProfileFormDokter');
    // var displayInfo = document.querySelector('.dokter-profile-view'); // Jika ingin menyembunyikan tabel saat form muncul
    if (form.style.display === 'none' || form.style.display === '') {
        form.style.display = 'block';
        // displayInfo.style.display = 'none';
    } else {
        form.style.display = 'none';
        // displayInfo.style.display = 'table';
    }
}
</script>

<?php else: ?>
    <div class="alert alert-warning">Tidak dapat memuat data profil dokter. Silakan coba lagi atau hubungi administrator.</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>