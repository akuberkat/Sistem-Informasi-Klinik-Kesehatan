<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

check_login('dokter');

$conn = connect_db();
$id_pengguna_dokter_login = $_SESSION['id_pengguna'];
$id_dokter_login = null; // ID dokter dari tabel dokter
$error_message = '';
$success_message = '';
$pendaftaran_detail = null;
// $pasien_detail = null; // Data pasien akan diambil bersamaan dengan pendaftaran_detail
$id_pendaftaran_url = null;

// Ambil id_dokter dari session dokter yang login (dari tabel dokter)
$stmt_get_id_dokter = $conn->prepare("SELECT id_dokter FROM dokter WHERE id_pengguna = ?");
if ($stmt_get_id_dokter) {
    $stmt_get_id_dokter->bind_param("i", $id_pengguna_dokter_login);
    $stmt_get_id_dokter->execute();
    $result_id_dokter = $stmt_get_id_dokter->get_result();
    if ($result_id_dokter->num_rows > 0) {
        $id_dokter_login = $result_id_dokter->fetch_assoc()['id_dokter'];
    } else {
        $error_message = "Autentikasi data dokter gagal. Harap login ulang atau hubungi admin jika masalah berlanjut.";
        // Hentikan eksekusi jika data dokter krusial tidak ada
        include '../includes/header.php'; // Untuk layout dasar pesan error
        echo "<div class='container mt-3'><div class='alert alert-danger'>$error_message. <a href='../index.php'>Login kembali</a></div></div>";
        include '../includes/footer.php';
        exit;
    }
    $stmt_get_id_dokter->close();
} else {
    $error_message = "Kesalahan query data dokter: " . $conn->error;
    include '../includes/header.php';
    echo "<div class='container mt-3'><div class='alert alert-danger'>$error_message</div></div>";
    include '../includes/footer.php';
    exit;
}


// Ambil id_pendaftaran dari URL
if (isset($_GET['id_pendaftaran']) && is_numeric($_GET['id_pendaftaran'])) {
    $id_pendaftaran_url = intval($_GET['id_pendaftaran']);

    // Ambil detail pendaftaran dan pastikan milik dokter yang login dan statusnya 'Dikonfirmasi'
    $sql_pendaftaran = "SELECT
                            pk.id_pendaftaran, pk.id_pasien, pk.keluhan_utama, pk.tanggal_konsultasi, pk.jam_konsultasi, pk.status_pendaftaran,
                            pas.nomor_rekam_medis, pas_pengguna.nama_lengkap AS nama_pasien, pas_pengguna.email AS email_pasien,
                            pas.tanggal_lahir, pas.jenis_kelamin, pas_pengguna.alamat AS alamat_pasien, pas_pengguna.nomor_telepon AS telepon_pasien
                        FROM pendaftaran_konsultasi pk
                        JOIN pasien pas ON pk.id_pasien = pas.id_pasien
                        JOIN pengguna pas_pengguna ON pas.id_pengguna = pas_pengguna.id_pengguna
                        WHERE pk.id_pendaftaran = ? AND pk.id_dokter = ?"; // Pastikan pendaftaran untuk dokter yg login

    $stmt_pendaftaran = $conn->prepare($sql_pendaftaran);
    if ($stmt_pendaftaran) {
        $stmt_pendaftaran->bind_param("ii", $id_pendaftaran_url, $id_dokter_login);
        $stmt_pendaftaran->execute();
        $result_pendaftaran = $stmt_pendaftaran->get_result();
        if ($result_pendaftaran->num_rows > 0) {
            $pendaftaran_detail = $result_pendaftaran->fetch_assoc();

            if ($pendaftaran_detail['status_pendaftaran'] == 'Selesai') {
                $error_message = "Konsultasi ini sudah selesai. Anda dapat melihat rekam medisnya.";
                // Arahkan ke lihat_rekam_medis.php jika sudah selesai
                // header("Location: lihat_rekam_medis.php?id_pendaftaran=" . $id_pendaftaran_url);
                // exit;
            } elseif ($pendaftaran_detail['status_pendaftaran'] == 'Dibatalkan') {
                 $error_message = "Pendaftaran konsultasi ini telah dibatalkan.";
            } elseif ($pendaftaran_detail['status_pendaftaran'] != 'Dikonfirmasi') {
                 $error_message = "Konsultasi ini belum dikonfirmasi atau statusnya tidak valid untuk diproses.";
            }

            // Cek apakah rekam medis sudah ada (seharusnya tidak jika status masih 'Dikonfirmasi')
            $stmt_cek_rm_exist = $conn->prepare("SELECT id_rekam_medis FROM rekam_medis WHERE id_pendaftaran = ?");
            if($stmt_cek_rm_exist){
                $stmt_cek_rm_exist->bind_param("i", $id_pendaftaran_url);
                $stmt_cek_rm_exist->execute();
                if ($stmt_cek_rm_exist->get_result()->num_rows > 0 && $pendaftaran_detail['status_pendaftaran'] == 'Dikonfirmasi') {
                     $error_message = "Rekam medis untuk pendaftaran ini sudah ada, namun status pendaftaran belum 'Selesai'. Hubungi Admin.";
                     // Ini kondisi anomali, idealnya tidak terjadi.
                }
                $stmt_cek_rm_exist->close();
            }

        } else {
            $error_message = "Pendaftaran tidak ditemukan atau tidak dialokasikan untuk Anda.";
        }
        $stmt_pendaftaran->close();
    } else {
        $error_message = "Gagal mengambil detail pendaftaran: " . $conn->error;
    }
} else {
    $error_message = "ID Pendaftaran tidak valid atau tidak disertakan.";
}

// Proses Simpan Rekam Medis
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['simpan_rekam_medis']) && $pendaftaran_detail && $pendaftaran_detail['status_pendaftaran'] == 'Dikonfirmasi' && empty($error_message) /* pastikan tidak ada error sebelumnya */ ) {
    $anamnesis = sanitize_input($_POST['anamnesis']);
    $pemeriksaan_fisik = sanitize_input($_POST['pemeriksaan_fisik']);
    $diagnosa = sanitize_input($_POST['diagnosa']);
    $tindakan_obat = sanitize_input($_POST['tindakan_obat']);
    $catatan_dokter = sanitize_input($_POST['catatan_dokter']);
    // tanggal_periksa bisa diambil dari tanggal_konsultasi atau waktu saat ini
    // Untuk konsistensi, kita bisa gunakan tanggal_konsultasi dan gabung dengan waktu saat ini jika perlu,
    // atau cukup tanggal saat ini (NOW()) untuk tanggal_periksa di rekam medis.
    $tanggal_periksa_rm = date("Y-m-d H:i:s");

    if (empty($diagnosa)) { // Contoh validasi sederhana
        $error_message = "Diagnosa wajib diisi untuk menyimpan rekam medis.";
    } else {
        $conn->begin_transaction();
        try {
            // 1. Insert ke tabel rekam_medis
            $stmt_insert_rm = $conn->prepare("INSERT INTO rekam_medis (id_pendaftaran, id_pasien, id_dokter, tanggal_periksa, anamnesis, pemeriksaan_fisik, diagnosa, tindakan_obat, catatan_dokter) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (!$stmt_insert_rm) { throw new Exception("Gagal menyiapkan statement insert RM: " . $conn->error); }

            $stmt_insert_rm->bind_param("iiissssss",
                $pendaftaran_detail['id_pendaftaran'],
                $pendaftaran_detail['id_pasien'],
                $id_dokter_login, // id_dokter yang sedang login dan mengisi
                $tanggal_periksa_rm,
                $anamnesis,
                $pemeriksaan_fisik,
                $diagnosa,
                $tindakan_obat,
                $catatan_dokter
            );
            if (!$stmt_insert_rm->execute()) { throw new Exception("Gagal menyimpan rekam medis: " . $stmt_insert_rm->error); }
            $id_rekam_medis_baru = $stmt_insert_rm->insert_id; // Ambil ID RM baru jika perlu
            $stmt_insert_rm->close();

            // 2. Update status pendaftaran_konsultasi menjadi 'Selesai'
            $stmt_update_status = $conn->prepare("UPDATE pendaftaran_konsultasi SET status_pendaftaran = 'Selesai' WHERE id_pendaftaran = ?");
            if (!$stmt_update_status) { throw new Exception("Gagal menyiapkan statement update status: " . $conn->error); }

            $stmt_update_status->bind_param("i", $pendaftaran_detail['id_pendaftaran']);
            if (!$stmt_update_status->execute()) { throw new Exception("Gagal update status pendaftaran: " . $stmt_update_status->error); }
            $stmt_update_status->close();

            $conn->commit();
            $success_message = "Rekam medis berhasil disimpan dan konsultasi (ID Pendaftaran: ".$pendaftaran_detail['id_pendaftaran'].") telah diselesaikan.";
            // Update status pendaftaran_detail agar form tidak tampil lagi
            if($pendaftaran_detail) $pendaftaran_detail['status_pendaftaran'] = 'Selesai';

            // Untuk UX yang lebih baik, redirect setelah beberapa detik
            // Atau bisa juga langsung menampilkan pesan sukses dan link.
            echo "<div class='container mt-3'><div class='alert alert-success'>$success_message Anda akan dialihkan dalam 5 detik... <a href='jadwal_saya.php'>Kembali ke Jadwal Saya</a></div></div>";
            header("refresh:5;url=jadwal_saya.php"); // Redirect ke jadwal saya
            include '../includes/footer.php'; // Pastikan footer di-include sebelum exit jika ada output HTML
            exit;

        } catch (Exception $e) {
            $conn->rollback();
            $error_message = "Terjadi kesalahan saat menyimpan data: " . $e->getMessage();
        }
    }
}

// Jika setelah POST ada error, $pendaftaran_detail mungkin sudah tidak valid, fetch ulang jika perlu (tapi untuk form ini, jika ada error POST, biasanya data POST dipertahankan untuk sticky form)
// Namun, jika $pendaftaran_detail jadi null karena error awal, form tidak akan tampil.

?>
<?php $page_title = "Proses Konsultasi & Rekam Medis"; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h1><?php echo $page_title; ?></h1>
</div>

<?php if (!empty($success_message) && (!$pendaftaran_detail || $pendaftaran_detail['status_pendaftaran'] == 'Selesai')): // Tampilkan hanya jika sudah selesai atau tidak ada detail lagi ?>
    <div class="alert alert-success"><?php echo $success_message; ?> <a href="jadwal_saya.php" class="alert-link">Kembali ke Jadwal Saya</a>.</div>
<?php endif; ?>
<?php if (!empty($error_message)): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?> 
        <?php if ($pendaftaran_detail && $pendaftaran_detail['status_pendaftaran'] == 'Selesai'): ?>
             <a href="lihat_rekam_medis.php?id_pendaftaran=<?php echo $id_pendaftaran_url; ?>" class="alert-link">Lihat Rekam Medis</a>.
        <?php elseif ($id_pendaftaran_url): ?>
             <a href="jadwal_saya.php" class="alert-link">Kembali ke Jadwal Saya</a>.
        <?php endif; ?>
    </div>
<?php endif; ?>


<?php
// Tampilkan form hanya jika pendaftaran valid, statusnya 'Dikonfirmasi', dan tidak ada error kritis sebelumnya
if ($pendaftaran_detail && empty($error_message) && $pendaftaran_detail['status_pendaftaran'] == 'Dikonfirmasi'):
?>
    <div class="row">
        <div class="col-md-4">
            <div class="card mb-3 shadow-sm">
                <div class="card-header bg-light">
                    <h6><i class="fas fa-user-injured"></i> Informasi Pasien</h6>
                </div>
                <div class="card-body">
                    <p><strong>Nama:</strong> <?php echo htmlspecialchars($pendaftaran_detail['nama_pasien']); ?></p>
                    <p><strong>No. RM:</strong> <?php echo htmlspecialchars($pendaftaran_detail['nomor_rekam_medis']); ?></p>
                    <p><strong>Tgl Lahir:</strong> <?php echo htmlspecialchars(format_tanggal_indonesia($pendaftaran_detail['tanggal_lahir'])); ?> (Usia: <?php echo $pendaftaran_detail['tanggal_lahir'] ? (new DateTime())->diff(new DateTime($pendaftaran_detail['tanggal_lahir']))->y . ' th' : '-'; ?>)</p>
                    <p><strong>Jenis Kelamin:</strong> <?php echo htmlspecialchars($pendaftaran_detail['jenis_kelamin']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($pendaftaran_detail['email_pasien'] ?: '-'); ?></p>
                    <p><strong>Telepon:</strong> <?php echo htmlspecialchars($pendaftaran_detail['telepon_pasien'] ?: '-'); ?></p>
                    <p><strong>Alamat:</strong> <?php echo nl2br(htmlspecialchars($pendaftaran_detail['alamat_pasien'] ?: '-')); ?></p>
                </div>
            </div>
            <div class="card shadow-sm">
                 <div class="card-header bg-light">
                    <h6><i class="fas fa-calendar-check"></i> Detail Pendaftaran</h6>
                </div>
                <div class="card-body">
                    <p><strong>Tgl Rencana Konsul:</strong> <?php echo htmlspecialchars(format_tanggal_indonesia($pendaftaran_detail['tanggal_konsultasi'])); ?> jam <?php echo htmlspecialchars(date("H:i", strtotime($pendaftaran_detail['jam_konsultasi']))); ?></p>
                    <p><strong>Keluhan Utama Pasien:</strong></p>
                    <blockquote class="blockquote">
                        <p class="mb-0" style="font-size: 0.9em; background-color: #f8f9fa; border-left: 3px solid #007bff; padding: 10px;"><?php echo nl2br(htmlspecialchars($pendaftaran_detail['keluhan_utama'])); ?></p>
                    </blockquote>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h6><i class="fas fa-file-medical-alt"></i> Formulir Pengisian Rekam Medis</h6>
                </div>
                <div class="card-body">
                    <form action="proses_konsultasi.php?id_pendaftaran=<?php echo $id_pendaftaran_url; ?>" method="POST">
                        <div class="form-group">
                            <label for="anamnesis"><strong>Anamnesis</strong> (Riwayat Keluhan, Penyakit, Pengobatan)</label>
                            <textarea name="anamnesis" id="anamnesis" rows="5" class="form-control" placeholder="Contoh: Pasien datang dengan keluhan utama demam sejak 3 hari yang lalu. Demam naik turun, disertai sakit kepala dan nyeri otot. Tidak ada batuk pilek. Riwayat penyakit sebelumnya: Hipertensi terkontrol. Riwayat alergi obat disangkal..."><?php echo isset($_POST['anamnesis']) ? htmlspecialchars($_POST['anamnesis']) : ''; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="pemeriksaan_fisik"><strong>Pemeriksaan Fisik</strong></label>
                            <textarea name="pemeriksaan_fisik" id="pemeriksaan_fisik" rows="5" class="form-control" placeholder="Contoh: KU: Tampak sakit sedang. Kes: Compos Mentis, GCS E4V5M6. Tensi: 120/80 mmHg, Nadi: 88x/menit, RR: 20x/menit, Suhu: 38.5°C. Kepala: CA -/-, SI -/-. Thorax: Cor/Pulmo dbn. Abdomen: Supel, NT (-)..."><?php echo isset($_POST['pemeriksaan_fisik']) ? htmlspecialchars($_POST['pemeriksaan_fisik']) : ''; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="diagnosa"><strong>Diagnosa Medis</strong> <span style="color:red;">*</span></label>
                            <textarea name="diagnosa" id="diagnosa" rows="3" class="form-control" placeholder="Contoh: Observasi Febris H3 e.c. Viral Infection / Susp. Dengue Fever / Common Cold..." required><?php echo isset($_POST['diagnosa']) ? htmlspecialchars($_POST['diagnosa']) : ''; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="tindakan_obat"><strong>Tindakan / Terapi / Resep Obat</strong></label>
                            <textarea name="tindakan_obat" id="tindakan_obat" rows="5" class="form-control" placeholder="Contoh Resep: R/ Paracetamol 500mg tab No. XV S 3 dd tab I pc. R/ Vitamin C tab No. X S 1 dd tab I. Edukasi: Istirahat cukup, banyak minum air putih. Tindakan: Pemberian infus RL..."><?php echo isset($_POST['tindakan_obat']) ? htmlspecialchars($_POST['tindakan_obat']) : ''; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="catatan_dokter"><strong>Catatan Tambahan / Rencana Tindak Lanjut</strong></label>
                            <textarea name="catatan_dokter" id="catatan_dokter" rows="3" class="form-control" placeholder="Contoh: Rencana pemeriksaan laboratorium darah lengkap dan NS1 besok. Kontrol kembali 2 hari lagi atau jika ada perburukan. Waspada tanda bahaya demam berdarah..."><?php echo isset($_POST['catatan_dokter']) ? htmlspecialchars($_POST['catatan_dokter']) : ''; ?></textarea>
                        </div>
                        <button type="submit" name="simpan_rekam_medis" class="btn btn-success btn-lg"><i class="fas fa-save"></i> Simpan Rekam Medis & Selesaikan Konsultasi</button>
                        <a href="jadwal_saya.php" class="btn btn-outline-secondary ml-2">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php
// Kondisi jika pendaftaran sudah selesai (setelah submit berhasil atau dari GET sebelumnya)
elseif ($pendaftaran_detail && $pendaftaran_detail['status_pendaftaran'] == 'Selesai' && empty($error_message)):
?>
    <div class="alert alert-info">
        Konsultasi ini sudah selesai. Rekam medis telah diisi.
        <a href="lihat_rekam_medis.php?id_pendaftaran=<?php echo $id_pendaftaran_url; ?>" class="alert-link">Lihat Rekam Medis</a> atau
        <a href="jadwal_saya.php" class="alert-link">Kembali ke Jadwal Saya</a>.
    </div>
<?php
// Kondisi jika pendaftaran dibatalkan atau status lain yang tidak valid (dan tidak ada error message utama)
elseif ($pendaftaran_detail && ($pendaftaran_detail['status_pendaftaran'] == 'Dibatalkan' || $pendaftaran_detail['status_pendaftaran'] == 'Menunggu Konfirmasi') && empty($error_message)):
?>
     <div class="alert alert-warning">
        Status pendaftaran ini adalah '<?php echo $pendaftaran_detail['status_pendaftaran']; ?>' dan tidak dapat diproses saat ini.
        <a href="jadwal_saya.php" class="alert-link">Kembali ke Jadwal Saya</a>.
    </div>
<?php
// Fallback jika $pendaftaran_detail null dan tidak ada error message spesifik (seharusnya sudah ditangani di atas)
elseif(empty($error_message)):
?>
    <div class="alert alert-warning">Tidak ada detail pendaftaran yang dapat diproses. Silakan periksa kembali ID Pendaftaran atau <a href="jadwal_saya.php" class="alert-link">kembali ke Jadwal Saya</a>.</div>
<?php
endif;
?>

<?php include '../includes/footer.php'; ?>